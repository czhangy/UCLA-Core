import requests

# Generate expected echo response
def generate_echo_response(hostname, port, path):
    expected_echo =f"""GET {path} HTTP/1.1\r
Host: {hostname}:{port}\r
User-Agent: python-requests/{requests.__version__}\r
Accept-Encoding: gzip, deflate\r
Accept: */*\r
Connection: keep-alive"""
    return expected_echo

# Generate config
def generate_config(port):
    port = str(port)
    config_path = "./config"
    config = """listen """+port+""";

threads 2;

location / NotFoundHandler {
}

location /echo EchoHandler {
}

location /static StaticHandler {
    root /tests/integration_tests/static;
}

location /api CRUDHandler {
    data_path /tests/integration_tests/crud;
    filesystem boost;
}
location /health HealthHandler{

}
location /sleep SleepHandler {
    time 1;
}"""
    file = open(config_path, 'w')
    file.write(config)
    file.close()

    return config_path