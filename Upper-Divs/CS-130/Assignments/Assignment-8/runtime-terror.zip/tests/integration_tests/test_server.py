from subprocess import Popen, DEVNULL

# Test Server class for integration tests
class TestServer:
    def __init__(self, executable, config):
        self.executable = executable
        self.config = config
    
    def start(self):
        self.proc = Popen([self.executable, self.config], text=True)
    
    def stop(self):
        self.proc.kill()