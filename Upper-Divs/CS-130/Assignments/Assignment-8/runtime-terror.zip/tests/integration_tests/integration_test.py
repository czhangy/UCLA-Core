from test_server import TestServer
from util import *
import time
import sys
import requests
import json
import difflib


# Constants
SERVER_URL= "http://localhost"
SERVER_HOST = "localhost"
SERVER_PORT = "8080"
NUM_TESTS = 12

# Expected responses
INVALID_URI = "404 Not Found"
STATIC_TEXT = "This is a test file for .txt extension in /static."
SLEEP_TEXT = "Thread slept for 1 second"
SLEEP_TIME = 1

# Paths
EXECUTABLE_PATH = "./bin/webserver"
CONFIG_PATH = generate_config(port=SERVER_PORT)

def integration_test():
    tests_passed = 0
    try:
        # Start the server
        print("STARTING WEBSERVER...")
        server = TestServer(executable=EXECUTABLE_PATH, config=CONFIG_PATH)
        server.start()
        time.sleep(1)

        # Test 404 request
        print("--------------------------------------------")
        path = "/"
        out = requests.get(SERVER_URL+ ':' + SERVER_PORT + path, stream=False)
        if out.text.strip() == INVALID_URI and out.status_code == 404:
            print("404 TEST PASSED")
            tests_passed += 1
        else:
            print("404 TEST FAILED")
        print("--------------------------------------------\n")

        # Test echo request 
        print("--------------------------------------------")
        path = "/echo"
        expected_echo = generate_echo_response(hostname=SERVER_HOST, port=SERVER_PORT, path=path).strip()
        out = requests.get(SERVER_URL + ':' + SERVER_PORT + path)
        if out.text.strip() == expected_echo and out.status_code == 200:
            print("ECHO TEST PASSED")
            tests_passed += 1
        else:
            print("ECHO TEST FAILED")
        print("--------------------------------------------\n")

        # Test 10 rapid echo requests
        print("--------------------------------------------")
        path = "/echo"
        expected_echo = generate_echo_response(hostname=SERVER_HOST, port=SERVER_PORT, path=path)
        passed = True
        for i in range(10):
            out = requests.get(SERVER_URL + ':' + SERVER_PORT + path)
            if (out.text.strip() != expected_echo) or (out.status_code != 200):
                passed = False
                break
        if passed:
            print("10 RAPID REQUEST TEST PASSED")
            tests_passed += 1
        else:
            print("10 RAPID REQUEST TEST FAILED")
        print("--------------------------------------------\n")
    
        # Test static request
        print("--------------------------------------------")
        path = "/static/test.txt"
        out = requests.get(SERVER_URL + ':' + SERVER_PORT + path)
        if out.text.strip() == STATIC_TEXT and out.status_code == 200:
            print("STATIC TEST PASSED")
            tests_passed += 1
        else:
            print("STATIC TEST FAILED")
        print("--------------------------------------------\n")

        # Test sleep request
        print("--------------------------------------------")
        path = "/sleep"
        start = time.time()
        out = requests.get(SERVER_URL + ':' + SERVER_PORT + path)
        end = time.time()
        if out.text.strip() == SLEEP_TEXT and (end - start) >= SLEEP_TIME:
            print("SLEEP TEST PASSED")
            tests_passed += 1
        else:
            print("SLEEP TEST FAILED")
        print("--------------------------------------------\n")

        # Test multithreading
        print("--------------------------------------------")
        sleep_path = "/sleep"
        static_path = "/static/test.txt"
        start = time.time()
        try:
            requests.get(SERVER_URL + ':' + SERVER_PORT + sleep_path, timeout=0.0000000001)
        except requests.exceptions.ReadTimeout: 
            pass
        out = requests.get(SERVER_URL + ':' + SERVER_PORT + static_path)
        end = time.time()
        if out.text.strip() == STATIC_TEXT and (end - start) <= SLEEP_TIME:
            print("MULTITHREADING TEST PASSED")
            tests_passed += 1
        else:
            print("MULTITHREADING TEST FAILED")
        print("--------------------------------------------\n")

        # Test CRUD POST request
        print("--------------------------------------------")
        path = "/api/Test"
        response = requests.post(SERVER_URL + ":" + SERVER_PORT + path)
        json_response = json.loads(response.text)
        if response.status_code == 201 and json_response.get("id") == 1:
            print("CRUD POST TEST PASSED")
            tests_passed += 1
        else:
            print("CRUD POST TEST FAILED")
            print(response.text)
        print("--------------------------------------------\n")

        # Test CRUD GET request
        print("--------------------------------------------")
        path = "/api/Test/1" 
        response = requests.get(SERVER_URL + ":" + SERVER_PORT + path)
        json_response = json.loads(response.text)
        if response.status_code == 200:
            print("CRUD GET TEST PASSED")
            tests_passed += 1
        else:
            print("CRUD GET TEST FAILED")
            print(response.text)
        print("--------------------------------------------\n")

        # Test CRUD PUT request
        print("--------------------------------------------")
        path = "/api/Test/1" 
        put_response = requests.put(SERVER_URL + ":" + SERVER_PORT + path)
        get_response = requests.get(SERVER_URL + ":" + SERVER_PORT + path)
        json_response = json.loads(get_response.text)
        if put_response.status_code == 200 and get_response.status_code == 200:
            print("CRUD PUT TEST PASSED")
            tests_passed += 1
        else:
            print("CRUD PUT TEST FAILED")
            print(put_response.text)
            print(get_response.text)
        print("--------------------------------------------\n")

        # Test CRUD LIST request
        print("--------------------------------------------")
        path = "/api/Test"
        response = requests.get(SERVER_URL + ":" + SERVER_PORT + path)
        json_response = json.loads(response.text)
        if response.status_code == 200 and json_response.get("valid_ids") == [1]:
            print("CRUD LIST TEST PASSED")
            tests_passed += 1
        else:
            print("CRUD LIST TEST FAILED")
            print(response.text)
        print("--------------------------------------------\n")

        # Test CRUD DELETE request
        print("--------------------------------------------")
        path = "/api/Test/1" 
        delete_response = requests.delete(SERVER_URL + ":" + SERVER_PORT + path)
        get_response = requests.get(SERVER_URL + ":" + SERVER_PORT + path)
        if delete_response.status_code == 200 and get_response.status_code == 404:
            print("CRUD DELETE TEST PASSED")
            tests_passed += 1
        else:
            print("CRUD DELETE TEST FAILED")
            print(delete_response.text)
            print(get_response.text)
        print("--------------------------------------------")

        # Test Health Request
        print("--------------------------------------------")
        path = "/health" 
        out = requests.get(SERVER_URL + ':' + SERVER_PORT + path)
        if out.text.strip() == "OK" and out.status_code == 200:
            print("HEALTH TEST PASSED")
            tests_passed += 1
        else:
            print("HEALTH TEST FAILED")
        print("--------------------------------------------")
    except:
        return 1
    
    # Shut down the server
    print("SHUTTING DOWN WEBSERVER...")
    server.stop()

    # Return Test Results
    print(f"{tests_passed} / {NUM_TESTS} INTEGRATION TESTS PASSED")
    if tests_passed == NUM_TESTS:
        return 0
    else:
        return 1

if __name__ == "__main__":
    res = integration_test()
    sys.exit(res)