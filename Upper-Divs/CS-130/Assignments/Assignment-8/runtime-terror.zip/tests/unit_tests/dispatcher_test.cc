#include <boost/lexical_cast.hpp>
#include "gtest/gtest.h"
#include "config_parser.h"
#include "dispatcher.h"
#include "mock_logger.h"

// Test fixture
class DispatcherTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;

    std::string GetResponseString(const std::string &request_str, std::string body = "")
    {
        Dispatcher dispatcher(config_, std::make_shared<MockLogger>());
        http::request_parser<http::string_body> parser;
        boost::system::error_code ec;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        request.body() = body;
        http::response<http::string_body> response = dispatcher.DispatchRequest(request, "0.0.0.0");
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(DispatcherTest, EchoRequest)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/echo_handler_config", &config_);
    std::string response_str = GetResponseString("GET /echo HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 24\r\n\r\nGET /echo HTTP/1.1\r\n\r\n\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, StaticRequest)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/static_handler_config", &config_);
    std::string response_str = GetResponseString("GET /static/test.txt HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 52\r\n\r\nThis is a test file for .txt extension in /static.\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, NotFoundRequest)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/not_found_handler_config", &config_);
    std::string response_str = GetResponseString("GET / HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 15\r\n\r\n404 Not Found\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, CRUDRequest)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/crud_handler_config", &config_);
    std::string response_str = GetResponseString("POST /api/Entity HTTP/1.1\r\n", "{\"test\": 0}");
    std::string expected_res = "HTTP/1.1 201 Created\r\nContent-Type: application/json\r\nContent-Length: 17\r\n\r\n{\n    \"id\": 1\n}\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, MissingFilesystem)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/missing_fs_config", &config_);
    std::string response_str = GetResponseString("POST /api/Entity HTTP/1.1\r\n", "{\"test\": 0}");
    std::string expected_res = "HTTP/1.1 201 Created\r\nContent-Type: application/json\r\nContent-Length: 17\r\n\r\n{\n    \"id\": 1\n}\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, BadHandler)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/missing_location_config", &config_);
    std::string response_str = GetResponseString("GET /not_a_location HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 55\r\n\r\nNo handler has been assigned to serve /not_a_location\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, SleepRequest)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/sleep_handler_config", &config_);
    std::string response_str = GetResponseString("GET /sleep HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 28\r\n\r\nThread slept for 0 seconds\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, InvalidSleepTime)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/invalid_sleep_time_config", &config_);
    std::string response_str = GetResponseString("GET /sleep HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 59\r\n\r\nThe handler serving /sleep has been configured improperly\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, NonNumericSleepTime)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/non_numeric_sleep_time_config", &config_);
    std::string response_str = GetResponseString("GET /sleep HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 59\r\n\r\nThe handler serving /sleep has been configured improperly\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, HealthRequest)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/health_handler_config", &config_);
    std::string response_str = GetResponseString("GET /health HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 4\r\n\r\nOK\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, LongestPrefixMatching)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/longest_prefix_config", &config_);
    std::string response_str = GetResponseString("GET /a/b HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 23\r\n\r\nGET /a/b HTTP/1.1\r\n\r\n\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, MissingSlash)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/echo_handler_config", &config_);
    std::string response_str = GetResponseString("GET echo HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 44\r\n\r\nNo handler has been assigned to serve echo\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, TrailingSlash)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/trailing_slash_config", &config_);
    std::string response_str = GetResponseString("GET /static/test.txt HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 52\r\n\r\nThis is a test file for .txt extension in /static.\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, MissingKeyword)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/missing_keyword_config", &config_);
    std::string response_str = GetResponseString("GET /static/test.txt HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 69\r\n\r\nThe handler serving /static/test.txt has been configured improperly\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, DuplicateHandler)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/duplicate_handler_config", &config_);
    std::string response_str = GetResponseString("GET /echo HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 24\r\n\r\nGET /echo HTTP/1.1\r\n\r\n\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, UnknownHandler)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/unknown_handler_config", &config_);
    std::string response_str = GetResponseString("GET /unknown HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 48\r\n\r\nNo handler has been assigned to serve /unknown\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, InvalidVerb)
{
    parser_.Parse("../tests/unit_tests/mocks/dispatcher/missing_keyword_config", &config_);
    std::string response_str = GetResponseString("NOT /static/test.txt HTTP/1.1\r\n");
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 22\r\n\r\nInvalid HTTP request\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, ValidateRequestVersion)
{
    Dispatcher dispatcher(config_, std::make_shared<MockLogger>());
    http::request<http::string_body> invalid_request;
    invalid_request.method(http::verb::get);
    invalid_request.target("/");
    invalid_request.version(19);
    EXPECT_FALSE(dispatcher.ValidateRequest(invalid_request));
}

TEST_F(DispatcherTest, ValidateRequestContentLength)
{
    Dispatcher dispatcher(config_, std::make_shared<MockLogger>());
    http::request<http::string_body> invalid_request;
    invalid_request.method(http::verb::get);
    invalid_request.target("/");
    invalid_request.version(11);
    std::string request_body = "This is the request body";
    invalid_request.body() = request_body;
    invalid_request.content_length(6);
    EXPECT_FALSE(dispatcher.ValidateRequest(invalid_request));
}
