#include "gtest/gtest.h"
#include "config_parser.h"
#include "mock_logger.h"
#include "session.h"

// Test fixture
class SessionTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
    boost::asio::io_service io_service_;
    std::shared_ptr<Logger> logger_ = std::make_shared<MockLogger>();
};

// Unit tests
TEST_F(SessionTest, Start)
{
    parser_.Parse("../tests/unit_tests/mocks/session/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    std::shared_ptr<session> test_session = std::make_shared<session>(io_service_, dispatcher, logger_);
    test_session->start();
    EXPECT_TRUE(test_session->started);
}

TEST_F(SessionTest, HandleRead)
{
    parser_.Parse("../tests/unit_tests/mocks/session/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    std::shared_ptr<session> test_session = std::make_shared<session>(io_service_, dispatcher, logger_);
    const std::string request = "GET /echo HTTP/1.1\r\n";
    std::strcpy(test_session->data_, request.c_str());
    test_session->handle_read(boost::system::error_code(), request.size());
    EXPECT_GT(test_session->response_str.size(), 0);
}

TEST_F(SessionTest, HandleReadError)
{
    parser_.Parse("../tests/unit_tests/mocks/session/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    std::shared_ptr<session> test_session = std::make_shared<session>(io_service_, dispatcher, logger_);
    const std::string request = "GET /echo HTTP/1.1\r\n";
    std::strcpy(test_session->data_, request.c_str());
    test_session->handle_read(boost::asio::error::operation_aborted, request.size());
    EXPECT_EQ(test_session->response_str.size(), 0);
}

TEST_F(SessionTest, HandleWrite)
{
    parser_.Parse("../tests/unit_tests/mocks/session/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    std::shared_ptr<session> test_session = std::make_shared<session>(io_service_, dispatcher, logger_);
    const std::string request = "GET /echo HTTP/1.1\r\n";
    std::strcpy(test_session->data_, request.c_str());
    test_session->handle_read(boost::system::error_code(), request.size());
    boost::system::error_code ec;
    test_session->handle_write(ec);
    EXPECT_TRUE(test_session->wrote);
}

TEST_F(SessionTest, HandleWriteError)
{
    parser_.Parse("../tests/unit_tests/mocks/session/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    std::shared_ptr<session> test_session = std::make_shared<session>(io_service_, dispatcher, logger_);
    const std::string request = "GET /echo HTTP/1.1\r\n";
    std::strcpy(test_session->data_, request.c_str());
    test_session->handle_read(boost::system::error_code(), request.size());
    test_session->handle_write(boost::asio::error::operation_aborted);
    EXPECT_FALSE(test_session->wrote);
}