#include "gtest/gtest.h"
#include "initializer.h"
#include "mock_logger.h"

// Test fixture
class InitializerTest : public ::testing::Test
{
protected:
    Initializer init_;
    std::shared_ptr<Logger> logger_ = std::make_shared<MockLogger>();
    char *arg_1_ = (char *)"webserver";
};

// Unit tests
TEST_F(InitializerTest, InvalidArgc)
{
    char *argv[] = {arg_1_};
    bool failure = init_.Initialize(1, argv, logger_);
    EXPECT_TRUE(failure);
}

TEST_F(InitializerTest, InvalidConfig)
{
    char *argv[] = {arg_1_, (char *)"not_a_config"};
    bool failure = init_.Initialize(2, argv, logger_);
    EXPECT_TRUE(failure);
}

TEST_F(InitializerTest, MissingPort)
{
    char *argv[] = {arg_1_, (char *)"../tests/unit_tests/mocks/initializer/missing_port_config"};
    bool failure = init_.Initialize(2, argv, logger_);
    EXPECT_TRUE(failure);
}

TEST_F(InitializerTest, InvalidPort)
{
    char *argv[] = {arg_1_, (char *)"../tests/unit_tests/mocks/initializer/invalid_port_config"};
    bool failure = init_.Initialize(2, argv, logger_);
    EXPECT_TRUE(failure);
}
