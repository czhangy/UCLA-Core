#include <boost/lexical_cast.hpp>
#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "mock_logger.h"
#include "static_handler.h"

using ::testing::HasSubstr;

// Test fixture
class StaticHandlerTest : public ::testing::Test
{
protected:
    std::string GetResponseString(const std::string &request_url)
    {
        std::string request_str = "GET " + request_url + " HTTP/1.1\r\n";
        StaticHandler static_handler = StaticHandler(request_url, "/static", "/tests/unit_tests/mocks/static_handler", std::make_shared<MockLogger>());
        boost::system::error_code ec;
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        static_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(StaticHandlerTest, HandleRequestSuccess)
{
    std::string response_str = GetResponseString("/static/test.txt");
    EXPECT_THAT(response_str, HasSubstr("This is a test file for .txt extension in /static."));
}

TEST_F(StaticHandlerTest, HandleRequestFail)
{
    std::string response_str = GetResponseString("/static/does_not_exist.txt");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(StaticHandlerTest, MIMETypeHTML)
{
    std::string response_str = GetResponseString("/static/test.html");
    EXPECT_THAT(response_str, HasSubstr("Content-Type: text/html"));
}

TEST_F(StaticHandlerTest, MIMETypeJPEG)
{
    std::string response_str = GetResponseString("/static/test.jpg");
    EXPECT_THAT(response_str, HasSubstr("Content-Type: image/jpeg"));
}

TEST_F(StaticHandlerTest, MIMETypeTXT)
{
    std::string response_str = GetResponseString("/static/test.txt");
    EXPECT_THAT(response_str, HasSubstr("Content-Type: text/plain"));
}

TEST_F(StaticHandlerTest, MIMETypeZIP)
{
    std::string response_str = GetResponseString("/static/test.zip");
    EXPECT_THAT(response_str, HasSubstr("Content-Type: application/zip"));
}

TEST_F(StaticHandlerTest, MIMETypeGIF_)
{
    std::string response_str = GetResponseString("/static/test.gif");
    EXPECT_THAT(response_str, HasSubstr("Content-Type: image/gif"));
}

TEST_F(StaticHandlerTest, MIMETypeOctetStream)
{
    std::string response_str = GetResponseString("/static/test.png");
    EXPECT_THAT(response_str, HasSubstr("Content-Type: application/octet-stream"));
}
