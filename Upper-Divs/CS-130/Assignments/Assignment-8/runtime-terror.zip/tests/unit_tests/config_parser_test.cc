#include "gtest/gtest.h"
#include "config_parser.h"

// Test fixture
class ParserTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig out_config_;
};

// Unit tests
TEST_F(ParserTest, SimpleDirective)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/simple_directive_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, BlockDirective)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/block_directive_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, NormalConfig)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/normal_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, MissingSemicolon)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/missing_semicolon_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingOpenBracket)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/missing_open_bracket_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingCloseBracket)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/missing_close_bracket_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, ExtraWhitespace)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/extra_whitespace_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EmptyConfig)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/empty_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, MissingToken)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/missing_token_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, EmptyBlockDirective)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/empty_block_directive_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, IgnoreComment)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/comment_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, ExtraSemicolon)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/extra_semicolon_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingTokenBlock)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/missing_token_block_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingWhitespaceQuote)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/missing_whitespace_quote_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, QuotedString)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/quoted_string_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EscapeSingleQuote)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/escape_single_quote_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EscapeDoubleQuote)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/escape_double_quote_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, PreserveBackslash)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/preserve_backslash_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, UnclosedQuote)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/unclosed_quote_config", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, FileDoesNotExist)
{
    bool failure = !parser_.Parse("../tests/unit_tests/mocks/config_parser/not_a_config", &out_config_);
    EXPECT_TRUE(failure);
}

// Test for ToString function
TEST_F(ParserTest, ConfigToString)
{
    bool success = parser_.Parse("../tests/unit_tests/mocks/config_parser/to_string_config", &out_config_);
    EXPECT_TRUE(success);
    EXPECT_EQ(out_config_.ToString(0), "http {\n  server {\n    listen 80;\n  }\n}\n");
}
