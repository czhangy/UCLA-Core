#include "gtest/gtest.h"
#include "config_parser.h"
#include "mock_logger.h"
#include "server.h"

// Test fixture
class ServerTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
    boost::asio::io_service io_service_;
    short port_ = 8080;
    int num_threads_ = 1;
    std::shared_ptr<Logger> logger_ = std::make_shared<MockLogger>();
};

// Unit tests
TEST_F(ServerTest, StartAccept)
{
    parser_.Parse("../tests/unit_tests/mocks/server/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    server test_server(io_service_, port_, num_threads_, dispatcher, logger_);
    test_server.start_accept();
    EXPECT_TRUE(test_server.started);
}

TEST_F(ServerTest, HandleAccept)
{
    parser_.Parse("../tests/unit_tests/mocks/server/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    server test_server(io_service_, port_, num_threads_, dispatcher, logger_);
    std::shared_ptr<session> test_session = std::make_shared<session>(io_service_, dispatcher, logger_);
    test_server.handle_accept(test_session, boost::system::error_code());
    EXPECT_TRUE(test_server.handled);
}

TEST_F(ServerTest, Run)
{
    parser_.Parse("../tests/unit_tests/mocks/server/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config_, logger_);
    server test_server(io_service_, port_, 0, dispatcher, logger_);
    bool success = test_server.run();
    EXPECT_TRUE(success);
}