#include <boost/lexical_cast.hpp>
#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "mock_logger.h"
#include "not_found_handler.h"

using ::testing::HasSubstr;

// Test fixture
class NotFoundHandlerTest : public ::testing::Test
{
protected:
    std::string GetResponseString(const std::string &request_url)
    {
        std::string request_str = "GET " + request_url + " HTTP/1.1\r\n";
        NotFoundHandler not_found_handler = NotFoundHandler(request_url, "/", std::make_shared<MockLogger>());
        boost::system::error_code ec;
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        not_found_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(NotFoundHandlerTest, GenerateResponse)
{
    std::string response_str = GetResponseString("/");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}