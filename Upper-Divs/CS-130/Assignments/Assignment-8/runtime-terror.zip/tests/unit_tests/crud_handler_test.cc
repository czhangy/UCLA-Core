#include <boost/lexical_cast.hpp>
#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "crud_handler.h"
#include "mock_filesystem.h"
#include "mock_logger.h"

using ::testing::HasSubstr;

// Test fixture
class CRUDHandlerTest : public ::testing::Test
{
protected:
    MockFilesystem::MockFile file_1_ = {1, "{\"content\": 1}"};
    MockFilesystem::MockFile file_2_ = {3, "{\"content\": 3}"};
    std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map_ = {
        {"Entity", {file_1_, file_2_}}};
    std::shared_ptr<MockFilesystem> fs_ = std::make_shared<MockFilesystem>(fs_map_);
    std::shared_ptr<std::mutex> map_guard_ = std::make_shared<std::mutex>();
    std::shared_ptr<mutex_map> mtx_map_ = std::make_shared<mutex_map>();

    std::string GetResponseString(std::string request_method, std::string request_url, std::string body = "")
    {
        std::string request_str = request_method + " " + request_url + " HTTP/1.1\r\n";
        CRUDHandler crud_handler(request_url, "/api", std::make_shared<MockLogger>(), fs_, map_guard_, mtx_map_);
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        boost::system::error_code ec;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        request.body() = body;
        crud_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(CRUDHandlerTest, HandleGet)
{
    std::string response_str = GetResponseString("GET", "/api/Entity/1");
    EXPECT_THAT(response_str, HasSubstr("200 OK"));
    EXPECT_THAT(response_str, HasSubstr("\"content\": 1"));
}

TEST_F(CRUDHandlerTest, HandleGetMissingTarget)
{
    std::string response_str = GetResponseString("GET", "/api/Entity/2");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(CRUDHandlerTest, HandlePost)
{
    std::string response_str = GetResponseString("POST", "/api/Entity", "{\"content\": 2}");
    EXPECT_TRUE(fs_->Exists("/Entity/2"));
    EXPECT_THAT(response_str, HasSubstr("201 Created"));
    EXPECT_THAT(response_str, HasSubstr("\"id\": 2"));
}

TEST_F(CRUDHandlerTest, HandlePostInvalidTarget)
{
    std::string post_id_response = GetResponseString("POST", "/api/Entity/1", "{\"content: 1}");
    std::string missing_entity_response = GetResponseString("POST", "/api/", "{\"content: 0}");
    EXPECT_THAT(post_id_response, HasSubstr("400 Bad Request"));
    EXPECT_THAT(missing_entity_response, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandlePostInvalidJSON)
{
    std::string response_str = GetResponseString("POST", "/api/Entity", "{\"content: 3}");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandlePut)
{
    std::string response_str = GetResponseString("PUT", "/api/Entity/1", "{\"content\": 2}");
    EXPECT_THAT(response_str, HasSubstr("200 OK"));
    EXPECT_THAT(response_str, HasSubstr("\"updated_id\": 1"));
}

TEST_F(CRUDHandlerTest, HandlePutMissingTarget)
{
    std::string response_str = GetResponseString("PUT", "/api/Entity/2", "{\"content\": 2}");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(CRUDHandlerTest, HandlePutInvalidTarget)
{
    std::string response_str = GetResponseString("PUT", "/api/Entity", "{\"content\": 0}");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandlePutInvalidJSON)
{
    std::string response_str = GetResponseString("PUT", "/api/Entity/1", "{\"content: 2}");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandleDelete)
{
    std::string response_str = GetResponseString("DELETE", "/api/Entity/1");
    EXPECT_THAT(response_str, HasSubstr("200 OK"));
    EXPECT_THAT(response_str, HasSubstr("\"deleted_id\": 1"));
}

TEST_F(CRUDHandlerTest, HandleDeleteMissingTarget)
{
    std::string response_str = GetResponseString("DELETE", "/api/Entity/2");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(CRUDHandlerTest, HandleDeleteInvalidTarget)
{
    std::string response_str = GetResponseString("DELETE", "/api/Entity");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandleList)
{
    std::string response_str = GetResponseString("GET", "/api/Entity");
    EXPECT_THAT(response_str, HasSubstr("200 OK"));
}

TEST_F(CRUDHandlerTest, HandleListMissingTarget)
{
    std::string response_str = GetResponseString("GET", "/api/NotEntity");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(CRUDHandlerTest, HandleRequestMissingEntity)
{
    std::string response_str = GetResponseString("GET", "/api");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandleRequestInvalidID)
{
    std::string response_str = GetResponseString("GET", "/api/Entity/abc");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(CRUDHandlerTest, HandleRequestNotImplemented)
{
    std::string response_str = GetResponseString("BAD", "/api/Entity");
    EXPECT_THAT(response_str, HasSubstr("501 Not Implemented"));
}
