#pragma once

#include <memory>
#include <string>
#include "logger.h"
#include "not_found_handler.h"
#include "request_handler_factory.h"

class NotFoundHandlerFactory : public RequestHandlerFactory
{
public:
    NotFoundHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;
};
