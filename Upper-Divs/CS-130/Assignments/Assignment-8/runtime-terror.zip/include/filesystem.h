#pragma once

#include <boost/lexical_cast.hpp>
#include <string>
#include <vector>

class Filesystem
{
public:
    std::string GetEntityName(const std::string &entity_path) const;
    int GetEntityID(const std::string &entity_path, const std::string &entity_name) const;

    virtual bool CreateDataPathDir() = 0;
    virtual bool Exists(const std::string &entity_path) = 0;
    virtual bool CreateDirectory(const std::string &entity_path) = 0;
    virtual std::vector<int> GetAllEntityIDs(const std::string &entity_path) = 0;
    virtual bool CreateFile(const std::string &entity_path, const std::string &content) = 0;
    virtual std::string GetData(const std::string &entity_path) = 0;
    virtual bool DeleteFile(const std::string &entity_path) = 0;
};