#pragma once

#include <boost/asio.hpp>
#include <cstdlib>
#include <string>
#include <iostream>
#include <memory>
#include <vector>
#include "config_parser.h"
#include "dispatcher.h"
#include "real_logger.h"
#include "nginx_config.h"
#include "server.h"

class Initializer
{
public:
    int Initialize(int argc, char *argv[], std::shared_ptr<Logger> server_logger) const;
};
