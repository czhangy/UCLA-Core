#pragma once

#include <memory>
#include <string>
#include "logger.h"
#include "health_handler.h"
#include "request_handler_factory.h"

class HealthHandlerFactory : public RequestHandlerFactory
{
public:
    HealthHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;
};