#pragma once

#include <cstdlib>
#include <memory>
#include <string>
#include "logger.h"
#include "nginx_config.h"
#include "not_found_handler.h"
#include "request_handler_factory.h"
#include "sleep_handler.h"

class SleepHandlerFactory : public RequestHandlerFactory
{
public:
    SleepHandlerFactory(const std::string &location, const NginxConfig &config,
                        std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;

private:
    bool IsValidSleepTime() const;
    std::string time_;
};
