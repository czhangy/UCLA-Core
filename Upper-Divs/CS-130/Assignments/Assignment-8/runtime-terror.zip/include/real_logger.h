#pragma once

#include <boost/filesystem.hpp>
#include <boost/log/common.hpp>
#include <boost/log/keywords/file_name.hpp>
#include <boost/log/keywords/format.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/utility/setup.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <string>
#include "logger.h"

class RealLogger : public Logger
{
public:
    RealLogger();
    void LogTrace(std::string message);
    void LogDebug(std::string message);
    void LogInfo(std::string message);
    void LogWarning(std::string message);
    void LogError(std::string message);
    void LogFatal(std::string message);

private:
    void Init();
    std::string GenerateLogFilePath();
    std::string dir_ = "../logs/";
    int rotation_size_ = 10 * 1000 * 1000;
};