#pragma once

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread/thread.hpp>
#include <memory>
#include <vector>
#include "dispatcher.h"
#include "logger.h"
#include "session.h"

using boost::asio::ip::tcp;

class server
{
public:
    server(boost::asio::io_service &io_service, unsigned short port, std::size_t thread_pool_size, std::shared_ptr<Dispatcher> dispatcher, std::shared_ptr<Logger> logger);
    bool run();
    void start_accept();
    void handle_accept(std::shared_ptr<session> new_session,
                       const boost::system::error_code &error);

    // Testing flags
    bool started = false;
    bool handled = false;

private:
    boost::asio::io_service &io_service_;
    tcp::acceptor acceptor_;
    std::size_t thread_pool_size_;
    std::shared_ptr<Dispatcher> dispatcher_;
    std::shared_ptr<Logger> logger_;
};