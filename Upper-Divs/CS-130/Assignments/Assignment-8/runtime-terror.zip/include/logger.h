#pragma once

#include <string>

class Logger
{
public:
    virtual void LogTrace(std::string message) = 0;
    virtual void LogDebug(std::string message) = 0;
    virtual void LogInfo(std::string message) = 0;
    virtual void LogWarning(std::string message) = 0;
    virtual void LogError(std::string message) = 0;
    virtual void LogFatal(std::string message) = 0;
};