#pragma once

#include <iostream>
#include <string>
#include "logger.h"

class MockLogger : public Logger
{
public:
    void LogTrace(std::string message);
    void LogDebug(std::string message);
    void LogInfo(std::string message);
    void LogWarning(std::string message);
    void LogError(std::string message);
    void LogFatal(std::string message);
};