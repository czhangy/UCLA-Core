#pragma once

#include <boost/beast/http.hpp>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include "crud_handler.h"
#include "boost_filesystem.h"
#include "mock_filesystem.h"
#include "request_handler.h"
#include "request_handler_factory.h"
#include "nginx_config.h"

namespace http = boost::beast::http;
typedef std::unordered_map<std::string, std::shared_ptr<std::mutex>> mutex_map;

class CRUDHandlerFactory : public RequestHandlerFactory
{
public:
    CRUDHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;

private:
    const std::string kBoost = "boost";
    const std::string kMock = "mock";

    std::string data_path_;
    std::string filesystem_;
    std::shared_ptr<std::mutex> map_guard_;
    std::shared_ptr<mutex_map> mtx_map_;
};