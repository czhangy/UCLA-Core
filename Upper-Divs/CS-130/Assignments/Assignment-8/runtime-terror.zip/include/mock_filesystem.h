#pragma once

#include <unordered_map>
#include <string>
#include <vector>
#include "filesystem.h"

class MockFilesystem : public Filesystem
{
public:
    struct MockFile
    {
        int id;
        std::string content;
    };

    MockFilesystem(const std::unordered_map<std::string, std::vector<MockFile>> &fs);
    bool CreateDataPathDir();
    bool Exists(const std::string &entity_path);
    bool CreateDirectory(const std::string &entity_path);
    std::vector<int> GetAllEntityIDs(const std::string &entity_path);
    bool CreateFile(const std::string &entity_path, const std::string &content);
    std::string GetData(const std::string &entity_path);
    bool DeleteFile(const std::string &entity_path);

private:
    std::unordered_map<std::string, std::vector<MockFile>> fs_;
};