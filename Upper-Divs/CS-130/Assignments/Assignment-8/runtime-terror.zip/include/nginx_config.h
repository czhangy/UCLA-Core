#pragma once

#include <climits>
#include <iostream>
#include <memory>
#include <queue>
#include <string>
#include <vector>

class NginxConfig;

class NginxConfigStatement
{
public:
    std::string ToString(int depth);
    std::vector<std::string> tokens_;
    std::unique_ptr<NginxConfig> child_block_;
};

class NginxConfig
{
public:
    unsigned short GetServerKeyword(std::string keyword) const;
    std::string GetKeyword(std::string keyword) const;
    std::string ToString(int depth = 0);
    std::vector<std::shared_ptr<NginxConfigStatement>> statements_;
};