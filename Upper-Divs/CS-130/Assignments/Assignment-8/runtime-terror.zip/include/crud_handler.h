#pragma once

#include <boost/beast/http.hpp>
#include <boost/filesystem.hpp>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <string>
#include <unordered_map>
#include <vector>
#include "filesystem.h"
#include "request_handler.h"

namespace fs = boost::filesystem;
namespace http = boost::beast::http;
typedef nlohmann::json json;
typedef std::unordered_map<std::string, std::shared_ptr<std::mutex>> mutex_map;

class CRUDHandler : public RequestHandler
{
public:
    CRUDHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger,
                std::shared_ptr<Filesystem> fs, std::shared_ptr<std::mutex> map_guard, std::shared_ptr<mutex_map> mtx_map);
    http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const;

private:
    const int kIndentSize = 4;

    std::shared_ptr<Filesystem> fs_;
    std::shared_ptr<std::mutex> map_guard_;
    std::shared_ptr<mutex_map> mtx_map_;

    std::shared_ptr<std::mutex> GetLock(const std::string &entity_name) const;
    http::status HandleGet(const std::string &entity_path, http::response<http::string_body> &response) const;
    http::status HandlePost(const std::string &entity_path, const std::string &body, http::response<http::string_body> &response) const;
    http::status HandlePut(const std::string &entity_path, const std::string &body, http::response<http::string_body> &response) const;
    http::status HandleDelete(const std::string &entity_path, http::response<http::string_body> &response) const;
    http::status HandleList(const std::string &entity_path, http::response<http::string_body> &response) const;
    http::status HandleErrorResponse(http::status status, std::string error_msg, http::response<http::string_body> &response) const;
};