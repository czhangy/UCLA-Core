#include "not_found_handler.h"

NotFoundHandler::NotFoundHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger) {}

http::status NotFoundHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    logger_->LogInfo("Generated 404 response");
    response.result(http::status::not_found);
    response.set(http::field::content_type, "text/plain");
    response.body() = "404 Not Found\r\n";
    response.prepare_payload();
    return response.result();
}
