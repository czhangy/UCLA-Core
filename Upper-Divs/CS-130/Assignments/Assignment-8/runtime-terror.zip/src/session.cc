#include "session.h"

session::session(boost::asio::io_service &io_service, std::shared_ptr<Dispatcher> dispatcher, std::shared_ptr<Logger> logger)
    : socket_(io_service),
      dispatcher_(dispatcher),
      logger_(logger) {}

tcp::socket &session::socket()
{
    return socket_;
}

void session::start()
{
    socket_.async_read_some(boost::asio::buffer(data_, max_length),
                            boost::bind(&session::handle_read, shared_from_this(),
                                        boost::asio::placeholders::error,
                                        boost::asio::placeholders::bytes_transferred));
    started = true;
}

void session::handle_read(const boost::system::error_code &error,
                          size_t bytes_transferred)
{
    if (!error)
    {
        // Get request
        boost::system::error_code parse_ec;
        std::string new_str(data_, bytes_transferred);
        request_str_ += new_str;

        // Check if finished reading
        if (socket_.is_open() && socket_.available())
        {
            // Continue reading
            socket_.async_read_some(boost::asio::buffer(data_, max_length),
                                    boost::bind(&session::handle_read, this,
                                                boost::asio::placeholders::error,
                                                boost::asio::placeholders::bytes_transferred));
        }
        else
        {
            // Finished reading
            http::request_parser<http::string_body> parser;
            parser.eager(true);
            parser.put(boost::asio::buffer(request_str_), parse_ec);
            http::request<http::string_body> request = std::move(parser.get());

            // Get request IP
            std::string client_ip = "Unknown";
            try
            {
                client_ip = socket_.remote_endpoint().address().to_string();
                logger_->LogInfo("Request IP: " + client_ip);
            }
            catch (boost::system::system_error const &e)
            {
                std::cout << e.what() << ": " << e.code() << " - " << e.code().message() << std::endl;
            }

            // Get response
            http::response<http::string_body> response = dispatcher_->DispatchRequest(request, client_ip);
            response_str = boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());

            // Write response to socket
            boost::asio::async_write(socket_,
                                     boost::asio::buffer(response_str.c_str(), response_str.size()),
                                     boost::bind(&session::handle_write, shared_from_this(),
                                                 boost::asio::placeholders::error));
        }
    }
    else
    {
        logger_->LogInfo("Server session terminated");
    }
}

void session::handle_write(const boost::system::error_code &error)
{
    if (!error)
    {
        wrote = true;
        socket_.async_read_some(boost::asio::buffer(data_, max_length),
                                boost::bind(&session::handle_read, this,
                                            boost::asio::placeholders::error,
                                            boost::asio::placeholders::bytes_transferred));
    }
    else
    {
        logger_->LogInfo("Server session terminated");
    }
}
