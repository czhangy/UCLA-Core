#include "not_found_handler_factory.h"

NotFoundHandlerFactory::NotFoundHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger) {}

std::shared_ptr<RequestHandler> NotFoundHandlerFactory::Create(const std::string &url) const
{
    return std::shared_ptr<RequestHandler>(new NotFoundHandler(url, location_, logger_));
}
