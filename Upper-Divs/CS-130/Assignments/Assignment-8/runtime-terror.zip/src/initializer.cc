#include "initializer.h"

int Initializer::Initialize(int argc, char *argv[], std::shared_ptr<Logger> server_logger) const
{
    try
    {
        // Create logger
        std::shared_ptr<Logger> logger = server_logger;

        // Check for valid args
        if (argc != 2)
        {
            logger->LogFatal("Invalid args! Correct usage: <webserver> <config>");
            return 1;
        }

        // Parse the config file
        NginxConfigParser config_parser;
        NginxConfig config;
        if (!config_parser.Parse(argv[1], &config))
        {
            logger->LogFatal("Invalid config file");
            return 1;
        }

        // Extract server info
        unsigned short port = config.GetServerKeyword("listen");
        unsigned short thread_pool_size = config.GetServerKeyword("threads");
        if (port == 0)
        {
            logger->LogFatal("Valid port not found");
            return 1;
        }
        if (thread_pool_size == 0)
        {
            logger->LogWarning("No valid thread pool size found, defaulting to single-thread");
            thread_pool_size = 1;
        }

        // Log server info
        logger->LogInfo("Listening on port: " + std::to_string(port));
        logger->LogInfo("Initializing server with thread pool size: " + std::to_string(thread_pool_size));

        // Create dispatcher
        std::shared_ptr<Dispatcher> dispatcher = std::make_shared<Dispatcher>(config, logger);

        // Start server
        boost::asio::io_service io_service;
        server s(io_service, port, thread_pool_size, dispatcher, logger);
        s.run();
    }
    catch (std::exception &e)
    {
        std::cerr << "Exception: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
