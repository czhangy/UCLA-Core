#include "request_handler.h"

RequestHandler::RequestHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger)
    : url_(url),
      location_(location),
      logger_(logger) {}