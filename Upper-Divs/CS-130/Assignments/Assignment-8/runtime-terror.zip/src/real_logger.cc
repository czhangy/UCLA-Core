#include "real_logger.h"

namespace attrs = boost::log::attributes;
namespace expr = boost::log::expressions;
namespace keywords = boost::log::keywords;
namespace logging = boost::log;
namespace sinks = boost::log::sinks;
namespace src = boost::log::sources;

RealLogger::RealLogger()
{
    Init();
}

void RealLogger::Init()
{
    // Set format
    logging::register_simple_formatter_factory<logging::trivial::severity_level, char>("Severity");
    logging::add_common_attributes();

    // Format for messages
    std::string message_format = "[%TimeStamp%] [%ThreadID%] [%Severity%]: %Message%";

    // Add file for logging
    logging::add_file_log(
        keywords::target = dir_,
        keywords::file_name = GenerateLogFilePath(),
        keywords::rotation_size = rotation_size_,                                     // rotate once file hits 10 mb
        keywords::time_based_rotation = sinks::file::rotation_at_time_point(0, 0, 0), // rotate at midnight
        keywords::format = message_format,
        keywords::open_mode = std::ios_base::app, // append to file
        keywords::auto_flush = true,              // flushes buffer after each new log record
        keywords::filter = (logging::trivial::severity >= logging::trivial::info));

    // Log to console as well
    logging::add_console_log(
        std::cout,
        keywords::format = message_format,
        keywords::filter = (logging::trivial::severity >= logging::trivial::info));
}

std::string RealLogger::GenerateLogFilePath()
{
    char buffer[80];
    std::time_t now = std::time(nullptr);
    std::strftime(buffer, 80, "%y_%m_%d", localtime(&now));
    std::string result(buffer);
    std::string path = dir_ + result + ".log";
    return path;
}

void RealLogger::LogTrace(std::string message)
{
    BOOST_LOG_TRIVIAL(trace) << message;
}

void RealLogger::LogDebug(std::string message)
{
    BOOST_LOG_TRIVIAL(debug) << message;
}

void RealLogger::LogInfo(std::string message)
{
    BOOST_LOG_TRIVIAL(info) << message;
}

void RealLogger::LogWarning(std::string message)
{
    BOOST_LOG_TRIVIAL(warning) << message;
}

void RealLogger::LogError(std::string message)
{
    BOOST_LOG_TRIVIAL(error) << message;
}

void RealLogger::LogFatal(std::string message)
{
    BOOST_LOG_TRIVIAL(fatal) << message;
}