#include "crud_handler.h"

CRUDHandler::CRUDHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger,
                         std::shared_ptr<Filesystem> fs, std::shared_ptr<std::mutex> map_guard, std::shared_ptr<mutex_map> mtx_map)
    : RequestHandler(url, location, logger),
      fs_(fs),
      map_guard_(map_guard),
      mtx_map_(mtx_map) {}

http::status CRUDHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    logger_->LogInfo("CRUDHandler: handling " + boost::lexical_cast<std::string>(request.method_string()) +
                     " request for " + request.target().to_string());
    response.set(http::field::content_type, "application/json");

    // Invalid method
    if (request.method() != http::verb::get && request.method() != http::verb::post &&
        request.method() != http::verb::put && request.method() != http::verb::delete_)
    {
        logger_->LogInfo("CRUDHandler: method " + boost::lexical_cast<std::string>(request.method_string()) + " is not implemented");
        return HandleErrorResponse(http::status::not_implemented,
                                   "The method " + boost::lexical_cast<std::string>(request.method_string()) + " is not implemented",
                                   response);
    }

    // Construct entity path from target (target - location) and remove trailing backslashes
    std::string entity_path = request.target().to_string().substr(location_.size());
    while (entity_path[entity_path.size() - 1] == '/')
    {
        entity_path.pop_back();
    }

    // Make sure an entity is specified
    std::string entity_name = fs_->GetEntityName(entity_path);
    if (entity_name.empty())
    {
        logger_->LogInfo("CRUDHandler: no entity was provided");
        return HandleErrorResponse(http::status::bad_request, "An entity name must be specified", response);
    }

    // Make sure entity ID is valid if it exists
    int entity_id = fs_->GetEntityID(entity_path, entity_name);
    if (entity_id == -1)
    {
        logger_->LogInfo("CRUDHandler: contains an invalid entity ID");
        return HandleErrorResponse(http::status::bad_request, "Entity IDs must be numeric", response);
    }

    // Make sure non-GET/POST requests specify an entity ID
    if (request.method() != http::verb::get && request.method() != http::verb::post && entity_id == 0)
    {
        logger_->LogInfo("CRUDHandler: " + entity_path + " is missing an entity ID for " + boost::lexical_cast<std::string>(request.method_string()) + " request");
        return HandleErrorResponse(http::status::bad_request, boost::lexical_cast<std::string>(request.method_string()) + " requests require a numeric entity ID", response);
    }

    // Lock entity before accessing filesystem
    std::shared_ptr<std::mutex> entity_guard = GetLock(entity_name);
    std::lock_guard<std::mutex> guard(*entity_guard);

    // Make sure the target exists for non-POST requests
    if (request.method() != http::verb::post && !fs_->Exists(entity_path))
    {
        logger_->LogInfo("CRUDHandler: " + entity_path + " was requested and does not exist");
        return HandleErrorResponse(http::status::not_found, entity_path + " does not exist", response);
    }

    // Attempt to process request
    switch (request.method())
    {
    case http::verb::get:
        return entity_id == 0 ? HandleList(entity_path, response) : HandleGet(entity_path, response);
    case http::verb::post:
        return HandlePost(entity_path, request.body(), response);
    case http::verb::put:
        return HandlePut(entity_path, request.body(), response);
    case http::verb::delete_:
        return HandleDelete(entity_path, response);
    default:
        return HandleErrorResponse(http::status::internal_server_error, "", response);
    }
}

std::shared_ptr<std::mutex> CRUDHandler::GetLock(const std::string &entity_name) const
{
    std::lock_guard<std::mutex> guard(*map_guard_);
    auto it = mtx_map_->find(entity_name);
    if (it == mtx_map_->end())
    {
        it = mtx_map_->emplace(entity_name, std::make_shared<std::mutex>()).first;
    }
    return it->second;
}

http::status CRUDHandler::HandleGet(const std::string &entity_path, http::response<http::string_body> &response) const
{
    // Read data from requested file
    std::string data = fs_->GetData(entity_path);

    // Prepare HTTP response
    logger_->LogInfo("CRUDHandler: handled GET request, sending response");
    response.result(http::status::ok);
    response.body() = data + "\r\n";
    response.prepare_payload();
    return http::status::ok;
}

http::status CRUDHandler::HandlePost(const std::string &entity_path, const std::string &body, http::response<http::string_body> &response) const
{
    // Check for valid target
    std::string entity_name = fs_->GetEntityName(entity_path);
    int id = fs_->GetEntityID(entity_path, entity_name);
    if (id != 0)
    {
        logger_->LogInfo("CRUDHandler: " + entity_path + " is an invalid target for POST");
        return HandleErrorResponse(http::status::bad_request, "POST requests require an entity name without an ID", response);
    }

    // Check for valid JSON body
    if (!body.empty() && !json::accept(body))
    {
        logger_->LogInfo("CRUDHandler: request did not send valid JSON");
        return HandleErrorResponse(http::status::bad_request, "POST requests require valid JSON content", response);
    }
    json json_content = body.empty() ? json::parse("{}") : json::parse(body);

    // Make directory if it doesn't exist
    if (!fs_->Exists(entity_path))
    {
        logger_->LogInfo("CRUDHandler: " + entity_name + " does not exist, creating directory");
        if (!fs_->CreateDirectory(entity_path))
        {
            logger_->LogError("CRUDHandler: failed to create directory for " + entity_path);
            return HandleErrorResponse(http::status::internal_server_error, "Failed to create entity", response);
        }
    }

    // Get next available ID for entity
    std::vector<int> entity_ids = fs_->GetAllEntityIDs(entity_path);
    int next_id = 1;
    for (int id : entity_ids)
    {
        if (id != next_id)
        {
            break;
        }
        next_id++;
    }
    std::string entity_id_path = entity_path + "/" + std::to_string(next_id);

    // Create file using new ID
    if (!fs_->CreateFile(entity_id_path, json_content.dump(kIndentSize)))
    {
        logger_->LogError("CRUDHandler: failed to create file for " + entity_id_path);
        return HandleErrorResponse(http::status::internal_server_error, "Failed to create entity", response);
    }

    // Prepare JSON response
    json json_res;
    json_res["id"] = next_id;

    // Prepare HTTP response
    logger_->LogInfo("CRUDHandler: handled POST request, sending response");
    response.result(http::status::created);
    response.body() = json_res.dump(kIndentSize) + "\r\n";
    response.prepare_payload();
    return http::status::created;
}

http::status CRUDHandler::HandlePut(const std::string &entity_path, const std::string &body, http::response<http::string_body> &response) const
{
    // Check for valid JSON body
    if (!body.empty() && !json::accept(body))
    {
        logger_->LogInfo("CRUDHandler: request did not send valid JSON");
        return HandleErrorResponse(http::status::bad_request, "PUT requests require valid JSON content", response);
    }
    json json_content = body.empty() ? json::parse("{}") : json::parse(body);

    // Update file using new JSON content
    if (!fs_->CreateFile(entity_path, json_content.dump(kIndentSize)))
    {
        logger_->LogError("CRUDHandler: failed to update file for " + entity_path);
        return HandleErrorResponse(http::status::internal_server_error, "Failed to update entity", response);
    }

    // Prepare JSON response
    json json_res;
    json_res["updated_id"] = fs_->GetEntityID(entity_path, fs_->GetEntityName(entity_path));

    // Prepare HTTP response
    logger_->LogInfo("CRUDHandler: handled PUT request, sending response");
    response.result(http::status::ok);
    response.body() = json_res.dump(kIndentSize) + "\r\n";
    response.prepare_payload();
    return http::status::ok;
}

http::status CRUDHandler::HandleDelete(const std::string &entity_path, http::response<http::string_body> &response) const
{
    // Update file using new JSON content
    if (!fs_->DeleteFile(entity_path))
    {
        logger_->LogError("CRUDHandler: failed to delete file for " + entity_path);
        return HandleErrorResponse(http::status::internal_server_error, "Failed to delete entity", response);
    }

    // Prepare JSON response
    json json_res;
    json_res["deleted_id"] = fs_->GetEntityID(entity_path, fs_->GetEntityName(entity_path));

    // Prepare HTTP response
    logger_->LogInfo("CRUDHandler: handled DELETE request, sending response");
    response.result(http::status::ok);
    response.body() = json_res.dump(kIndentSize) + "\r\n";
    response.prepare_payload();
    return http::status::ok;
}

http::status CRUDHandler::HandleList(const std::string &entity_path, http::response<http::string_body> &response) const
{
    // Prepare JSON response
    json json_res;
    json_res["valid_ids"] = fs_->GetAllEntityIDs(entity_path);

    // Prepare HTTP response
    logger_->LogInfo("CRUDHandler: handled LIST request, sending response");
    response.result(http::status::ok);
    response.body() = json_res.dump(kIndentSize) + "\r\n";
    response.prepare_payload();
    return http::status::ok;
}

http::status CRUDHandler::HandleErrorResponse(http::status status, std::string error_msg, http::response<http::string_body> &response) const
{
    logger_->LogInfo("CRUDHandler: request could not be handled, sending error response");
    json json_res;
    if (status == http::status::bad_request)
    {
        json_res["error"] = "400 Bad Request";
    }
    else if (status == http::status::not_found)
    {
        json_res["error"] = "404 Not Found";
    }
    else if (status == http::status::not_implemented)
    {
        json_res["error"] = "501 Not Implemented";
    }
    else
    {
        json_res["error"] = "500 Internal Server Error";
    }

    if (!error_msg.empty())
    {
        json_res["error-msg"] = error_msg;
    }
    response.result(status);
    response.body() = json_res.dump(kIndentSize) + "\r\n";
    response.prepare_payload();
    return status;
}
