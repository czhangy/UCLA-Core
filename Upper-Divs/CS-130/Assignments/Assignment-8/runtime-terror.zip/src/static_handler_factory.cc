#include "static_handler_factory.h"

StaticHandlerFactory::StaticHandlerFactory(const std::string &location,
                                           const NginxConfig &config,
                                           std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger)
{
    root_ = config.GetKeyword("root");
}

std::shared_ptr<RequestHandler> StaticHandlerFactory::Create(
    const std::string &url) const
{
    if (root_.empty())
    {
        logger_->LogWarning("The static handler serving " + location_ +
                            " is missing a root");
        return NULL;
    }
    else
    {
        return std::shared_ptr<RequestHandler>(
            new StaticHandler(url, location_, root_, logger_));
    }
}
