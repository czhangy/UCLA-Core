#include "request_handler_factory.h"

RequestHandlerFactory::RequestHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger)
    : location_(location), logger_(logger) {}