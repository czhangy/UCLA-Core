#!/bin/bash

EXPECTED_RES_PATH_1=../tests/integration_tests/files/expected_static_res_1
EXPECTED_RES_PATH_2=../tests/integration_tests/files/expected_static_res_2
TEST_RES_PATH_1=../tests/integration_tests/files/test_static_res_1
TEST_RES_PATH_2=../tests/integration_tests/files/test_static_res_2
SERVER_URL_1=http://localhost:8080/static1/test.txt
SERVER_URL_2=http://localhost:8080/static2/test.txt
CURL_VERSION=$(curl --version | head -n 1 | awk '{ print $2 }')

# Dynamically generate the expected response
echo "This is a test file for .txt extension in /static1." > "$EXPECTED_RES_PATH_1"

echo "This is a test file for .txt extension in /static2." > "$EXPECTED_RES_PATH_2"

# Send and capture the responses, allowing a maximum of 5s
timeout 5 curl -s "$SERVER_URL_1" > "$TEST_RES_PATH_1"
timeout 5 curl -s "$SERVER_URL_2" > "$TEST_RES_PATH_2"

# Compare expected and test outputs and capture diff
diff -w -B "$EXPECTED_RES_PATH_1" "$TEST_RES_PATH_1" &>/dev/null
DIFF=$?

# Output if test was successful
if [ "$DIFF" -eq 0 ]
then
    echo -e "\e[1;32mStatic test passed!\e[0m"
else
    echo -e "\e[1;31mStatic test failed!\e[0m"
    echo "---------------------------------------------"
    echo "Expected response:"
    cat "$EXPECTED_RES_PATH_1"
    echo "---------------------------------------------"
    echo "Actual response:"
    cat "$TEST_RES_PATH_1"
    echo "---------------------------------------------"
    exit "$DIFF"
fi

# Compare expected and test outputs and capture diff
diff -w -B "$EXPECTED_RES_PATH_2" "$TEST_RES_PATH_2" &>/dev/null
DIFF=$?

# Output if test was successful
if [ "$DIFF" -eq 0 ]
then
    echo -e "\e[1;32mStatic test passed!\e[0m"
else
    echo -e "\e[1;31mStatic test failed!\e[0m"
    echo "---------------------------------------------"
    echo "Expected response:"
    cat "$EXPECTED_RES_PATH_2"
    echo "---------------------------------------------"
    echo "Actual response:"
    cat "$TEST_RES_PATH_2"
    echo "---------------------------------------------"
fi

# Exit with corresponding code
exit "$DIFF"
