#include <iostream>
#include <fstream>
#include "gtest/gtest.h"
#include "static_handler.h"

//Test fixture
class StaticHandlerTest : public ::testing::Test
{
protected:
    StaticHandlerTest() : uri_("/static1"), root_("/static/static1") {
    // Initialize static_handler_ with the given URI and root directory
        static_handler_ = new StaticHandler(uri_, root_);
    }
    StaticHandler* static_handler_;
    std::string uri_;
    std::string root_;
};

TEST_F(StaticHandlerTest, GenerateResponseSuccess)
{
    std::string request_ = "GET /static1/test.txt HTTP/1.1";
    static_handler_->SetRequest(request_);
    std::string response = static_handler_->GenerateResponse().ToString();
    EXPECT_EQ(response, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 51\r\n\r\nThis is a test file for .txt extension in /static1.");
}

TEST_F(StaticHandlerTest, GenerateResponseFail)
{
    std::string request_ = "GET /static1/abc.txt HTTP/1.1";
    static_handler_->SetRequest(uri_);
    std::string response = static_handler_->GenerateResponse().ToString();
    EXPECT_EQ(response, "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 24\r\n\r\nThe file doesn't exist\r\n");
}

TEST_F(StaticHandlerTest, GetMIMETypeHTML)
{
    std::string path = "//host:port/static/somefile.html";
    std::string type = static_handler_->GetMIMEType(path);
    EXPECT_EQ(type, "text/html");
}

TEST_F(StaticHandlerTest, GetMIMETypeJPG)
{
    std::string path = "//host:port/static/somefile.jpeg";
    std::string type = static_handler_->GetMIMEType(path);
    EXPECT_EQ(type, "image/jpeg");
}

TEST_F(StaticHandlerTest, GetMIMETypeZIP)
{
    std::string path = "//host:port/static/somefile.zip";
    std::string type = static_handler_->GetMIMEType(path);
    EXPECT_EQ(type, "application/zip");
}

TEST_F(StaticHandlerTest, GetMIMETypeTXT)
{
    std::string path = "//host:port/static/somefile.txt";
    std::string type = static_handler_->GetMIMEType(path);
    EXPECT_EQ(type, "text/plain");
}

TEST_F(StaticHandlerTest, GetMIMETypeGIF)
{
    std::string path = "//host:port/static/somefile.gif";
    std::string type = static_handler_->GetMIMEType(path);
    EXPECT_EQ(type, "image/gif");
}

TEST_F(StaticHandlerTest, GetMIMETypeOCTET)
{
    std::string path = "//host:port/static/somefile.others";
    std::string type = static_handler_->GetMIMEType(path);
    EXPECT_EQ(type, "application/octet-stream");
}