#include "gtest/gtest.h"
#include "logger.h"
#include <ctime>

// Test fixture
class LoggerTest : public ::testing::Test
{
protected:
    Logger logger_;
};

// TEST_F(LoggerTest, CreatesLogFile)
// {
//     char buffer[80];
//     std::time_t now = std::time(nullptr);
//     std::strftime(buffer, 80, "%y_%m_%d", localtime(&now));
//     std::string result(buffer);
//     std::string logFileName = "../logs/" + result + ".log";
//     bool success = boost::filesystem::exists(logFileName);
//     EXPECT_TRUE(success);
// }
