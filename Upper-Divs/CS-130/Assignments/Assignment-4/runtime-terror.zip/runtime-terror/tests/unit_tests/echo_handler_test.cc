#include "gtest/gtest.h"
#include "echo_handler.h"

// Test fixture
class EchoHandlerTest : public ::testing::Test
{
protected:
    std::string req_ = "Hello World";
    EchoHandler echo_handler_;
};

// Unit tests
TEST_F(EchoHandlerTest, GenerateResponse)
{
    echo_handler_.SetRequest(req_);
    std::string res = echo_handler_.GenerateResponse().ToString();
    EXPECT_EQ(res, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nHello World");
}
