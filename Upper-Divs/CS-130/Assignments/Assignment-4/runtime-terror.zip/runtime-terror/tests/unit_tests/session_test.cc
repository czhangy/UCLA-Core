#include "gtest/gtest.h"
#include "session.h"

class SessionTest : public ::testing::Test
{
protected:
    boost::asio::io_service io_service;
    std::shared_ptr<ServerTools> tools_ = std::shared_ptr<ServerTools>(new ServerTools());
    std::vector<Location> locations_;
    std::unique_ptr<HandlerManager> handler_manager_ = std::unique_ptr<HandlerManager>(new HandlerManager(locations_));

    // Linking error please help
    std::string str;
    Request req = Request(str);
    BadHandler bh;
    EchoHandler eh;
    StaticHandler sh = StaticHandler(str, str);
    Logger l;
};

// Test for start
TEST_F(SessionTest, StartSession)
{
    tools_->dispatcher = std::unique_ptr<Dispatcher>(new Dispatcher(std::move(handler_manager_)));
    session test_session(io_service, tools_);
    test_session.start();
    EXPECT_TRUE(test_session.started);
}

// Test for handle_read
TEST_F(SessionTest, SessionHandleRead)
{
    tools_->dispatcher = std::unique_ptr<Dispatcher>(new Dispatcher(std::move(handler_manager_)));
    session test_session(io_service, tools_);
    std::ostream os(&test_session.buffer_);
    const std::string request = "GET /echo HTTP/1.1";
    os << request;
    test_session.handle_read(boost::system::error_code(), request.size());
    EXPECT_GT(test_session.response_str.size(), 0);
}

// Test for handle_write
TEST_F(SessionTest, SessionHandleWrite)
{
    tools_->dispatcher = std::unique_ptr<Dispatcher>(new Dispatcher(std::move(handler_manager_)));
    session test_session(io_service, tools_);
    std::ostream os(&test_session.buffer_);
    std::string request = "hello\r\n\r\n";
    os << request;
    test_session.handle_read(boost::system::error_code(), request.size());
    boost::system::error_code ec;
    test_session.handle_write(ec);
    EXPECT_TRUE(test_session.wrote);
}