#include "gtest/gtest.h"
#include "request.h"

// Test fixture
class RequestTest : public ::testing::Test
{
protected:
    std::string request_str_ = "GET /echo HTTP/1.1\r\n";
    Request request_ = Request(request_str_);
};

// Unit tests
TEST_F(RequestTest, ToString)
{
    EXPECT_EQ(request_.ToString(), request_str_);
}

TEST_F(RequestTest, GetRequestURI)
{
    std::string uri = request_.GetRequestURI();
    EXPECT_EQ(uri, "/echo");
}
