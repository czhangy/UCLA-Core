#pragma once

#include <memory>
#include "dispatcher.h"
#include "logger.h"

struct ServerTools
{
    std::unique_ptr<Dispatcher> dispatcher;
    std::unique_ptr<Logger> logger;
};
