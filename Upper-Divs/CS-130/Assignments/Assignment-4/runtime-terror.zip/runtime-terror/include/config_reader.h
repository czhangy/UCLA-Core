#pragma once

#include "config_parser.h"
#include "location.h"
#include <queue>
#include <vector>

class ConfigReader
{
public:
    ConfigReader(NginxConfig *config);
    unsigned short GetPort() const;
    std::vector<Location> GetLocations() const;

private:
    unsigned short ExtractPort(NginxConfig *config) const;
    std::vector<Location> ExtractLocations(NginxConfig *config) const;
    bool ExtractLocation(NginxConfig *location_config, Location *location) const;

    unsigned short port_;
    std::vector<Location> locations_;
};