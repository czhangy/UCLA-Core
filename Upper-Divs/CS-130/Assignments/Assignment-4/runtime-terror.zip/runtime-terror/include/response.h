#pragma once

#include <string>
#include <vector>

class Response
{
public:
    enum Status
    {
        OK = 200,
        BAD = 400,
        NOT_FOUND = 404
    };

    Response(Status status, std::string body);
    void AddHeader(std::string header_name, std::string header_value);
    std::string GetStatusString() const;
    std::string ToString() const;

private:
    struct Header
    {
        std::string name;
        std::string value;

        Header(std::string name, std::string value);
        std::string ToString() const;
    };

    const std::string CRLF = "\r\n";
    Status status_;
    std::vector<Header> headers_;
    std::string body_;
};