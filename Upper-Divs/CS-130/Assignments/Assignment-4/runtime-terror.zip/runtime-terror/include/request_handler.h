#pragma once

#include <string>
#include "request.h"
#include "response.h"

class RequestHandler
{
public:
    RequestHandler();
    virtual ~RequestHandler() {}
    void SetRequest(const std::string &request);
    virtual Response GenerateResponse() const = 0;

protected:
    std::string uri_;
    std::string request_;
};