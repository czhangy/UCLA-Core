#pragma once

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <istream>
#include <iostream>
#include <memory>
#include <string>
#include "dispatcher.h"
#include "echo_handler.h"
#include "logger.h"
#include "handler_manager.h"
#include "request.h"
#include "request_handler.h"
#include "response.h"
#include "server_tools.h"
#include "static_handler.h"

using boost::asio::ip::tcp;

class session
{
public:
    session(boost::asio::io_service &io_service, std::shared_ptr<ServerTools> tools);
    tcp::socket &socket();
    void start();
    void handle_read(const boost::system::error_code &error,
                     size_t bytes_transferred);
    void handle_write(const boost::system::error_code &error);
    boost::asio::streambuf buffer_;
    bool started = false;
    bool wrote = false;
    std::string response_str;

private:
    tcp::socket socket_;
    enum
    {
        max_length = 1024
    };
    char data_[max_length];
    std::shared_ptr<ServerTools> tools_;
};
