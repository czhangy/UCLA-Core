#pragma once

#include <boost/asio.hpp>
#include <boost/filesystem.hpp>
#include <fstream>
#include <string>
#include "config_reader.h"
#include "request_handler.h"
#include "response.h"

class StaticHandler : public RequestHandler
{
public:
    StaticHandler(const std::string &uri, const std::string &root);
    Response GenerateResponse() const;
    std::string GetMIMEType(const std::string &path) const;

private:
    Response FailedRequest(std::string error) const;
    std::string GetPath() const;

    std::string uri_;
    std::string root_;
};
