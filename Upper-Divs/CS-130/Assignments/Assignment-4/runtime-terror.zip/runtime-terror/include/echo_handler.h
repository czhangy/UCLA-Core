#pragma once

#include <string>
#include "request_handler.h"
#include "response.h"

class EchoHandler : public RequestHandler
{
public:
    EchoHandler();
    Response GenerateResponse() const;
};