#pragma once
#include <string>
#include <boost/log/trivial.hpp>
#include <boost/log/common.hpp>
#include <boost/log/keywords/file_name.hpp>
#include <boost/log/keywords/format.hpp>
#include <boost/log/utility/setup.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <boost/filesystem.hpp>

class Logger {

public:
    Logger();

    void logTrace(std::string message);
    void logDebug(std::string message);
    void logInfo(std::string message);
    void logWarning(std::string message);
    void logError(std::string message);
    void logFatal(std::string message);

private:

};