#pragma once

#include <string>
#include "request_handler.h"
#include "response.h"

class BadHandler : public RequestHandler
{
public:
    BadHandler();
    void SetError(std::string error);
    Response GenerateResponse() const;

private:
    std::string error_;
};