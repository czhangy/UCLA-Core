#pragma once
#include <string>

struct Location
{
    std::string uri;
    std::string handler;
    std::string root;
};
