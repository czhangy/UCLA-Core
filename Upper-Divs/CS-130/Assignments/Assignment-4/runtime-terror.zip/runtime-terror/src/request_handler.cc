#include "request_handler.h"

RequestHandler::RequestHandler() {}

void RequestHandler::SetRequest(const std::string &request)
{
    request_ = request;
}
