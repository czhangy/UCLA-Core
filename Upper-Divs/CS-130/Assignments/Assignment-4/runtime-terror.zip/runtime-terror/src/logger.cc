#include "logger.h"

namespace logging = boost::log;
namespace sinks = boost::log::sinks;
namespace src = boost::log::sources;
namespace expr = boost::log::expressions;
namespace attrs = boost::log::attributes;
namespace keywords = boost::log::keywords;

Logger::Logger() {
    // set format
    logging::register_simple_formatter_factory< logging::trivial::severity_level, char >("Severity");
    logging::add_common_attributes();

    // format for messages
    std::string messageFormat = "[%TimeStamp%] [%ThreadID%] [%Severity%]: %Message%";

    // add file for logging
    logging::add_file_log ( 
        keywords::target = "../logs/", 
        keywords::file_name = "../logs/%y_%m_%d.log",                                      
        keywords::rotation_size = 10 * 1000 * 1000, // rotate once file hits 10 mb
        keywords::time_based_rotation =  sinks::file::rotation_at_time_point(0, 0, 0), // rotate at midnight
        keywords::format = messageFormat,
        keywords::open_mode = std::ios_base::app, // append to file
        keywords::auto_flush = true // flushes buffer after each new log record
    );

    // log to console as well
    logging::add_console_log(std::cout, boost::log::keywords::format = messageFormat);
}

void Logger::logTrace(std::string message){
    BOOST_LOG_TRIVIAL(trace) << message;
}

void Logger::logDebug(std::string message){
    BOOST_LOG_TRIVIAL(debug) << message;
}

void Logger::logInfo(std::string message){
    BOOST_LOG_TRIVIAL(info) << message;
}

void Logger::logWarning(std::string message){
    BOOST_LOG_TRIVIAL(warning) << message;
}

void Logger::logError(std::string message){
    BOOST_LOG_TRIVIAL(error) << message;
}

void Logger::logFatal(std::string message){
    BOOST_LOG_TRIVIAL(fatal) << message;
}