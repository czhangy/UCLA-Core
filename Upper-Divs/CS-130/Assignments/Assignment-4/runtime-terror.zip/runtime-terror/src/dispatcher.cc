#include "dispatcher.h"

Dispatcher::Dispatcher(std::unique_ptr<HandlerManager> handler_manager) : handler_manager_(std::move(handler_manager)) {}

Response Dispatcher::DispatchRequest(const Request &request) const
{
    std::string uri = request.GetRequestURI();
    std::shared_ptr<RequestHandler> handler = handler_manager_->GetHandler(uri);
    handler->SetRequest(request.ToString());
    return handler->GenerateResponse();
}
