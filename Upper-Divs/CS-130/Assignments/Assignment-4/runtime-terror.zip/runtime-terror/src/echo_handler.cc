#include "echo_handler.h"

EchoHandler::EchoHandler() {}

/*
    Generates an echoed response

    @return a response that matches the incoming request
*/
Response EchoHandler::GenerateResponse() const
{
    Response response(Response::OK, request_);
    response.AddHeader("Content-Type", "text/plain");
    response.AddHeader("Content-Length", std::to_string(request_.size()));
    return response;
}
