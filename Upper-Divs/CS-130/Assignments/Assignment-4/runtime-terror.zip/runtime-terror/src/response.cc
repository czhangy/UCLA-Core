#include "response.h"

Response::Header::Header(std::string name, std::string value) : name(name), value(value) {}

std::string Response::Header::ToString() const
{
    return name + ": " + value;
}

Response::Response(Status status, std::string body) : status_(status), body_(body) {}

/*
    Adds a new HTTP header to the header list

    @param name the name of the header
    @param value the value of the header
*/
void Response::AddHeader(std::string name, std::string value)
{
    headers_.push_back(Header(name, value));
}

/*
    Gets the string corresponding to the response's status

    @return the string representation of the current status code
*/
std::string Response::GetStatusString() const
{
    switch (status_)
    {
    case OK:
        return "200 OK";
    case NOT_FOUND:
        return "404 Not Found";
    default:
        return "400 Bad Request";
    }
}

/*
    Outputs the response in string format

    @return the formatted string representation of the HTTP response
*/
std::string Response::ToString() const
{
    // Append status
    std::string response;
    response += "HTTP/1.1 " + GetStatusString() + CRLF;

    // Append headers
    for (Header header : headers_)
    {
        response += header.ToString() + CRLF;
    }

    // CRLF between headers and body
    response += CRLF;

    // Append body
    response += body_;
    return response;
}
