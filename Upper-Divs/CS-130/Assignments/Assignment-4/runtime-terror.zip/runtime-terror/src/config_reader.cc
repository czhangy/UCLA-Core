#include "config_reader.h"

ConfigReader::ConfigReader(NginxConfig *config)
{
    port_ = ExtractPort(config);
    locations_ = ExtractLocations(config);
}

/*
    Returns the port number to be listened on

    @return a valid port number
*/
unsigned short ConfigReader::GetPort() const
{
    return port_;
}

/*
    Returns a list of locations that the server should use

    @return a vector containing Location objects constructed from locations
            specified in the config
*/
std::vector<Location> ConfigReader::GetLocations() const
{
    return locations_;
}

/*
    Searches for the shallowest valid port number in the config

    @param config a pointer to the parsed config file
    @return the port number if it was found, or 0 if no valid port number exists
*/
unsigned short ConfigReader::ExtractPort(NginxConfig *config) const
{
    std::queue<NginxConfig *> config_queue;
    config_queue.push(config);
    while (!config_queue.empty())
    {
        NginxConfig *current_config = config_queue.front();
        config_queue.pop();
        if (current_config == NULL)
        {
            continue;
        }
        for (std::shared_ptr<NginxConfigStatement> statement : current_config->statements_)
        {
            if (statement != NULL && statement->tokens_.size() == 2 &&
                statement->tokens_[0] == "listen")
            {
                try
                {
                    unsigned long port = std::strtoul((statement->tokens_[1]).c_str(), NULL, 0);
                    if (port <= 0xFFFF)
                    {
                        return static_cast<unsigned short>(port);
                    }
                }
                catch (std::exception &e)
                {
                    continue;
                }
            }
            config_queue.push(statement->child_block_.get());
        }
    }
    return 0;
}

/*
    Searches for all valid location declarations in the config file

    @param config a pointer to the parsed config file
    @return a vector containing all locations found in the config
*/
std::vector<Location> ConfigReader::ExtractLocations(NginxConfig *config) const
{
    std::vector<Location> locations;
    std::queue<NginxConfig *> config_queue;
    config_queue.push(config);
    while (!config_queue.empty())
    {
        NginxConfig *current_config = config_queue.front();
        config_queue.pop();
        if (current_config == NULL)
        {
            continue;
        }
        for (std::shared_ptr<NginxConfigStatement> statement : current_config->statements_)
        {
            if (statement != NULL && statement->tokens_.size() == 2 &&
                statement->tokens_[0] == "location")
            {
                Location location;
                location.uri = statement->tokens_[1];
                location.root = "/";
                if (ExtractLocation(statement->child_block_.get(), &location))
                {
                    locations.push_back(location);
                }
            }
            config_queue.push(statement->child_block_.get());
        }
    }
    return locations;
}

/*
    Populates the fields of a location object
    Fails if the location config has extra tokens or missing handler token

    @param[in] location_config a pointer to the block directive associated with
               the location token
    @param[out] location a pointer to the location object containing route
                information
    @return if the location extraction was successful
*/
bool ConfigReader::ExtractLocation(NginxConfig *location_config, Location *location) const
{
    for (std::shared_ptr<NginxConfigStatement> statement : location_config->statements_)
    {
        if (statement != NULL && statement->tokens_.size() == 2)
        {
            if (statement->tokens_[0] == "handler" && location->handler.empty())
            {
                location->handler = statement->tokens_[1];
            }
            else if (statement->tokens_[0] == "root" && location->root == "/")
            {
                location->root = statement->tokens_[1];
            }
        }
    }
    return !location->handler.empty();
}
