#include "echo_handler_factory.h"

EchoHandlerFactory::EchoHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger) {}

std::shared_ptr<RequestHandler> EchoHandlerFactory::Create(const std::string &url) const
{
    return std::shared_ptr<EchoHandler>(new EchoHandler(url, location_, logger_));
}
