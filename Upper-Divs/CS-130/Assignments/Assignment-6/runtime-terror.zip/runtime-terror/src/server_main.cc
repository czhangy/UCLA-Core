//
// async_tcp_echo_server.cpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2017 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/asio.hpp>
#include <cstdlib>
#include <string>
#include <iostream>
#include <memory>
#include <vector>
#include "config_parser.h"
#include "dispatcher.h"
#include "logger.h"
#include "nginx_config.h"
#include "server.h"

int main(int argc, char *argv[])
{
    try
    {
        // Create logger
        std::shared_ptr<Logger> logger(new Logger());

        // Check for valid args
        if (argc != 2)
        {
            logger->LogFatal("Invalid args");
            return 1;
        }

        // Parse the config file
        NginxConfigParser config_parser;
        NginxConfig config;
        if (!config_parser.Parse(argv[1], &config))
        {
            logger->LogFatal("Invalid config file");
            return 1;
        }
        unsigned short port = config.GetPort();
        logger->LogInfo("Config file parsed successfully");

        // Extract port
        if (port == 0)
        {
            logger->LogFatal("Valid port not found");
            return 1;
        }

        // Log port found in config file
        logger->LogInfo("Listening on port: " + std::to_string(port));

        // Create dispatcher
        std::shared_ptr<Dispatcher> dispatcher(new Dispatcher(config, logger));

        // Start server
        boost::asio::io_service io_service;
        server s(io_service, port, dispatcher, logger);
        io_service.run();
    }
    catch (std::exception &e)
    {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}
