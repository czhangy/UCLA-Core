#include "echo_handler.h"

EchoHandler::EchoHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger) {}

http::status EchoHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    std::string request_str;
    request_str += boost::lexical_cast<std::string>(request.base());
    request_str += boost::lexical_cast<std::string>(request.body());
    logger_->LogInfo("Generated echo response");
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/plain");
    response.body() = request_str + "\r\n";
    response.prepare_payload();
    return response.result();
}
