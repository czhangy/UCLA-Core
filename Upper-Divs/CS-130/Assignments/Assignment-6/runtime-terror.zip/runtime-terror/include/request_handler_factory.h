#pragma once

#include <memory>
#include <string>
#include "logger.h"
#include "request_handler.h"

class RequestHandlerFactory
{
public:
    RequestHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger);
    virtual std::shared_ptr<RequestHandler> Create(const std::string &url) const = 0;

protected:
    std::string location_;
    std::shared_ptr<Logger> logger_;
};