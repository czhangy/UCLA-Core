#pragma once

#include <boost/asio.hpp>
#include <boost/beast/http.hpp>
#include <boost/bind.hpp>
#include <istream>
#include <iostream>
#include <memory>
#include <string>
#include "dispatcher.h"
#include "logger.h"

using boost::asio::ip::tcp;
namespace http = boost::beast::http;

class session
{
public:
    session(boost::asio::io_service &io_service, std::shared_ptr<Dispatcher> dispatcher, std::shared_ptr<Logger> logger);
    tcp::socket &socket();
    void start();
    void handle_read(const boost::system::error_code &error,
                     size_t bytes_transferred);
    void handle_write(const boost::system::error_code &error);
    boost::asio::streambuf buffer_;

    // Testing variables
    std::string response_str;
    bool started = false;
    bool wrote = false;

private:
    enum
    {
        max_length = 1024
    };

    tcp::socket socket_;
    char data_[max_length];
    std::shared_ptr<Dispatcher> dispatcher_;
    std::shared_ptr<Logger> logger_;
};
