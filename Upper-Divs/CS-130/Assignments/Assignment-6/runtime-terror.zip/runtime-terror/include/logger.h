#pragma once

#include <boost/filesystem.hpp>
#include <boost/log/common.hpp>
#include <boost/log/keywords/file_name.hpp>
#include <boost/log/keywords/format.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/utility/setup.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <ctime>
#include <string>

class Logger
{
public:
    Logger();
    void Init();
    std::string GetAbsoluteLogFilePath();
    void LogTrace(std::string message);
    void LogDebug(std::string message);
    void LogInfo(std::string message);
    void LogWarning(std::string message);
    void LogError(std::string message);
    void LogFatal(std::string message);

private:
    std::string GenerateLogFilePath();
    std::string logFileDir_ = "../logs/";
    int logFileRotationSize_ = 10 * 1000 * 1000;
};