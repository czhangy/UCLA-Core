#pragma once

#include <boost/asio.hpp>
#include <boost/beast/http.hpp>
#include <boost/filesystem.hpp>
#include <fstream>
#include <memory>
#include <string>
#include "request_handler.h"

namespace http = boost::beast::http;

class StaticHandler : public RequestHandler
{
public:
    StaticHandler(const std::string &url, const std::string &location, const std::string &root, std::shared_ptr<Logger> logger);
    http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const;

private:
    http::status NotFoundRequest(std::string error, http::response<http::string_body> &response) const;
    std::string GetPath(const http::request<http::string_body> &request) const;
    std::string GetMIMEType(const std::string &path) const;

    std::string root_;
};
