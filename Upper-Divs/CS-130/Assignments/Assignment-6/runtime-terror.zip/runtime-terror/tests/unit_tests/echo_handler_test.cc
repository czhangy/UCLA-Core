#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "echo_handler.h"

using ::testing::HasSubstr;

// Test fixture
class EchoHandlerTest : public ::testing::Test
{
protected:
    std::string echo_url_ = "/echo";
    std::string echo_str_ = "GET /echo HTTP/1.1";

    std::string GetResponseString(const std::string &request_url)
    {
        std::string request_str = "GET " + request_url + " HTTP/1.1\r\n";
        EchoHandler echo_handler = EchoHandler(request_url, "/echo", std::shared_ptr<Logger>(new Logger()));
        boost::system::error_code ec;
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        echo_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(EchoHandlerTest, GenerateResponse)
{
    std::string response_str = GetResponseString(echo_url_);
    EXPECT_THAT(response_str, HasSubstr(echo_str_));
}
