#include "gtest/gtest.h"
#include "config_parser.h"
#include "server.h"

class ServerTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
    boost::asio::io_service io_service_;
    short port_ = 8080;
    std::shared_ptr<Logger> logger_ = std::shared_ptr<Logger>(new Logger());
};

// Test for start accept
TEST_F(ServerTest, StartAccept)
{
    parser_.Parse("/mocks/configs/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::shared_ptr<Dispatcher>(new Dispatcher(config_, logger_));
    server test_server(io_service_, port_, dispatcher, logger_);
    test_server.start_accept();
    EXPECT_TRUE(test_server.started);
}

// Test for handle accept
TEST_F(ServerTest, HandleAccept)
{
    parser_.Parse("/mocks/configs/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::shared_ptr<Dispatcher>(new Dispatcher(config_, logger_));
    server test_server(io_service_, port_, dispatcher, logger_);
    session *test_session = new session(io_service_, dispatcher, logger_);
    test_server.handle_accept(test_session, boost::system::error_code());
    EXPECT_TRUE(test_server.handled);
}