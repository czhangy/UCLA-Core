#include "gtest/gtest.h"
#include "config_parser.h"
#include "session.h"

class SessionTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
    boost::asio::io_service io_service_;
    std::shared_ptr<Logger> logger_ = std::shared_ptr<Logger>(new Logger());
};

// Test for start
TEST_F(SessionTest, StartSession)
{
    parser_.Parse("/mocks/configs/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::shared_ptr<Dispatcher>(new Dispatcher(config_, logger_));
    session test_session(io_service_, dispatcher, logger_);
    test_session.start();
    EXPECT_TRUE(test_session.started);
}

// Test for handle_read
TEST_F(SessionTest, SessionHandleRead)
{
    parser_.Parse("/mocks/configs/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::shared_ptr<Dispatcher>(new Dispatcher(config_, logger_));
    session test_session(io_service_, dispatcher, logger_);
    std::ostream os(&test_session.buffer_);
    const std::string request = "GET /echo HTTP/1.1\r\n";
    os << request;
    test_session.handle_read(boost::system::error_code(), request.size());
    EXPECT_GT(test_session.response_str.size(), 0);
}

// Test for handle_write
TEST_F(SessionTest, SessionHandleWrite)
{
    parser_.Parse("/mocks/configs/normal_config", &config_);
    std::shared_ptr<Dispatcher> dispatcher = std::shared_ptr<Dispatcher>(new Dispatcher(config_, logger_));
    session test_session(io_service_, dispatcher, logger_);
    std::ostream os(&test_session.buffer_);
    std::string request = "GET /echo HTTP/1.1\r\n";
    os << request;
    test_session.handle_read(boost::system::error_code(), request.size());
    boost::system::error_code ec;
    test_session.handle_write(ec);
    EXPECT_TRUE(test_session.wrote);
}