#include "gtest/gtest.h"
#include "logger.h"

// Test fixture
class LoggerTest : public ::testing::Test
{
protected:
    Logger logger_;
};

// TEST_F(LoggerTest, CreatesLogFile)
// {
//     std::string logFilePath = logger_.GenerateLogFilePath();
//     std::cout << "file path: " << logFilePath << std::endl;
//     bool success = boost::filesystem::exists(logFilePath);
//     EXPECT_TRUE(success);
// }
