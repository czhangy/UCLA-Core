#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "static_handler.h"

using ::testing::HasSubstr;

// Test fixture
class StaticHandlerTest : public ::testing::Test
{
protected:
    std::string invalid_url_ = "/static/abc.txt";
    std::string txt_url_ = "/static/test.txt";
    std::string html_url_ = "/static/test.html";
    std::string jpeg_url_ = "/static/dog.jpg";
    std::string zip_url_ = "/static/testfile.zip";
    std::string gif_url_ = "/static/cat.gif";

    std::string GetResponseString(const std::string &request_url)
    {
        std::string request_str = "GET " + request_url + " HTTP/1.1\r\n";
        StaticHandler static_handler = StaticHandler(request_url, "/static", "/mocks/static_files", std::shared_ptr<Logger>(new Logger()));
        boost::system::error_code ec;
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        static_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(StaticHandlerTest, HandleRequestSuccess)
{
    std::string response_str = GetResponseString(txt_url_);
    std::string file_contents = "This is a test file for .txt extension in /static1.";
    EXPECT_THAT(response_str, HasSubstr(file_contents));
}

TEST_F(StaticHandlerTest, HandleRequestFail)
{
    std::string response_str = GetResponseString(invalid_url_);
    std::string not_found = "404 Not Found";
    EXPECT_THAT(response_str, HasSubstr(not_found));
}

TEST_F(StaticHandlerTest, MIMETypeHTML)
{
    std::string response_str = GetResponseString(html_url_);
    std::string mime_html = "Content-Type: text/html";
    EXPECT_THAT(response_str, HasSubstr(mime_html));
}

TEST_F(StaticHandlerTest, MIMETypeJPEG)
{
    std::string response_str = GetResponseString(jpeg_url_);
    std::string mime_jpeg = "Content-Type: image/jpeg";
    EXPECT_THAT(response_str, HasSubstr(mime_jpeg));
}

TEST_F(StaticHandlerTest, MIMETypeTXT)
{
    std::string response_str = GetResponseString(txt_url_);
    std::string mime_txt = "Content-Type: text/plain";
    EXPECT_THAT(response_str, HasSubstr(mime_txt));
}

TEST_F(StaticHandlerTest, MIMETypeZIP)
{
    std::string response_str = GetResponseString(zip_url_);
    std::string mime_zip = "Content-Type: application/zip";
    EXPECT_THAT(response_str, HasSubstr(mime_zip));
}

TEST_F(StaticHandlerTest, MIMETypeGIF_)
{
    std::string response_str = GetResponseString(gif_url_);
    std::string mime_gif = "Content-Type: image/gif";
    EXPECT_THAT(response_str, HasSubstr(mime_gif));
}
