#include "gtest/gtest.h"
#include "config_parser.h"
#include "dispatcher.h"

// Test fixture
class DispatcherTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
    std::string echo_request_ = "GET /echo HTTP/1.1\r\n";
    std::string static_request_ = "GET /static/test.txt HTTP/1.1\r\n";
    std::string bad_handler_request_ = "GET /bad HTTP/1.1\r\n";
    std::string not_found_request_ = "GET / HTTP/1.1\r\n";

    std::string GetResponseString(const std::string &request_str)
    {
        Dispatcher dispatcher = Dispatcher(config_, std::shared_ptr<Logger>(new Logger()));
        boost::system::error_code ec;
        http::request_parser<http::string_body> parser;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        http::response<http::string_body> response = dispatcher.DispatchRequest(request);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(DispatcherTest, EchoRequest)
{
    parser_.Parse("../mocks/configs/normal_config", &config_);
    std::string response_str = GetResponseString(echo_request_);
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 24\r\n\r\nGET /echo HTTP/1.1\r\n\r\n\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, StaticRequest)
{
    parser_.Parse("../mocks/configs/normal_config", &config_);
    std::string response_str = GetResponseString(static_request_);
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 53\r\n\r\nThis is a test file for .txt extension in /static1.\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, NotFoundRequest)
{
    parser_.Parse("../mocks/configs/normal_config", &config_);
    std::string response_str = GetResponseString(not_found_request_);
    std::string expected_res = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 15\r\n\r\n404 Not Found\r\n";
    EXPECT_EQ(response_str, expected_res);
}

TEST_F(DispatcherTest, BadHandler)
{
    parser_.Parse("../mocks/configs/missing_location_config", &config_);
    std::string response_str = GetResponseString(bad_handler_request_);
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 44\r\n\r\nNo handler has been assigned to serve /bad\r\n";
    EXPECT_EQ(response_str, expected_res);
}
