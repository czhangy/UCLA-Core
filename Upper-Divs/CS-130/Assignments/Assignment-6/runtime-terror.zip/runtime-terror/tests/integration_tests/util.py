import subprocess
from subprocess import Popen

# Curl URL as text or binary
def curl(URL, text=True):
    curl = Popen(['curl', URL], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=text)
    return curl.communicate()

# Generate expected echo response
def generate_config(port):
    port = str(port)
    config_path = "./config"
    config = """http {
    server {
        listen """+port+""";

        location /echo {
            handler echo;
        }

        location /static1 {
            handler static;
            root /tests/integration_tests/static/static1;
        }

        location /static2 {
            handler static;
            root /tests/integration_tests/static/static2;
        }
    }
}"""
    file = open(config_path, 'w')
    file.write(config)
    file.close()

    return config_path