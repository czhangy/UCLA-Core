from test_server import TestServer
from util import *
import time

# Constants
SERVER_URL= "http://localhost"
SERVER_HOST = "localhost"
SERVER_PORT = "8080"
NUM_TESTS = 4

# Expected Responses
INVALID_URI = "Invalid URI"
STATIC1_TEXT = "This is a test file for .txt extension in /static1."

# Paths
EXECUTABLE_PATH = "./bin/webserver"
CONFIG_PATH = generate_config(port=SERVER_PORT)

def integration_test():
    tests_passed = 0
    try:
        # Start the server
        print("Starting webserver... ")
        server = TestServer(executable=EXECUTABLE_PATH, config=CONFIG_PATH)
        server.start()
        time.sleep(1)

        # Invalid URI Test
        path = "/ec"
        out, err = curl(SERVER_URL+ ':' + SERVER_PORT + path)
        if out.strip() == INVALID_URI:
            print("INVALID URI TEST PASSED")
            tests_passed +=1
        else:
            print("INVALID URI TEST FAILED")

        # Test Echo 
        path = "/echo"
        expected_echo = generate_echo_response(hostname=SERVER_HOST, port=SERVER_PORT, path=path)
        out, err = curl(SERVER_URL+ ':' + SERVER_PORT + path)
        if out.strip() == expected_echo:
            print("ECHO TEST PASSED")
            tests_passed +=1
        else:
            print("ECHO TEST FAILED")

        # Test 10 Rapid Echo Requests
        path = "/echo"
        expected_echo = generate_echo_response(hostname=SERVER_HOST, port=SERVER_PORT, path=path)
        passed = True
        for i in range(10):
            out, err = curl(SERVER_URL+ ':' + SERVER_PORT + path)
            if out.strip() != expected_echo:
                passed = False
                break
        if passed:
            print("10 RAPID REQUEST TEST PASSED")
            tests_passed +=1
        else:
            print("10 RAPID REQUEST TEST FAILED")
    
        # Test Static1 Text
        path = "/static1/test.txt"
        print(SERVER_URL+ ':' + SERVER_PORT + path)
        out, err = curl(SERVER_URL+ ':' + SERVER_PORT + path)
        if out.strip() == STATIC1_TEXT:
            print("STATIC1 TEXT TEST PASSED")
            tests_passed +=1
        else:
            print("STATIC1 TEXT TEST FAILED")

    except:
        return 1
    
    # Shut down the server
    print("Shutting down webserver...")
    server.stop()

    # Return Test Results
    print(f"{tests_passed} / {NUM_TESTS} INTEGRATION TESTS PASSED")
    if tests_passed == NUM_TESTS:
        return 0
    else:
        return 1

if __name__ == "main":
    integration_test()