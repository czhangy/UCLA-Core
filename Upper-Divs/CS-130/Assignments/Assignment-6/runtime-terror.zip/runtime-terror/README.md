# Runtime Terror Documentation


## Project Description:
Runtime-Terror is a modern webserver, able to server static files, echo requests, and server 404 errors. This project was built with expandability in mind, allowing users to configure their own APIs with ease. Below is instructions on how to build, run, and test the server, as well as how to configure additional APIs consistent with the original design.


# 

## Project Layout:
All of the source code for the project is located in "src/" and all of the header files are in "include/" directories. 

The code starts from "server_main.cc", which uses a config reader to read the server configuration file located in "configs/docker_server_config" which is passed to the program as a parameter. It then creates a server using this configuration, and this server listens for requests, useing a request_handler_factory to create an appropriate request handler, and delivering the response from the handler to the user. 

Every class in this process is seprated into a different .cc file, allowing for modularity, expandablity, and straightforward testing.

The code for the unit and integration tests are located in "tests/", and the Dockerfiles required to build the final image are located in "docker/".



#


# How to build, test, and run the code:

### To perform a out-of-source **build** from the root directory:

<br/>

$ mkdir build

$ cd build

$ cmake ..

$ make

<br/>


### After, to run the **tests**:
<br/>

$ ctest  # Simple output

or

$ ctest -V # Verbose output

<br/>


### To build a out-of-source **test coverage** from the root directory:

<br/>

$ mkdir build_coverage

$ cd build_coverage

$ cmake -DCMAKE_BUILD_TYPE=Coverage ..

$ make coverage

<br/>

### Finally, to **run** the program from the root directory:

<br/>
$ ./build/bin/webserver ./configs/docker_server_config

<br/>

#
# How to add a request handler, including:

Our webserver is built to be expandable, allowing you to contribute new requst handlers to the project. 

First, add the new request handler to the "configs/docker_server_config" config file. This allows you to link incoming requests to a specific path to a specific handler. The general format for the config file is as follow:
<br/><br/>
location {path} {name of the handler} { <br/>
&nbsp;&nbsp;&nbsp;&nbsp; parameters
<br/>
}
<br/>

The path is the url path to reach this handler, which is then linked to the name of the handler, and any paramters for the handler are passed inside the curly brackets.

<br/><br/>

For example, the static_handler configuration looks like:
<br/><br/>
location /static1 StaticHandler { <br/>
&nbsp;&nbsp;&nbsp;&nbsp;  root /static/static1;
<br/>
}
<br/><br/>

Then, you have to actually implement the handler and handler factory. All of our handlers and handler factories inherit from our base "request_handler.cc" and "request_handler_factory.cc" classes in the "src/" directory. This helps maintain a consistent interface for all of our handlers. For example, our speficic implementation of the static_handelr_factory ensures that a root is provided before it attempts to create a static_handler object. 
<br/><br/>

Lastly, you have to add this new request_handler_factory to the dispatcher, so it is able to route the incoming requests to this handler and pass it the corrrect parameters.
<br/><br/>

## Logging and Testing
#
In order to aid with debugging, make sure to include logging throughout the process using:
<br/>
logger_->LogInfo()

logger_->LogWarning()

logger_->LogError()
<br/>
<br/>

After creating the handler, test it by adding unit tests under "tests/unit_tests" and adding the test to the CMakeLists.txt. For our static handler example, here is how the CMakeLists.txt looks like:
<br/><br/>

add_executable(static_handler_test tests/unit_tests/static_handler_test.cc)
target_link_libraries(static_handler_test static_handler gmock gtest_main)
<br/>
<br/>


## Example Interface for Static Handler

<br/>

### static_handler_factory.h
#

class StaticHandlerFactory : public RequestHandlerFactory
<br/>
{
<br/>
public:
<br/>
&nbsp;&nbsp;&nbsp;&nbsp; StaticHandlerFactory(const std::string &location, const NginxConfig &config,
    <br/>
&nbsp;&nbsp;&nbsp;&nbsp; std::shared_ptr<Logger> logger);
    <br/>
&nbsp;&nbsp;&nbsp;&nbsp; std::shared_ptr<RequestHandler> Create(const std::string &url) const;
    <br/>

private:
<br/>
&nbsp;&nbsp;&nbsp;&nbsp; std::string root_;
<br/>
};

<br/>
<br/>

### static_hanldler.h:
#

<br/>
namespace http = boost::beast::http;
<br/>
class StaticHandler : public RequestHandler
<br/>
{
<br/>
public:<br/>
&nbsp;&nbsp;&nbsp;&nbsp; StaticHandler(const std::string &url, const std::string &location, const std::string &root, std::shared_ptr<Logger> logger);

&nbsp;&nbsp;&nbsp;&nbsp; http::status HandleRequest(const http::request<http::string_body> &request,http::response<http::string_body> &response) const;
<br/>
private:<br/>
&nbsp;&nbsp;&nbsp;&nbsp; http::status NotFoundRequest(std::string error, http::response<http::string_body> &response) const;

&nbsp;&nbsp;&nbsp;&nbsp; std::string GetPath(const http::request<http::string_body> &request) const;

&nbsp;&nbsp;&nbsp;&nbsp; std::string GetMIMEType(const std::string &path) const;
    
&nbsp;&nbsp;&nbsp;&nbsp; std::string root_;

};



