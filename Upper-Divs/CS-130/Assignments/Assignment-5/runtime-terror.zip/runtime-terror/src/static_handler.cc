#include "static_handler.h"

StaticHandler::StaticHandler(const std::string &uri, const std::string &root) : uri_(uri), root_(root) {}

/*
    Generates a response containing the requested file if it exists

    @return a response containing the requested file, or an error response if
            the file was not found
*/
Response StaticHandler::GenerateResponse(const Request &request) const
{
    // Get the full path of the file
    std::string rel_path = GetPath(request);
    std::string full_path = ".." + root_ + rel_path;

    // Check if file exists and is not a directory
    boost::filesystem::path boost_path(full_path);
    if (!boost::filesystem::exists(boost_path) || !boost::filesystem::is_regular_file(full_path))
    {
        return NotFoundRequest("The file doesn't exist\r\n");
    }

    // Open file
    std::ifstream file(full_path.c_str(), std::ios::in | std::ios::binary);
    if (!file)
    {
        return NotFoundRequest("The file is corrupted\r\n");
    }

    // Read file contents into string
    std::string content;
    file.seekg(0, std::ios::end);
    content.resize(file.tellg());
    file.seekg(0, std::ios::beg);
    file.read(&content[0], content.size());
    file.close();

    // Form response
    Response response(Response::OK, content);
    response.AddHeader("Content-Type", GetMIMEType(rel_path));
    response.AddHeader("Content-Length", std::to_string(content.size()));
    return response;
}

/*
    Returns a response indicating a 404 error occurred

    @param error the string detailing the error
*/
Response StaticHandler::NotFoundRequest(std::string error) const
{
    Response response(Response::NOT_FOUND, error);
    response.AddHeader("Content-Type", "text/plain");
    response.AddHeader("Content-Length", std::to_string(error.size()));
    return response;
}

/*
    Extracts the relative path from the request, removing the URI

    @return a string containing the path relative to the root
*/
std::string StaticHandler::GetPath(const Request &request) const
{
    std::string full_uri = request.GetRequestURI();
    return full_uri.substr(uri_.size());
}

/*
    Gets the MIME type of a file

    @param path a string containing the file's relative path
    @return a string containing the MIME type of the file
*/
std::string StaticHandler::GetMIMEType(const std::string &path) const
{
    // Extract the file extension
    int extension_start = path.find(".");
    std::string extension = path.substr(extension_start + 1);

    // Find the correct MIME type
    if (extension == "html")
    {
        return "text/html";
    }
    else if (extension == "jpg" || extension == "jpeg")
    {
        return "image/jpeg";
    }
    else if (extension == "txt")
    {
        return "text/plain";
    }
    else if (extension == "zip")
    {
        return "application/zip";
    }
    else if (extension == "gif")
    {
        return "image/gif";
    }
    else
    {
        return "application/octet-stream";
    }
}