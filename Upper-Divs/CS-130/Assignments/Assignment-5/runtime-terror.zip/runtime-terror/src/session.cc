#include "session.h"

session::session(boost::asio::io_service &io_service, std::shared_ptr<ServerTools> tools)
    : socket_(io_service),
      tools_(tools) {}

tcp::socket &session::socket()
{
    return socket_;
}

void session::start()
{
    async_read_until(socket_, buffer_, "\r\n\r\n",
                     boost::bind(&session::handle_read, this,
                                 boost::asio::placeholders::error,
                                 boost::asio::placeholders::bytes_transferred));
    started = true;
}

void session::handle_read(const boost::system::error_code &error,
                          size_t bytes_transferred)
{

    if (!error)
    {
        // Get request
        std::ostringstream request_oss;
        request_oss << &buffer_;
        std::string request_str = request_oss.str();
        Request request(request_str);
        tools_->logger->logInfo("Request: " + request.GetRequestURI());

        // Generate response from correct handler
        Response response = tools_->dispatcher->DispatchRequest(request);
        response_str = response.ToString();

        // TODO: Move this logging into StaticHandler
        if (response_str.find("The file doesn't exist\r\n") != std::string::npos) // This is garbage code I know, but didn't want to cause merge conflicts with StaticHandler class
            tools_->logger->logWarning("File doesn't exist at URI: " + request.GetRequestURI());
        if (response_str.find("The file is corrupted\r\n") != std::string::npos) // This is garbage code I know, but didn't want to cause merge conflicts with StaticHandler class
            tools_->logger->logWarning("File at URI: " + request.GetRequestURI() + " is corrupted.");
        if (request_str.empty() || request.GetRequestURI() == "/favicon.ico")
        {
            response_str = "";
        }

        // Write response to socket
        boost::asio::async_write(socket_,
                                 boost::asio::buffer(response_str.c_str(), response_str.size()),
                                 boost::bind(&session::handle_write, this,
                                             boost::asio::placeholders::error));
    }
    else
    {
        delete this;
        tools_->logger->logInfo("Server session terminated");
    }
}

void session::handle_write(const boost::system::error_code &error)
{
    if (!error)
    {
        try
        {
            tools_->logger->logInfo("IP: " + socket_.remote_endpoint().address().to_string());
        }
        catch (boost::system::system_error const &e)
        {
            std::cout << e.what() << ": " << e.code() << " - " << e.code().message() << std::endl;
        }
        wrote = true;
        async_read_until(socket_, buffer_, "\r\n\r\n",
                         boost::bind(&session::handle_read, this,
                                     boost::asio::placeholders::error,
                                     boost::asio::placeholders::bytes_transferred));
    }
    else
    {
        delete this;
        tools_->logger->logInfo("Server session terminated");
    }
}