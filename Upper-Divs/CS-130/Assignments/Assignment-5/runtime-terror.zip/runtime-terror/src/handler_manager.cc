#include "handler_manager.h"

HandlerManager::HandlerManager(const std::vector<Location> &locations)
{
    bad_handler_ = std::shared_ptr<BadHandler>(new BadHandler());
    for (const Location &location : locations)
    {
        AssignHandler(location);
    }
}

/*
    Fetches the corresponding RequestHandler to a given URI

    @param url a string containing the URI that needs a handler
    @return a pointer to the corresponding RequestHandler if the URI mapping
            exists, or a BadHandler object if the it doesn't
*/
std::shared_ptr<RequestHandler> HandlerManager::GetHandler(const std::string &uri) const
{
    for (int len = uri.size(); len > 0; len--)
    {
        std::string uri_substr = uri.substr(0, len);
        auto handler = handler_map_.find(uri_substr);
        if (handler != handler_map_.end())
        {
            return handler->second;
        }
    }
    bad_handler_->SetError("Invalid URI");
    return bad_handler_;
}

/*
    Constructs the correct RequestHandler object based on the handler specified
    in the location config

    @param handler a string that details the desired handler object
    @param root a string that defines
    @return a pointer to the RequestHandler object that corresponds to the
            config, or a null pointer if the string is badly formatted/unknown
*/
std::shared_ptr<RequestHandler> HandlerManager::CreateHandler(const Location &location) const
{
    if (location.handler == "echo")
    {
        return std::shared_ptr<RequestHandler>(new EchoHandler());
    }
    else if (location.handler == "static")
    {
        return std::shared_ptr<RequestHandler>(new StaticHandler(location.uri, location.root));
    }
    else
    {
        return NULL;
    }
}

/*
    Creates a (URI -> RequestHandler) mapping based on a Location object if the
    URI is not already in use

    @param location a Location object that specifies the mapping details
*/
void HandlerManager::AssignHandler(const Location &location)
{
    std::shared_ptr<RequestHandler> handler = CreateHandler(location);
    if (handler)
    {
        handler_map_.insert(std::make_pair(location.uri, handler));
    }
}