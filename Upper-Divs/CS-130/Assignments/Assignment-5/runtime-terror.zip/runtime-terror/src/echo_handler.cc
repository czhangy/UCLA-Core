#include "echo_handler.h"

/*
    Generates an echoed response

    @return a response that matches the incoming request
*/
Response EchoHandler::GenerateResponse(const Request &request) const
{
    std::string request_str = request.ToString();
    Response response(Response::OK, request_str);
    response.AddHeader("Content-Type", "text/plain");
    response.AddHeader("Content-Length", std::to_string(request_str.size()));
    return response;
}
