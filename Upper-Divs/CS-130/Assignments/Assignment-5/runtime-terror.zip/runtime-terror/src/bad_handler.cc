#include "bad_handler.h"

/*
    Generates a bad response

    @param request the invalid HTTP request
    @return a response that outputs the error detected
*/
Response BadHandler::GenerateResponse(const Request &request) const
{
    Response response(Response::BAD, error_);
    response.AddHeader("Content-Type", "text/plain");
    response.AddHeader("Content-Length", std::to_string(error_.size()));
    return response;
}

/*
    Sets the error state of the handler

    @param error the string detailing the error
*/
void BadHandler::SetError(std::string error)
{
    error_ = error;
}
