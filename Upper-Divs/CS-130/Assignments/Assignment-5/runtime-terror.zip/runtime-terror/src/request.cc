#include "request.h"

Request::Request(const std::string &request) : request_(request) {}

/*
    Gets the request in string format

    @return a string containing the original request
*/
std::string Request::ToString() const
{
    return request_;
}

/*
    Gets the URI the request was sent to

    @return a string of the form "/${URI}"
*/
std::string Request::GetRequestURI() const
{
    std::string uri;
    std::size_t begin = request_.find("/");
    for (int i = begin; i < request_.size() && !isspace(request_[i]); i++)
    {
        uri += request_[i];
    }
    return uri;
}
