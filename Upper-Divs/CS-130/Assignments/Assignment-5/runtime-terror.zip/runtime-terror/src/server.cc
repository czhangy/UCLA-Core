#include "server.h"

server::server(boost::asio::io_service &io_service, unsigned short port, std::shared_ptr<ServerTools> tools)
    : io_service_(io_service),
      acceptor_(io_service, tcp::endpoint(tcp::v4(), port)),
      tools_(tools)
{
    start_accept();
    tools_->logger->logInfo("Server started");
}

void server::start_accept()
{
    session *new_session = new session(io_service_, tools_);
    acceptor_.async_accept(new_session->socket(),
                           boost::bind(&server::handle_accept, this, new_session,
                                       boost::asio::placeholders::error));
    started = true;
}

void server::handle_accept(session *new_session,
                           const boost::system::error_code &error)
{
    if (!error)
    {
        new_session->start();
        handled = true;
        tools_->logger->logInfo("New server session accepted");
    }
    else
    {
        tools_->logger->logWarning("New server session was not properly handled");
        delete new_session;
    }

    start_accept();
}
