//
// async_tcp_echo_server.cpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2017 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/asio.hpp>
#include <cstdlib>
#include <string>
#include <iostream>
#include "config_parser.h"
#include "config_reader.h"
#include "handler_manager.h"
#include "logger.h"
#include "server.h"
#include "server_tools.h"

int main(int argc, char *argv[])
{
    try
    {
        // Create logger
        std::unique_ptr<Logger> logger(new Logger());

        // Check for valid args
        if (argc != 2)
        {
            logger->logFatal("Invalid args");
            return 1;
        }

        // Parse the config file
        NginxConfigParser config_parser;
        NginxConfig config;
        if (!config_parser.Parse(argv[1], &config))
        {
            logger->logFatal("Invalid config file");
            return 1;
        }

        // Read the config file
        ConfigReader config_reader(&config);
        logger->logInfo("Config file parsed succesfully");

        // Create server tools
        std::shared_ptr<ServerTools> tools(new ServerTools());
        std::unique_ptr<HandlerManager> handler_manager(new HandlerManager(config_reader.GetLocations()));
        tools->dispatcher = std::unique_ptr<Dispatcher>(new Dispatcher(std::move(handler_manager)));
        tools->logger = std::move(logger);

        // Extract port
        if (config_reader.GetPort() == 0)
        {
            std::cerr << "Valid port not found\n";
            tools->logger->logFatal("Valid port not found");
            return 1;
        }

        // Start server
        boost::asio::io_service io_service;
        server s(io_service, config_reader.GetPort(), tools);
        io_service.run();
    }
    catch (std::exception &e)
    {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}
