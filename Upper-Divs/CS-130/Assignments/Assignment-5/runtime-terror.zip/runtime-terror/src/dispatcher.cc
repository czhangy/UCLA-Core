#include "dispatcher.h"

Dispatcher::Dispatcher(std::unique_ptr<HandlerManager> handler_manager) : handler_manager_(std::move(handler_manager)) {}

/*
    Dispatches a request to the correct handler and retrieves the response

    @param request a well-formatted Request object
    @return a Response object that responds to the HTTP request
*/
Response Dispatcher::DispatchRequest(const Request &request) const
{
    std::string uri = request.GetRequestURI();
    std::shared_ptr<RequestHandler> handler = handler_manager_->GetHandler(uri);
    return handler->GenerateResponse(request);
}
