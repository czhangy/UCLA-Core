#!/bin/bash

EXPECTED_RES_PATH=../tests/integration_tests/files/expected_echo_res
TEST_RES_PATH=../tests/integration_tests/files/test_echo_res
SERVER_URL=http://localhost:8080/echo
CURL_VERSION=$(curl --version | head -n 1 | awk '{ print $2 }')

# Dynamically generate the expected response
echo "GET /echo HTTP/1.1
Host: localhost:8080
User-Agent: curl/${CURL_VERSION}
Accept: */*
" > "$EXPECTED_RES_PATH"

# Send and capture the response, allowing a maximum of 5s
timeout 5 curl -s "$SERVER_URL" > "$TEST_RES_PATH"

# Compare expected and test outputs and capture diff
diff -w -B "$EXPECTED_RES_PATH" "$TEST_RES_PATH" &>/dev/null
DIFF=$?

# Output if test was successful
if [ "$DIFF" -eq 0 ]
then
    echo -e "\e[1;32mEcho test passed!\e[0m"
else
    echo -e "\e[1;31mEcho test failed!\e[0m"
    echo "---------------------------------------------"
    echo "Expected response:"
    cat "$EXPECTED_RES_PATH"
    echo "---------------------------------------------"
    echo "Actual response:"
    cat "$TEST_RES_PATH"
    echo "---------------------------------------------"
fi

# Exit with corresponding code
exit "$DIFF"
