#!/bin/bash

# This file should be run from within the build/ directory

CONFIG_PATH=../tests/integration_tests/files/config
EXIT=0
FAILED=0
NUM_TESTS=2

# Clear existing files
rm -rf ../tests/integration_tests/files
mkdir ../tests/integration_tests/files

# Dynamically generate the config file
echo "http {
    server {
        listen 8080;

        location /echo {
            handler echo;
        }

        location /static1 {
            handler static;
            root /static/static1;
        }

        location /static2 {
            handler static;
            root /static/static2;
        }
    }
}" > "$CONFIG_PATH"

# Start webserver in background
echo -e "\nStarting webserver..."
./bin/webserver "$CONFIG_PATH" &
sleep 1

# Run test for echo functionality and capture success/failure
echo -e "\nTesting echo functionality..."
../tests/integration_tests/echo_test.sh
((FAILED+=$?))

# Run test for static functionality and capture success/failure
echo -e "\nTesting static functionality..."
../tests/integration_tests/static_test.sh
((FAILED+=$?))

# Shut down webserver
echo -e "\nShutting down webserver..."
pkill webserver

# Output number of successful tests
if [ "$FAILED" -eq 0 ]
then
    echo -en "\n\e[1;32m"
else
    echo -en "\n\e[1;31m"
    EXIT=1
fi
TESTS_PASSED=$((NUM_TESTS-FAILED))
echo -e "${TESTS_PASSED}/2 tests passed!\e[0m\n"

# Exit script
exit "$EXIT"
