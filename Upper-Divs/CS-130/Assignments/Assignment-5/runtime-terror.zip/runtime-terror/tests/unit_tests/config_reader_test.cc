#include "gtest/gtest.h"
#include "config_reader.h"

// Test fixture
class ConfigReaderTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
};

// Unit tests
TEST_F(ConfigReaderTest, GetPort)
{
    parser_.Parse("../mocks/configs/normal_config", &config_);
    ConfigReader reader(&config_);
    unsigned short port = reader.GetPort();
    EXPECT_EQ(port, 80);
}

TEST_F(ConfigReaderTest, MissingListen)
{
    parser_.Parse("../mocks/configs/empty_config", &config_);
    ConfigReader reader(&config_);
    unsigned short port = reader.GetPort();
    EXPECT_EQ(port, 0);
}

TEST_F(ConfigReaderTest, InvalidPort)
{
    parser_.Parse("../mocks/configs/quoted_string", &config_);
    ConfigReader reader(&config_);
    unsigned short port = reader.GetPort();
    EXPECT_EQ(port, 0);
}

TEST_F(ConfigReaderTest, GetLocations)
{
    parser_.Parse("../mocks/configs/normal_config", &config_);
    ConfigReader reader(&config_);
    std::vector<Location> locations = reader.GetLocations();
    ASSERT_EQ(locations.size(), 1);
    EXPECT_EQ(locations[0].uri, "/static");
    EXPECT_EQ(locations[0].handler, "static");
}

TEST_F(ConfigReaderTest, MissingURI)
{
    parser_.Parse("../mocks/configs/invalid_location", &config_);
    ConfigReader reader(&config_);
    std::vector<Location> locations = reader.GetLocations();
    ASSERT_EQ(locations.size(), 0);
}

TEST_F(ConfigReaderTest, ExtraLocationField)
{
    parser_.Parse("../mocks/configs/extra_location_field", &config_);
    ConfigReader reader(&config_);
    std::vector<Location> locations = reader.GetLocations();
    ASSERT_EQ(locations.size(), 0);
}

TEST_F(ConfigReaderTest, DefaultRoot)
{
    parser_.Parse("../mocks/configs/default_root", &config_);
    ConfigReader reader(&config_);
    std::vector<Location> locations = reader.GetLocations();
    ASSERT_EQ(locations.size(), 1);
    EXPECT_EQ(locations[0].root, "/");
}
