#include "gtest/gtest.h"
#include "response.h"

// Test fixture
class ResponseTest : public ::testing::Test
{
protected:
    std::string body_ = "Hello World";
};

// Unit tests
TEST_F(ResponseTest, StatusString)
{
    Response ok = Response(Response::OK, body_);
    Response bad = Response(Response::BAD, body_);
    EXPECT_EQ(ok.GetStatusString(), "200 OK");
    EXPECT_EQ(bad.GetStatusString(), "400 Bad Request");
}

TEST_F(ResponseTest, ToString)
{
    Response response = Response(Response::OK, body_);
    response.AddHeader("Content-Type", "text/plain");
    response.AddHeader("Content-Length", std::to_string(body_.size()));
    std::string response_str = response.ToString();
    EXPECT_EQ(response_str, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nHello World");
}
