#include "gtest/gtest.h"
#include "dispatcher.h"

// Test fixture
class DispatcherTest : public ::testing::Test
{
protected:
    Location echo_location_ = {"/echo", "echo", "/"};
    Location null_handler_location_ = {"/abc", "xyz", "/"};
    std::vector<Location> locations_ = {echo_location_, null_handler_location_};
    std::unique_ptr<HandlerManager> handler_manager_ = std::unique_ptr<HandlerManager>(new HandlerManager(locations_));
    Dispatcher dispatcher_ = Dispatcher(std::move(handler_manager_));
};

// Unit tests
TEST_F(DispatcherTest, OKRequest)
{
    std::string request_str = "GET /echo HTTP/1.1\r\n";
    std::string expected_res = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 20\r\n\r\nGET /echo HTTP/1.1\r\n";
    Request request(request_str);
    std::string response = dispatcher_.DispatchRequest(request).ToString();
    EXPECT_EQ(response, expected_res);
}

TEST_F(DispatcherTest, UndefinedHandler)
{
    std::string request_str = "GET /abc HTTP/1.1\r\n";
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nInvalid URI";
    Request request(request_str);
    std::string response = dispatcher_.DispatchRequest(request).ToString();
    EXPECT_EQ(response, expected_res);
}

TEST_F(DispatcherTest, UndefinedURI)
{
    std::string request_str = "GET /bad HTTP/1.1\r\n";
    std::string expected_res = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nInvalid URI";
    Request request(request_str);
    std::string response = dispatcher_.DispatchRequest(request).ToString();
    EXPECT_EQ(response, expected_res);
}