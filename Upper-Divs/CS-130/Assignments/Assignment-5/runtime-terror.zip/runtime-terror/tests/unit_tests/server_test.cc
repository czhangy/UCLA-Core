#include "gtest/gtest.h"
#include "server.h"

class ServerTest : public ::testing::Test
{
protected:
    boost::asio::io_service io_service_;
    short port_ = 8080;
    std::shared_ptr<ServerTools> tools_ = std::shared_ptr<ServerTools>(new ServerTools());
    std::vector<Location> locations_;
    std::unique_ptr<HandlerManager> handler_manager_ = std::unique_ptr<HandlerManager>(new HandlerManager(locations_));
};

// Test for start accept
TEST_F(ServerTest, StartAccept)
{
    tools_->dispatcher = std::unique_ptr<Dispatcher>(new Dispatcher(std::move(handler_manager_)));
    server test_server(io_service_, port_, tools_);
    test_server.start_accept();
    EXPECT_TRUE(test_server.started);
}

// Test for handle accept
TEST_F(ServerTest, HandleAccept)
{
    tools_->dispatcher = std::unique_ptr<Dispatcher>(new Dispatcher(std::move(handler_manager_)));
    server test_server(io_service_, port_, tools_);
    session *test_session = new session(io_service_, tools_);
    test_server.handle_accept(test_session, boost::system::error_code());
    EXPECT_TRUE(test_server.handled);
}