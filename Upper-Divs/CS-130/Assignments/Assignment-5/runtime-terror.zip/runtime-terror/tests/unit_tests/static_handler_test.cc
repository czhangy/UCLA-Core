#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "static_handler.h"

using ::testing::HasSubstr;

// Test fixture
class StaticHandlerTest : public ::testing::Test
{
protected:
    StaticHandler static_handler_ = StaticHandler("/static", "/mocks/static_files");
    std::string invalid_request_ = "GET /static/abc.txt HTTP/1.1";
    std::string txt_request_ = "GET /static/test.txt HTTP/1.1";
    std::string html_request_ = "GET /static/test.html HTTP/1.1";
    std::string jpeg_request_ = "GET /static/dog.jpg HTTP/1.1";
    std::string zip_request_ = "GET /static/testfile.zip HTTP/1.1";
    std::string gif_request_ = "GET /static/cat.gif HTTP/1.1";
};

// Unit tests
TEST_F(StaticHandlerTest, GenerateResponseSuccess)
{
    Request request = Request(txt_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_EQ(response, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 51\r\n\r\nThis is a test file for .txt extension in /static1.");
}

TEST_F(StaticHandlerTest, GenerateResponseFail)
{
    Request request = Request(invalid_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_EQ(response, "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 24\r\n\r\nThe file doesn't exist\r\n");
}

TEST_F(StaticHandlerTest, MIMETypeHTML)
{
    Request request = Request(html_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_THAT(response, HasSubstr("Content-Type: text/html"));
}

TEST_F(StaticHandlerTest, MIMETypeJPEG)
{
    Request request = Request(jpeg_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_THAT(response, HasSubstr("Content-Type: image/jpeg"));
}

TEST_F(StaticHandlerTest, MIMETypeTXT)
{
    Request request = Request(txt_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_THAT(response, HasSubstr("Content-Type: text/plain"));
}

TEST_F(StaticHandlerTest, MIMETypeZIP)
{
    Request request = Request(zip_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_THAT(response, HasSubstr("Content-Type: application/zip"));
}

TEST_F(StaticHandlerTest, MIMETypeGIF_)
{
    Request request = Request(gif_request_);
    std::string response = static_handler_.GenerateResponse(request).ToString();
    EXPECT_THAT(response, HasSubstr("Content-Type: image/gif"));
}
