#include "gtest/gtest.h"
#include "echo_handler.h"

// Test fixture
class EchoHandlerTest : public ::testing::Test
{
protected:
    std::string request_str_ = "GET /echo HTTP/1.1";
    Request request_ = Request(request_str_);
    EchoHandler echo_handler_;
};

// Unit tests
TEST_F(EchoHandlerTest, GenerateResponse)
{
    std::string response = echo_handler_.GenerateResponse(request_).ToString();
    EXPECT_EQ(response, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 18\r\n\r\nGET /echo HTTP/1.1");
}
