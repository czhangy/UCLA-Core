#include "gtest/gtest.h"
#include "bad_handler.h"

// Test fixture
class BadHandlerTest : public ::testing::Test
{
protected:
    std::string request_str_ = "";
    Request request_ = Request(request_str_);
    BadHandler bad_handler_ = BadHandler();
};

// Unit tests
TEST_F(BadHandlerTest, GenerateResponse)
{
    bad_handler_.SetError("Error");
    std::string res = bad_handler_.GenerateResponse(request_).ToString();
    EXPECT_EQ(res, "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 5\r\n\r\nError");
}
