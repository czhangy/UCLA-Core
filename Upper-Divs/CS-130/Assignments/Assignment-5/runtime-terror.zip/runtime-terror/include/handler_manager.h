#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include "bad_handler.h"
#include "echo_handler.h"
#include "location.h"
#include "request_handler.h"
#include "static_handler.h"

class HandlerManager
{
public:
    HandlerManager(const std::vector<Location> &locations);
    std::shared_ptr<RequestHandler> GetHandler(const std::string &uri) const;

private:
    std::shared_ptr<RequestHandler> CreateHandler(const Location &location) const;
    void AssignHandler(const Location &location);

    std::unordered_map<std::string, std::shared_ptr<RequestHandler>> handler_map_;
    std::shared_ptr<BadHandler> bad_handler_;
};