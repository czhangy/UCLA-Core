#pragma once

#include <string>
#include "request.h"
#include "response.h"

class RequestHandler
{
public:
    virtual Response GenerateResponse(const Request &request) const = 0;
};
