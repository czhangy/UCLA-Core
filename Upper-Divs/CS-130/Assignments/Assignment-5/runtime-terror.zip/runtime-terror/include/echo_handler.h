#pragma once

#include <string>
#include "request.h"
#include "request_handler.h"
#include "response.h"

class EchoHandler : public RequestHandler
{
public:
    Response GenerateResponse(const Request &request) const;
};