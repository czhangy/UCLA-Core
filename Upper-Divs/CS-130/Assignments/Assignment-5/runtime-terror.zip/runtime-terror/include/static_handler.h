#pragma once

#include <boost/asio.hpp>
#include <boost/filesystem.hpp>
#include <fstream>
#include <string>
#include "request_handler.h"
#include "response.h"

class StaticHandler : public RequestHandler
{
public:
    StaticHandler(const std::string &uri, const std::string &root);
    Response GenerateResponse(const Request &request) const;

private:
    Response NotFoundRequest(std::string error) const;
    std::string GetPath(const Request &request) const;
    std::string GetMIMEType(const std::string &path) const;

    std::string uri_;
    std::string root_;
};
