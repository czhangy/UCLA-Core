#pragma once

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <memory>
#include "dispatcher.h"
#include "logger.h"
#include "server_tools.h"
#include "session.h"

using boost::asio::ip::tcp;

class server
{
public:
    server(boost::asio::io_service &io_service, unsigned short port, std::shared_ptr<ServerTools> tools);
    void start_accept();
    void handle_accept(session *new_session,
                       const boost::system::error_code &error);

    // Testing flags
    bool started = false;
    bool handled = false;

private:
    boost::asio::io_service &io_service_;
    tcp::acceptor acceptor_;
    std::shared_ptr<ServerTools> tools_;
};