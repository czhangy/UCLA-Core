#pragma once

#include <string>

class Request
{
public:
    Request(const std::string &request);
    std::string ToString() const;
    std::string GetRequestURI() const;

private:
    std::string request_;
};