#pragma once

#include <memory>
#include "handler_manager.h"
#include "request.h"
#include "request_handler.h"
#include "response.h"

class Dispatcher
{
public:
    Dispatcher(std::unique_ptr<HandlerManager> handler_manager);
    Response DispatchRequest(const Request &request) const;

private:
    std::unique_ptr<HandlerManager> handler_manager_;
};
