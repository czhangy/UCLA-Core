#include "gtest/gtest.h"
#include "config_parser.h"
#include "config_reader.h"

// Test fixture
class ConfigReaderTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig config_;
};

// Unit tests
TEST_F(ConfigReaderTest, SimpleDirective)
{
    parser_.Parse("../mocks/configs/simple_directive", &config_);
    NginxConfigReader reader(&config_);
    int port = reader.GetPort();
    EXPECT_EQ(port, 80);
}

TEST_F(ConfigReaderTest, BlockDirective)
{
    parser_.Parse("../mocks/configs/block_directive", &config_);
    NginxConfigReader reader(&config_);
    int port = reader.GetPort();
    EXPECT_EQ(port, 80);
}

TEST_F(ConfigReaderTest, NestedDirective)
{
    parser_.Parse("../mocks/configs/nested_directive", &config_);
    NginxConfigReader reader(&config_);
    int port = reader.GetPort();
    EXPECT_EQ(port, 80);
}

TEST_F(ConfigReaderTest, MissingListen)
{
    parser_.Parse("../mocks/configs/empty_config", &config_);
    NginxConfigReader reader(&config_);
    int port = reader.GetPort();
    EXPECT_EQ(port, 0);
}

TEST_F(ConfigReaderTest, InvalidPort)
{
    parser_.Parse("../mocks/configs/quoted_string", &config_);
    NginxConfigReader reader(&config_);
    int port = reader.GetPort();
    EXPECT_EQ(port, 0);
}
