#include "gtest/gtest.h"
#include "config_parser.h"

// Test fixture
class ParserTest : public ::testing::Test
{
protected:
    NginxConfigParser parser_;
    NginxConfig out_config_;
};

// Unit tests
TEST_F(ParserTest, SimpleDirective)
{
    bool success = parser_.Parse("../mocks/configs/simple_directive", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, BlockDirective)
{
    bool success = parser_.Parse("../mocks/configs/block_directive", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, MultiDirective)
{
    bool success = parser_.Parse("../mocks/configs/multi_directive", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, MissingSemicolon)
{
    bool failure = !parser_.Parse("../mocks/configs/missing_semicolon", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingOpenBracket)
{
    bool failure = !parser_.Parse("../mocks/configs/missing_open_bracket", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingCloseBracket)
{
    bool failure = !parser_.Parse("../mocks/configs/missing_close_bracket", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, ExtraWhitespace)
{
    bool success = parser_.Parse("../mocks/configs/extra_whitespace", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EmptyConfig)
{
    bool success = parser_.Parse("../mocks/configs/empty_config", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, MissingToken)
{
    bool failure = !parser_.Parse("../mocks/configs/missing_token", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, NestedDirective)
{
    bool success = parser_.Parse("../mocks/configs/nested_directive", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EmptyBlockDirective)
{
    bool success = parser_.Parse("../mocks/configs/empty_block_directive", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, IgnoreComment)
{
    bool success = parser_.Parse("../mocks/configs/ignore_comment", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, ExtraSemicolon)
{
    bool failure = !parser_.Parse("../mocks/configs/extra_semicolon", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingTokenBlock)
{
    bool failure = !parser_.Parse("../mocks/configs/missing_token_block", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, MissingWhitespace)
{
    bool failure = !parser_.Parse("../mocks/configs/missing_whitespace", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, QuotedString)
{
    bool success = parser_.Parse("../mocks/configs/quoted_string", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EscapeSingleQuote)
{
    bool success = parser_.Parse("../mocks/configs/escape_single_quote", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, EscapeDoubleQuote)
{
    bool success = parser_.Parse("../mocks/configs/escape_double_quote", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, PreserveBackslash)
{
    bool success = parser_.Parse("../mocks/configs/preserve_backslash", &out_config_);
    EXPECT_TRUE(success);
}

TEST_F(ParserTest, UnclosedQuote)
{
    bool failure = !parser_.Parse("../mocks/configs/unclosed_quote", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, BadClosingBrace)
{
    bool failure = !parser_.Parse("../mocks/configs/bad_closing_brace", &out_config_);
    EXPECT_TRUE(failure);
}

TEST_F(ParserTest, BadFile)
{
    bool failure = !parser_.Parse("../mocks/configs/bad_file", &out_config_);
    EXPECT_TRUE(failure);
}

// Test for ToString function
TEST_F(ParserTest, ConfigToString)
{
    bool success = parser_.Parse("../mocks/configs/to_string_config", &out_config_);
    EXPECT_TRUE(success);
    std::string config_string = out_config_.ToString(0);
    std::cerr << config_string;
    std::string expect_string = "foo bar;\nhttp {\n  server {\n    listen 80;\n  }\n}\n";
    EXPECT_STREQ(config_string.c_str(), expect_string.c_str());
}
