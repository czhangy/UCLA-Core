#include "gtest/gtest.h"
#include "server.h"
#include "session.h"
#include "config_parser.h"
#include <boost/asio.hpp>

class ServerTest : public ::testing::Test
{
	protected:
        short port = 8080;
		boost::asio::io_service io_service;
};

// Test for start accept
TEST_F(ServerTest, StartAccept)
{
	server test_server(io_service, port);
    test_server.start_accept();
    EXPECT_TRUE(test_server.started);
}

// Test for handle accept
TEST_F(ServerTest, HandleAccept)
{
    session *test_session = new session(io_service);
	server test_server(io_service, port);
    test_server.handle_accept(test_session, boost::system::error_code());
    EXPECT_TRUE(test_server.handled);
}