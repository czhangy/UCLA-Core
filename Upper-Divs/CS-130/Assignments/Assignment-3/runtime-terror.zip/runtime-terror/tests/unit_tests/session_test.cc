#include "gtest/gtest.h"
#include "session.h"
#include <string>

class SessionTest : public ::testing::Test
{
	protected:
		boost::asio::io_service io_service;
};


//Test for start
TEST_F(SessionTest, StartSession)
{
    session test_session(io_service);
    test_session.start();
    EXPECT_TRUE(test_session.started);
}

//Test for handle_read
TEST_F(SessionTest, SessionHandleRead)
{
    session test_session(io_service);
    std::ostream os(&test_session.buffer_);
    const std::string request = "GET / HTTP/1.1";
    os << request;
    test_session.handle_read(boost::system::error_code(), request.size());
    std::string response = test_session.http_res;
    std::string exp_response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: " + std::to_string(request.size()) + "\r\n\r\nGET / HTTP/1.1";
    EXPECT_EQ(exp_response, response);	
}

//Test for handle_write
TEST_F(SessionTest, SessionHandleWrite)
{
    session test_session(io_service);
    std::ostream os(&test_session.buffer_);
    std::string request = "hello\r\n\r\n";
    os << request;
    test_session.handle_read(boost::system::error_code(), request.size());
    boost::system::error_code ec;
    test_session.handle_write(ec);
    EXPECT_TRUE(test_session.read);
}