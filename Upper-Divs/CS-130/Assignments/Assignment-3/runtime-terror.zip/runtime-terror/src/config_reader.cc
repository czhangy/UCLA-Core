#include <queue>

#include "config_reader.h"

NginxConfigReader::NginxConfigReader(NginxConfig *config) : config_(config) {}

int NginxConfigReader::GetPort()
{
    // Queue to search for shallowest "listen"
    std::queue<NginxConfig *> config_queue;
    config_queue.push(config_);
    while (!config_queue.empty())
    {
        NginxConfig *current_config = config_queue.front();
        config_queue.pop();
        // Iterate over each statement, looking for "listen"
        for (std::shared_ptr<NginxConfigStatement> statement : current_config->statements_)
        {
            if (statement->tokens_[0] == "listen")
            {
                try
                {
                    int port = std::atoi((statement->tokens_[1]).c_str());
                    return port;
                }
                catch (std::exception &e)
                {
                    // Look for valid "listen"
                    continue;
                }
            }
            // Push nested config into queue
            config_queue.push(statement->child_block_.get());
        }
    }
    return 0;
}
