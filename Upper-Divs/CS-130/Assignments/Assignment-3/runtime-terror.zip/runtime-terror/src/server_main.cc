//
// async_tcp_echo_server.cpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2017 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <string>
#include <cstdlib>
#include <iostream>
#include <boost/asio.hpp>
#include "config_parser.h"
#include "config_reader.h"
#include "req_handler.h"
#include "server.h"

int main(int argc, char *argv[])
{
    try
    {
        // These 2 lines don't do anything but ReqHandler fails to link without them :/
        std::string str = "";
        ReqHandler req_h(str);
        // Error out if config file isn't given/extra args are given
        if (argc != 2)
        {
            std::cerr << "Usage: webserver <config_file>\n";
            return 1;
        }

        // Parse config file for port #
        NginxConfigParser config_parser;
        NginxConfig config;
        // Error out if config file is invalid
        if (!config_parser.Parse(argv[1], &config))
        {
            std::cerr << "Invalid config file\n";
            return 1;
        }
        NginxConfigReader config_reader(&config);
        int port = config_reader.GetPort();
        // Error out if port is invalid
        if (port == -1)
        {
            std::cerr << "Valid port not found\n";
            return 1;
        }

        // Start server
        boost::asio::io_service io_service;
        server s(io_service, port);
        io_service.run();
    }
    catch (std::exception &e)
    {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}
