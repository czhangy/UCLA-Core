#pragma once
#include <boost/asio.hpp>
#include "session.h"

using boost::asio::ip::tcp;

class server
{
public:
    server(boost::asio::io_service &io_service, short port);
    // flags for funstions
    bool started = false;
    bool handled = false;
    void start_accept();
    void handle_accept(session *new_session,
                       const boost::system::error_code &error);

private:
    
    boost::asio::io_service &io_service_;
    tcp::acceptor acceptor_;
};