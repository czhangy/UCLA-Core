#pragma once
#include <string>

class ReqHandler
{
public:
    ReqHandler(const std::string &req);
    std::string Respond() const;

private:
    std::string req_;
};