#pragma once
#include "config_parser.h"

class NginxConfigReader
{
public:
    NginxConfigReader(NginxConfig *config);
    int GetPort();

private:
    NginxConfig *config_;
};