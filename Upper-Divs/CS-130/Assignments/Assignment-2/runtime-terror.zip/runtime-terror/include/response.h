#pragma once
#include <string>

class Response
{
public:
    void SetStatus(const std::string &status);
    void AddHeader(std::string header_name, const std::string &header_value);
    void SetBody(const std::string &body);
    std::string GetResponse() const;

private:
    const std::string CRLF = "\r\n";
    std::string status_;
    std::string headers_;
    std::string body_;
};