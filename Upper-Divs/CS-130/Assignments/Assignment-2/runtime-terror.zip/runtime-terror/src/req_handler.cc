#include <istream>
#include <string>

#include "response.h"
#include "req_handler.h"

ReqHandler::ReqHandler(const std::string &req) : req_(req) {}

std::string ReqHandler::Respond() const
{
    // Static content
    std::string status = "200 OK";
    std::string content_type = "text/plain";

    Response res;
    res.SetStatus(status);
    res.AddHeader("Content-Type", content_type);
    res.AddHeader("Content-Length", std::to_string(req_.size()));
    res.SetBody(req_);
    return res.GetResponse();
}
