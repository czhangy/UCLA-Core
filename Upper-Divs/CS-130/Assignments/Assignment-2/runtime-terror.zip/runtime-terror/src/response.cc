#include "response.h"

void Response::SetStatus(const std::string &status)
{
    status_ = "HTTP/1.1 " + status;
}

void Response::AddHeader(std::string header_name, const std::string &header_value)
{
    headers_ += header_name + ": " + header_value + CRLF;
}

void Response::SetBody(const std::string &body)
{
    body_ = body;
}

std::string Response::GetResponse() const
{
    std::string res;
    res += status_ + CRLF;
    res += headers_ + CRLF;
    res += body_;
    return res;
}
