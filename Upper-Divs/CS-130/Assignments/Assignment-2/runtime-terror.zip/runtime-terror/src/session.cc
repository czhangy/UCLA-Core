#include <boost/bind.hpp>
#include <istream>
#include <iostream>
#include <string>

#include "req_handler.h"
#include "session.h"

session::session(boost::asio::io_service &io_service)
    : socket_(io_service) {}

tcp::socket &session::socket()
{
    return socket_;
}

void session::start()
{
    async_read_until(socket_, buffer_, "\r\n\r\n",
                     boost::bind(&session::handle_read, this,
                                 boost::asio::placeholders::error,
                                 boost::asio::placeholders::bytes_transferred));
}

void session::handle_read(const boost::system::error_code &error,
                          size_t bytes_transferred)
{
    if (!error)
    {
        std::string req((std::istreambuf_iterator<char>(&buffer_)), std::istreambuf_iterator<char>());
        ReqHandler req_handler(req);
        std::string http_res = req_handler.Respond();
        boost::asio::async_write(socket_,
                                 boost::asio::buffer(http_res.c_str(), http_res.size()),
                                 boost::bind(&session::handle_write, this,
                                             boost::asio::placeholders::error));
    }
    else
    {
        delete this;
    }
}

void session::handle_write(const boost::system::error_code &error)
{
    if (!error)
    {
        socket_.async_read_some(boost::asio::buffer(data_, max_length),
                                boost::bind(&session::handle_read, this,
                                            boost::asio::placeholders::error,
                                            boost::asio::placeholders::bytes_transferred));
    }
    else
    {
        delete this;
    }
}