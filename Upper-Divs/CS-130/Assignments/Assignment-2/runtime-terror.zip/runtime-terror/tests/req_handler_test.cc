#include "gtest/gtest.h"
#include "req_handler.h"

// Test fixture
class ReqHandlerTest : public ::testing::Test
{
protected:
    std::string req_ = "Hello World";
    ReqHandler req_handler_ = ReqHandler(req_);
};

// Unit tests
TEST_F(ReqHandlerTest, CorrectResponse)
{
    std::string res = req_handler_.Respond();
    EXPECT_EQ(res, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nHello World");
}
