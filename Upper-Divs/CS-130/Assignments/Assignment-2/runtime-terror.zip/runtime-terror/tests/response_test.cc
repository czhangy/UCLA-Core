#include "gtest/gtest.h"
#include "response.h"

// Test fixture
class ResponseTest : public ::testing::Test
{
protected:
    Response res_;
    std::string status_ = "200 OK";
    std::string content_type_ = "text/plain";
    std::string body_ = "Hello World";
};

// Unit tests
TEST_F(ResponseTest, ResponseConstruction)
{
    res_.SetStatus("200 OK");
    res_.AddHeader("Content-Type", content_type_);
    res_.AddHeader("Content-Length", std::to_string(body_.size()));
    res_.SetBody(body_);
    std::string res = res_.GetResponse();
    EXPECT_EQ(res, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 11\r\n\r\nHello World");
}
