# runtime-terror Documentation


## Project Description
runtime-terror is a modern webserver. This project was built with expandability in mind, allowing users to configure their own APIs with ease. Below are instructions on how to build, run, and test the server, as well as how to configure additional APIs consistent with the original design.

## Project Layout
```
.
├── CMakeLists.txt
├── README.md
├── cmake
│   └── CodeCoverageReportConfig.cmake
├── configs
│   ├── dev_config
│   └── docker_server_config
├── docker
│   ├── Dockerfile
│   ├── base.Dockerfile
│   ├── cloudbuild.yaml
│   └── coverage.Dockerfile
├── logs
│   ├── ...
├── include
│   ├── ...
├── mocks
│   ├── configs
│   │   ├── ...
│   ├── dispatcher
│   │   └── ...
│   └── static_files
│       ├── ...
├── src
│   ├── ...
├── static
│   ├── static1
│   │   ├── ...
│   └── static2
│       ├── ...
└── tests
    ├── integration_tests
    │   ├── integration_test.py
    │   ├── static
    │   │   └── ...
    │   ├── test_server.py
    │   └── util.py
    └── unit_tests
        ├── ...
```


## Building, Testing, and Running the Project

### Out-of-source build from the root directory:

```bash
mkdir build
cd build
cmake ..
make
```


### Running tests from the /build directory:
```bash
ctest 		# For simple output
ctest -V 	# For verbose output
```


### Out-of-source coverage build from the root directory:

```bash
mkdir build_coverage
cd build_coverage
cmake -DCMAKE_BUILD_TYPE=Coverage ..
make coverage
```

### Running the webserver from the /build directory:

```bash
bin/webserver ../configs/dev_config
```

## Contributing a Request Handler

### Config File

The new request handler must be registered in `configs/docker_server_config` using the following syntax:

```
location ${PATH} ${HANDLER_NAME} {
	${PARAM_1} ${VALUE_1}
	...
	${PARAM_n} ${VALUE_n}
}
```

- `PATH` is the URL path that the handler will serve on
- `HANDLER_NAME` is the name that will be used to refer to your handler, written in PascalCase
- `PARAM_i` is the name of the `i`th parameter used to construct your handler
- `VALUE_i` is the value assigned to the `i`th parameter

An example `StaticHandler` config might look like:

```
location /static StaticHandler {
	root /foo/bar
}
```

### Header Files

A header file for the new handler should be created in the `include/` directory with the name `${handler_name}.h`. This file should define a class that inherits from `RequestHandler` and contains all definitions needed for your handler.

An example handler header file is shown below:

```c++
// echo_handler.h

#pragma once

#include ...

namespace http = boost::beast::http;

class EchoHandler : public RequestHandler
{
public:
    EchoHandler(const std::string &url, const std::string &location,
                std::shared_ptr<Logger> logger);
    http::status HandleRequest(const http::request<http::string_body> &request,
                               http::response<http::string_body> &response) const;
};
```

- All handler constructors must take in a string containing the URL of the request being served, a string containing the location the handler is serving at, and an `std::shared_ptr` to a `Logger` object
- All handlers must implement the `HandleRequest` method specified by the abstract class `RequestHandler`

Another header file defining the handler's factory should be made in the `include/` directory with the name `${handler_name}_factory.h`. This file should define a class that inherits from `RequestHandlerFactory`.

An example handler factory header file is shown below:

```c++
// echo_handler_factory.h

#pragma once

#include ...

class EchoHandlerFactory : public RequestHandlerFactory
{
public:
    EchoHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;
};
```

- All handler factory constructors must take in a string containing the location the handlers will serve at and and an `std::shared_ptr` to a `Logger` object
- All handler factories must implement the `Create` method specified by the abstract class `RequestHandlerFactory`

### Source Files

Source files of the names `${handler_name}.cc` and `${handler_name}_factory.cc` should be created in the `src/` directory to implement the classes defined in the header files from above. Important events should be logged using the private member variable `logger_` (member functions can be viewed in `include/logger.h`).

Handler implementations are required to construct a valid HTTP response by properly setting the response's status code, content type header, and body content. Body content should be followed by a CRLF, and the handler is expected to call `prepare_payload()` on the response before returning it.

Example source files are shown below:

```c++
// echo_handler.cc

#include "echo_handler.h"

EchoHandler::EchoHandler(const std::string &url, const std::string &location,
                         std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger) {}

http::status EchoHandler::HandleRequest(const http::request<http::string_body> &request,
                                        http::response<http::string_body> &response) const
{
    std::string request_str;
    request_str += boost::lexical_cast<std::string>(request.base());
    request_str += boost::lexical_cast<std::string>(request.body());
    logger_->LogInfo("Generated echo response");
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/plain");
    response.body() = request_str + "\r\n";
    response.prepare_payload();
    return response.result();
}
```

```c++
// echo_handler_factory.cc

#include "echo_handler_factory.h"

EchoHandlerFactory::EchoHandlerFactory(const std::string &location,
                                       std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger) {}

std::shared_ptr<RequestHandler> EchoHandlerFactory::Create(const std::string &url) const
{
    return std::shared_ptr<EchoHandler>(new EchoHandler(url, location_, logger_));
}
```

### Dispatching

To allow the server to recognize your new handler, you must update the dispatcher with your handler's name.

In `include/dispatcher.h`, add a new `const std::string` private member variable of the name `k${HANDLER_NAME}` with the value `"${HANDLER_NAME}"`.

In `src/dispatcher.cc`, locate the `CreateHandlerFactory` function, and add a new else-if statement to check for your new handler, and to create your new handler's factory when it is found.

An example of this process is shown below:

```c++
// dispatcher.h

class Dispatcher
{
private:
    const std::string kStaticHandler = "StaticHandler";
    const std::string kEchoHandler = "EchoHandler";
    ...
};
```

```c++
std::shared_ptr<RequestHandlerFactory> Dispatcher::CreateHandlerFactory(...)
{
    if (handler == kStaticHandler)
    {
        return std::shared_ptr<RequestHandlerFactory>(new StaticHandlerFactory(...));
    }
    else if (handler == kEchoHandler)
    {
        return std::shared_ptr<RequestHandlerFactory>(new EchoHandlerFactory(...));
    }
    ...
}
```

### Testing

A file of the name `${handler_name}_test.cc` should be created in the `tests/unit_tests` directory to unit test your new handler. Unit tests should be written to cover at least the basic functionality of your handler, with test fixtures being used when appropriate.

An additional unit test should also be added to `tests/unit_tests/dispatcher_test.cc` to test your handler's interaction with the overall dispatching mechanism.

An example unit test is shown below:

```c++
// echo_handler_test.cc

#include ...

using ::testing::HasSubstr;

// Test fixture
class EchoHandlerTest : public ::testing::Test
{
protected:
    std::string echo_url_ = "/echo";
    std::string echo_str_ = "GET /echo HTTP/1.1";

    std::string GetResponseString(const std::string &request_url)
    {
        std::string request_str = "GET " + request_url + " HTTP/1.1\r\n";
        EchoHandler echo_handler = EchoHandler(...);
        boost::system::error_code ec;
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        echo_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) +
            boost::lexical_cast<std::string>(response.body());
    }
};

// Unit test
TEST_F(EchoHandlerTest, GenerateResponse)
{
    std::string response_str = GetResponseString(echo_url_);
    EXPECT_THAT(response_str, HasSubstr(echo_str_));
}
```

The functionality of your handler should also be tested in our integration test script. This test can be added in `tests/integration_tests/integration_test.py`.

When adding an integration test, the constant `NUM_TESTS` should be incremented, a concise description of the test should be added as a comment, print statements should be added detailing the results of the test, and the variable `tests_passed` should be incremented by 1 if the test passes.

You must also register your new handler in the integration test's config, which can be done in `tests/integration_tests/util.py` in the `generate_config` function.

An example integration test is shown below:

```python
# integration_test.py

...

# Test Echo 
path = "/echo"
expected_echo = generate_echo_response(hostname=SERVER_HOST, port=SERVER_PORT, path=path)
out, err = curl(SERVER_URL+ ':' + SERVER_PORT + path)
if out.strip() == expected_echo:
	print("ECHO TEST PASSED")
	tests_passed +=1
else:
	print("ECHO TEST FAILED")
...
```

### Compiling and Linking

Finally, `CMakeLists.txt` should be updated with your new handler files.

A library containing your handler and handler factory code, along with their dependencies should be created in the `# Libraries` section. Your library should also be declared as a dependency of `dispatcher`.

A test executable should be created for your unit test in the `# Test executables` section.

Your test executable should be made discoverable by adding it to the `# Test discovery` section.

Your new library and test should be added to the coverage report at the bottom of the file.

An example of this process is shown below:

```cmake
# CMakeLists.txt

...

# Libraries
add_library(echo_handler src/echo_handler.cc)
target_link_libraries(echo_handler request_handler)

add_library(echo_handler_factory src/echo_handler_factory.cc)
target_link_libraries(echo_handler_factory echo_handler request_handler_factory)

add_library(dispatcher src/dispatcher.cc)
target_link_libraries(dispatcher echo_handler_factory ...)
...

# Test executables
add_executable(echo_handler_test tests/unit_tests/echo_handler_test.cc)
target_link_libraries(echo_handler_test echo_handler gmock gtest_main)
...

# Test discovery
gtest_discover_tests(echo_handler_test WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/tests)
...

# Update with target/test targets
include(cmake/CodeCoverageReportConfig.cmake)
generate_coverage_report(TARGETS webserver ... echo_handler echo_handler_factory ...
                         TESTS ... echo_handler_test ...)
```

