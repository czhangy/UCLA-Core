#include "gtest/gtest.h"
#include "mock_filesystem.h"

// Test fixture
class MockFilesystemTest : public ::testing::Test
{
protected:
    MockFilesystem::MockFile file_1_ = {1, "Content 1"};
    MockFilesystem::MockFile file_2_ = {2, "Content 2"};
    std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map_ = {
        {"Entity", {file_1_, file_2_}}};
    MockFilesystem fs_ = MockFilesystem(fs_map_);
};

// Unit tests
TEST_F(MockFilesystemTest, Exists)
{
    EXPECT_TRUE(fs_.Exists("/Entity"));
    EXPECT_TRUE(fs_.Exists("/Entity/1"));
    EXPECT_FALSE(fs_.Exists("/NotEntity"));
    EXPECT_FALSE(fs_.Exists("/Entity/3"));
}

TEST_F(MockFilesystemTest, CreateDirectory)
{
    EXPECT_FALSE(fs_.Exists("/NewEntity"));
    fs_.CreateDirectory("/NewEntity");
    EXPECT_TRUE(fs_.Exists("/NewEntity"));
}

TEST_F(MockFilesystemTest, GetAllEntityIDs)
{
    std::vector<size_t> ids = fs_.GetAllEntityIDs("/Entity");
    std::vector<size_t> expected_ids = {1, 2};
    EXPECT_EQ(ids, expected_ids);
}

TEST_F(MockFilesystemTest, CreateFile)
{
    fs_.CreateFile("/Entity/3", "Content 3");
    std::vector<size_t> expected_ids = {1, 2, 3};
    EXPECT_EQ(fs_.GetAllEntityIDs("/Entity"), expected_ids);
}

TEST_F(MockFilesystemTest, GetData)
{
    EXPECT_EQ(fs_.GetData("/Entity/1"), "Content 1");
}

TEST_F(MockFilesystemTest, GetDataError)
{
    std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> empty_map;
    MockFilesystem empty_fs = MockFilesystem(empty_map);
    EXPECT_TRUE(empty_fs.GetData("/Entity/1").empty());
}

TEST_F(MockFilesystemTest, DeleteFile)
{
    bool success = fs_.DeleteFile("/Entity/1");
    EXPECT_TRUE(success);
    EXPECT_FALSE(fs_.Exists("/Entity/1"));
}

TEST_F(MockFilesystemTest, DeleteFileError)
{
    std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> empty_map;
    MockFilesystem empty_fs = MockFilesystem(empty_map);
    bool failure = !empty_fs.DeleteFile("/Entity/1");
    EXPECT_TRUE(failure);
}
