#include <boost/lexical_cast.hpp>
#include <gmock/gmock.h>
#include "gtest/gtest.h"
#include "mock_filesystem.h"
#include "mock_logger.h"
#include "notes_handler.h"

using ::testing::HasSubstr;

// Test fixture
class NotesHandlerTest : public ::testing::Test
{
protected:
    MockFilesystem::MockFile note_ = {1, "{\"id\": \"1\", \"title\": \"Title\", \"note\": \"Note\"}"};
    MockFilesystem::MockFile bad_note_ = {2, "Not JSON"};
    std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map_ = {
        {"Username", {note_, bad_note_}}};
    std::shared_ptr<MockFilesystem> fs_ = std::make_shared<MockFilesystem>(fs_map_);

    std::string GetResponseString(std::string request_method, std::string request_url, std::string body = "")
    {
        std::string request_str = request_method + " " + request_url + " HTTP/1.1\r\n";
        NotesHandler notes_handler(request_url, "/api", std::make_shared<MockLogger>(), fs_);
        http::request_parser<http::string_body> parser;
        http::response<http::string_body> response;
        boost::system::error_code ec;
        parser.put(boost::asio::buffer(request_str), ec);
        http::request<http::string_body> request = std::move(parser.get());
        request.body() = body;
        notes_handler.HandleRequest(request, response);
        return boost::lexical_cast<std::string>(response.base()) + boost::lexical_cast<std::string>(response.body());
    }
};

// Unit tests
TEST_F(NotesHandlerTest, ServeNotesList)
{
    std::string response_str = GetResponseString("GET", "/notes?username=Username");
    EXPECT_THAT(response_str, HasSubstr("200 OK"));
    EXPECT_THAT(response_str, HasSubstr("{\"id\": \"1\", \"title\": \"Title\", \"note\": \"Note\"}"));
    EXPECT_THAT(response_str, Not(HasSubstr("USERNAME")));
}

TEST_F(NotesHandlerTest, ServeNotesListMissingUser)
{
    std::string response_str = GetResponseString("GET", "/notes?");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(NotesHandlerTest, ServeNotesListUnknownUser)
{
    std::string response_str = GetResponseString("GET", "/notes?username=NotAUsername");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(NotesHandlerTest, CreateNote)
{
    std::string response_str = GetResponseString("POST", "/notes", "{\"username\": \"Username\", \"title\": \"New Title\", \"note\": \"Note\"}");
    EXPECT_THAT(response_str, HasSubstr("201 Created"));
    EXPECT_EQ(fs_->GetAllEntityIDs("/Username").size(), 3);
}

TEST_F(NotesHandlerTest, CreateNoteNewUser)
{
    std::string response_str = GetResponseString("POST", "/notes", "{\"username\": \"NewUser\", \"title\": \"Title\", \"note\": \"Note\"}");
    EXPECT_THAT(response_str, HasSubstr("201 Created"));
    EXPECT_TRUE(fs_->Exists("/NewUser"));
}

TEST_F(NotesHandlerTest, CreateNoteBadRoute)
{
    std::string response_str = GetResponseString("POST", "/notes/bad");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(NotesHandlerTest, CreateNoteInvalidJSON)
{
    std::string response_str = GetResponseString("POST", "/notes", "Not JSON");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(NotesHandlerTest, CreateNoteMissingJSONFields)
{
    std::string response_str = GetResponseString("POST", "/notes", "{\"note\": \"Note\"}");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(NotesHandlerTest, DeleteNote)
{
    std::string response_str = GetResponseString("DELETE", "/notes?username=Username&id=1");
    EXPECT_THAT(response_str, HasSubstr("200 OK"));
    EXPECT_FALSE(fs_->Exists("/Username/1"));
}

TEST_F(NotesHandlerTest, DeleteNoteMissingUser)
{
    std::string response_str = GetResponseString("DELETE", "/notes?id=1");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(NotesHandlerTest, DeleteNoteMissingID)
{
    std::string response_str = GetResponseString("DELETE", "/notes?username=Username");
    EXPECT_THAT(response_str, HasSubstr("400 Bad Request"));
}

TEST_F(NotesHandlerTest, DeleteNoteUnknownUser)
{
    std::string response_str = GetResponseString("DELETE", "/api/username=NotAUsername&id=1");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(NotesHandlerTest, DeleteNoteUnknownID)
{
    std::string response_str = GetResponseString("DELETE", "/notes?username=Username&id=3");
    EXPECT_THAT(response_str, HasSubstr("404 Not Found"));
}

TEST_F(NotesHandlerTest, PUTRequest)
{
    std::string response_str = GetResponseString("PUT", "/notes");
    EXPECT_THAT(response_str, HasSubstr("501 Not Implemented"));
}

TEST_F(NotesHandlerTest, TrailingSlash)
{
    std::string response_str = GetResponseString("POST", "/notes/", "{\"username\": \"Username\", \"title\": \"New Title\", \"note\": \"Note\"}");
    EXPECT_THAT(response_str, HasSubstr("201 Created"));
}
