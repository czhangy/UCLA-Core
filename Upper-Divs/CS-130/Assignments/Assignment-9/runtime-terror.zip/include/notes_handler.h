#pragma once

#include <boost/algorithm/string/replace.hpp>
#include <boost/beast/http.hpp>
#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>
#include <memory>
#include <nlohmann/json.hpp>
#include <string>
#include "filesystem.h"
#include "logger.h"
#include "request_handler.h"

namespace fs = boost::filesystem;
namespace http = boost::beast::http;
typedef nlohmann::json json;

class NotesHandler : public RequestHandler
{
public:
    NotesHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger, std::shared_ptr<Filesystem> fs);
    http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const;

private:
    http::status ServeNotesList(const std::string &target, http::response<http::string_body> &response) const;
    http::status ServeNote(const std::string &target, http::response<http::string_body> &response) const;
    http::status CreateNote(const std::string &target, const std::string &body, http::response<http::string_body> &response) const;
    http::status DeleteNote(const std::string &target, http::response<http::string_body> &response) const;
    http::status ListNotes(const std::string &target, std::vector<std::string> &notes) const;
    std::string ParseURL(const std::string &url, std::string param) const;
    http::status HandleErrorResponse(http::status status, std::string, http::response<http::string_body> &response) const;

    std::shared_ptr<Filesystem> fs_;

    int kTabSize = 4;
};