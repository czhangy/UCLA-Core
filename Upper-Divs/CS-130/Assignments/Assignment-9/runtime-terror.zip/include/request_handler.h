#pragma once

#include <boost/beast/http.hpp>
#include <memory>
#include <string>
#include "logger.h"

namespace http = boost::beast::http;

class RequestHandler
{
public:
    RequestHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger);
    virtual http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const = 0;

protected:
    std::string url_;
    std::string location_;
    std::shared_ptr<Logger> logger_;
};
