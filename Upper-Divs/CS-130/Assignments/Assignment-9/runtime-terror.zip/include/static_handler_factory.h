#pragma once

#include <memory>
#include <string>
#include "nginx_config.h"
#include "logger.h"
#include "request_handler_factory.h"
#include "static_handler.h"

class StaticHandlerFactory : public RequestHandlerFactory
{
public:
    StaticHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;

private:
    std::string root_;
};
