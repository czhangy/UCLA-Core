#pragma once

#include <boost/filesystem.hpp>
#include <memory>
#include <string>
#include "filesystem.h"
#include "logger.h"

namespace fs = boost::filesystem;

class BoostFilesystem : public Filesystem
{
public:
    BoostFilesystem(const std::string &data_path, std::shared_ptr<Logger> logger);
    bool CreateDataPathDir();
    bool Exists(const std::string &entity_path);
    bool CreateDirectory(const std::string &entity_path);
    std::vector<size_t> GetAllEntityIDs(const std::string &entity_path);
    bool CreateFile(const std::string &entity_path, const std::string &content);
    std::string GetData(const std::string &entity_path);
    bool DeleteFile(const std::string &entity_path);

private:
    std::string data_path_;
    std::shared_ptr<Logger> logger_;
};