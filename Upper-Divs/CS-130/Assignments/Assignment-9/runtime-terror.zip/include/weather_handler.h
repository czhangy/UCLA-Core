#pragma once

#include <algorithm>
#include <boost/algorithm/string/replace.hpp>
#include <boost/asio/connect.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/beast/version.hpp>
#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <iostream>
#include <memory>
#include <nlohmann/json.hpp>
#include <string>
#include "logger.h"
#include "request_handler.h"

namespace fs = boost::filesystem;
namespace beast = boost::beast;
namespace http = beast::http;
namespace net = boost::asio;
typedef nlohmann::json json;

class WeatherHandler : public RequestHandler
{
public:
    WeatherHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger);
    http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const;

private:
    http::status ServeInitialForm(http::verb method, http::response<http::string_body> &response) const;
    http::status ServeWeatherForm(http::verb method, const std::string &target, http::response<http::string_body> &response) const;
    std::string ParseURL(const std::string &url, std::string param) const;
    std::string GetWeatherData(const std::string &location, const std::string &units, const std::string &start_date, const std::string &end_date) const;
    http::response<http::string_body> MakeAPICall(std::string host, const std::string &target) const;
    std::pair<std::string, std::string> ParseCoordinates(const http::response<http::string_body> &coordinate_res) const;
    std::vector<float> ParseWeatherData(const http::response<http::string_body> &weather_data) const;
    http::status HandleErrorResponse(http::status status, std::string, http::response<http::string_body> &response) const;
};