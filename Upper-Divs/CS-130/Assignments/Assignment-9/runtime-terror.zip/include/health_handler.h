#pragma once

#include <memory>
#include <string>
#include <boost/beast/http.hpp>
#include "request_handler.h"

namespace http = boost::beast::http;

class HealthHandler : public RequestHandler
{
public:
    HealthHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger);
    http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const;
};