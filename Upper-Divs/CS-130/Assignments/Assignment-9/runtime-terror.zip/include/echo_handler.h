#pragma once

#include <boost/beast/http.hpp>
#include <boost/lexical_cast.hpp>
#include <memory>
#include <string>
#include "logger.h"
#include "request_handler.h"

namespace http = boost::beast::http;

class EchoHandler : public RequestHandler
{
public:
    EchoHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger);
    http::status HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const;
};