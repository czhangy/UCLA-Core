#pragma once

#include <boost/beast/http.hpp>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "crud_handler_factory.h"
#include "echo_handler_factory.h"
#include "health_handler_factory.h"
#include "logger.h"
#include "nginx_config.h"
#include "not_found_handler_factory.h"
#include "notes_handler_factory.h"
#include "request_handler.h"
#include "request_handler_factory.h"
#include "sleep_handler_factory.h"
#include "static_handler_factory.h"
#include "weather_handler_factory.h"

namespace http = boost::beast::http;

class Dispatcher
{
public:
    Dispatcher(const NginxConfig &config, std::shared_ptr<Logger> logger);
    http::response<http::string_body> DispatchRequest(const http::request<http::string_body> &request, std::string ip) const;
    bool ValidateRequest(const http::request<http::string_body> &request) const;

private:
    const std::string kStaticHandler = "StaticHandler";
    const std::string kEchoHandler = "EchoHandler";
    const std::string kNotFoundHandler = "NotFoundHandler";
    const std::string kCrudHandler = "CRUDHandler";
    const std::string kSleepHandler = "SleepHandler";
    const std::string kHealthHandler = "HealthHandler";
    const std::string kWeatherHandler = "WeatherHandler";
    const std::string kNotesHandler = "NotesHandler";

    std::map<std::string, std::shared_ptr<RequestHandlerFactory>> routes_;
    std::shared_ptr<Logger> logger_;

    void AssignHandlerFactories(const NginxConfig &config);
    std::shared_ptr<RequestHandlerFactory> CreateHandlerFactory(const std::string &location, const std::string &handler, const NginxConfig &config);
    std::string Match(const std::string &url) const;
    http::response<http::string_body> FormBadResponse(std::string error) const;
};
