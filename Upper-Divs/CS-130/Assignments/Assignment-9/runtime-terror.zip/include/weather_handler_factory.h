#pragma once

#include <memory>
#include <string>
#include <vector>
#include "logger.h"
#include "request_handler.h"
#include "request_handler_factory.h"
#include "nginx_config.h"
#include "weather_handler.h"

class WeatherHandlerFactory : public RequestHandlerFactory
{
public:
    WeatherHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;
};