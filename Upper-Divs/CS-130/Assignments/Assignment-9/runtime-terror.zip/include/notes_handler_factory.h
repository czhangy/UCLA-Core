#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include "boost_filesystem.h"
#include "logger.h"
#include "mock_filesystem.h"
#include "nginx_config.h"
#include "notes_handler.h"
#include "request_handler.h"
#include "request_handler_factory.h"

class NotesHandlerFactory : public RequestHandlerFactory
{
public:
    NotesHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger);
    std::shared_ptr<RequestHandler> Create(const std::string &url) const;

private:
    const std::string kBoost = "boost";
    const std::string kMock = "mock";

    std::string data_path_;
    std::string filesystem_;
};