#include "boost_filesystem.h"

BoostFilesystem::BoostFilesystem(const std::string &data_path, std::shared_ptr<Logger> logger)
    : data_path_(data_path),
      logger_(logger) {}

bool BoostFilesystem::CreateDataPathDir()
{
    // Construct relative path from build/ directory
    data_path_ = (data_path_[0] == '/' ? ".." : "../") + data_path_;
    fs::path path(data_path_);

    // Ignore if the data path directory already exists
    if (fs::exists(data_path_) && fs::is_directory(data_path_))
    {
        return true;
    }

    // Make the directories if they don't exist
    logger_->LogInfo("BoostFilesystem: data_path " + data_path_.substr(2) + " does not exist, creating directory");
    int len = 2;
    while (len < data_path_.size())
    {
        len = data_path_.find("/", len + 1);
        fs::path new_dir(data_path_.substr(0, len));
        if (!fs::exists(new_dir))
        {
            try
            {
                fs::create_directory(new_dir);
            }
            catch (...)
            {
                return false;
            }
        }
    }
    return true;
}

bool BoostFilesystem::Exists(const std::string &entity_path)
{
    return fs::exists(fs::path(data_path_ + entity_path));
}

bool BoostFilesystem::CreateDirectory(const std::string &entity_path)
{
    try
    {
        fs::create_directory(fs::path(data_path_ + entity_path));
        return true;
    }
    catch (...)
    {
        return false;
    }
}

std::vector<size_t> BoostFilesystem::GetAllEntityIDs(const std::string &entity_path)
{
    std::vector<size_t> ids;
    fs::directory_iterator end;
    for (fs::directory_iterator file(data_path_ + entity_path); file != end; file++)
    {
        if (fs::is_regular_file(*file))
        {
            ids.push_back(stoul(file->path().filename().string()));
        }
    }
    return ids;
}

bool BoostFilesystem::CreateFile(const std::string &entity_path, const std::string &content)
{
    try
    {
        fs::ofstream file(data_path_ + entity_path);
        file << content;
        return true;
    }
    catch (...)
    {
        return false;
    }
}

std::string BoostFilesystem::GetData(const std::string &entity_path)
{
    fs::ifstream file(fs::path(data_path_ + entity_path));
    std::string file_contents((std::istreambuf_iterator<char>(file)),
                              std::istreambuf_iterator<char>());
    return file_contents;
}

bool BoostFilesystem::DeleteFile(const std::string &entity_path)
{
    try
    {
        fs::remove(fs::path(data_path_ + entity_path));
        return true;
    }
    catch (...)
    {
        return false;
    }
}
