#include "notes_handler_factory.h"

NotesHandlerFactory::NotesHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger)
{
    data_path_ = config.GetKeyword("data_path");
    filesystem_ = config.GetKeyword("filesystem");
}

std::shared_ptr<RequestHandler> NotesHandlerFactory::Create(const std::string &url) const
{
    std::shared_ptr<Filesystem> fs;
    if (filesystem_ == kBoost)
    {
        fs = std::make_shared<BoostFilesystem>(data_path_, logger_);
    }
    else
    {
        if (filesystem_ != kMock)
        {
            logger_->LogWarning("NotesHandlerFactory: no valid filesystem specified, defaulting to MockFilesystem");
        }
        std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
        fs = std::make_shared<MockFilesystem>(fs_map);
    }
    if (fs->CreateDataPathDir())
    {
        logger_->LogInfo("NotesHandlerFactory: creating new notes handler with data path " + data_path_ + " serving " + location_);
        return std::make_shared<NotesHandler>(url, location_, logger_, fs);
    }
    else
    {
        logger_->LogFatal("NotesHandlerFactory: failed to create data path directory " + data_path_ + ", exiting");
        return NULL;
    }
}