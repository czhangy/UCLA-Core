#include "dispatcher.h"

Dispatcher::Dispatcher(const NginxConfig &config, std::shared_ptr<Logger> logger) : logger_(logger)
{
    AssignHandlerFactories(config);
}

http::response<http::string_body> Dispatcher::DispatchRequest(const http::request<http::string_body> &request, std::string client_ip) const
{
    if (!ValidateRequest(request))
    {
        return FormBadResponse("Invalid HTTP request");
    }
    http::response<http::string_body> response;
    std::string url = request.target().to_string();
    std::string location = Match(url);
    auto factory_iter = routes_.find(location);
    if (factory_iter == routes_.end())
    {
        return FormBadResponse("No handler has been assigned to serve " + url);
    }
    std::shared_ptr<RequestHandlerFactory> factory = factory_iter->second;
    std::shared_ptr<RequestHandler> handler = factory->Create(url);
    if (handler == NULL)
    {
        return FormBadResponse("The handler serving " + url + " has been configured improperly");
    }
    http::status status = handler->HandleRequest(request, response);
    std::string code = std::to_string(response.result_int());
    std::string req_handler = location.substr(1);
    if (req_handler.empty())
    {
        req_handler = "NotFoundHandler";
    }
    logger_->LogInfo("[ResponseMetrics] {client_ip:" + client_ip + "} {request_path:" + url + "} {request_handler:" + req_handler + "} {request_code:" + code + "}");
    return response;
}

void Dispatcher::AssignHandlerFactories(const NginxConfig &config)
{
    for (auto statement : config.statements_)
    {
        if (statement->tokens_.size() == 3 && statement->tokens_[0] == "location" && statement->child_block_ != NULL)
        {
            std::string location = statement->tokens_[1];
            std::string handler = statement->tokens_[2];
            while (location.size() > 1 && location[location.size() - 1] == '/')
            {
                location.pop_back();
            }
            std::shared_ptr<RequestHandlerFactory> handler_factory = CreateHandlerFactory(location, handler, *statement->child_block_);
            if (handler_factory)
            {
                bool insert_success = routes_.insert(std::make_pair(location, handler_factory)).second;
                if (!insert_success)
                {
                    logger_->LogWarning("Duplicate handler ignored at: " + location);
                }
            }
        }
        if (statement->child_block_ != NULL)
        {
            AssignHandlerFactories(*statement->child_block_);
        }
    }
}

std::shared_ptr<RequestHandlerFactory> Dispatcher::CreateHandlerFactory(const std::string &location, const std::string &handler, const NginxConfig &config)
{
    if (handler == kStaticHandler)
    {
        return std::make_shared<StaticHandlerFactory>(location, config, logger_);
    }
    else if (handler == kEchoHandler)
    {
        return std::make_shared<EchoHandlerFactory>(location, logger_);
    }
    else if (handler == kNotFoundHandler)
    {
        return std::make_shared<NotFoundHandlerFactory>(location, logger_);
    }
    else if (handler == kCrudHandler)
    {
        return std::make_shared<CRUDHandlerFactory>(location, config, logger_);
    }
    else if (handler == kSleepHandler)
    {
        return std::make_shared<SleepHandlerFactory>(location, config, logger_);
    }
    else if (handler == kHealthHandler)
    {
        return std::make_shared<HealthHandlerFactory>(location, logger_);
    }
    else if (handler == kWeatherHandler)
    {
        return std::make_shared<WeatherHandlerFactory>(location, config, logger_);
    }
    else if (handler == kNotesHandler)
    {
        return std::make_shared<NotesHandlerFactory>(location, config, logger_);
    }
    else
    {
        logger_->LogError(handler + " is an unknown handler type and will not be constructed");
        return NULL;
    }
}

std::string Dispatcher::Match(const std::string &url) const
{
    // Trim off query string
    std::string url_substr = url;
    int q_pos = url_substr.rfind("?");
    if (q_pos != std::string::npos)
    {
        url_substr = url_substr.substr(0, q_pos);
    }

    // Prefix matching
    while (!url_substr.empty())
    {
        auto factory_iter = routes_.find(url_substr);
        if (factory_iter != routes_.end())
        {
            logger_->LogInfo("Request for URL " + url + " will be served by handler at: " + url_substr);
            return factory_iter->first;
        }
        int pos = url_substr.rfind("/");
        if (pos == std::string::npos)
        {
            break;
        }
        url_substr = url_substr.substr(0, pos);
    }
    return "/";
}

http::response<http::string_body> Dispatcher::FormBadResponse(std::string error) const
{
    http::response<http::string_body> response;
    response.result(http::status::bad_request);
    response.set(http::field::content_type, "text/plain");
    response.body() = error + "\r\n";
    response.prepare_payload();
    return response;
}

bool Dispatcher::ValidateRequest(const http::request<http::string_body> &request) const
{
    if (request.method() == http::verb::unknown)
    {
        logger_->LogError("Unknown method in the request");
        return false;
    }
    if (request.version() != 11 && request.version() != 10)
    {
        logger_->LogError("Unsupported HTTP version in the request");
        return false;
    }
    if (request.has_content_length())
    {
        auto contentLengthHeader = request[http::field::content_length];
        std::size_t expectedLength = std::stoul(contentLengthHeader.to_string());
        std::size_t actualLength = request.body().size();
        if (expectedLength != actualLength)
        {
            logger_->LogError("Content Length and actual body size not matched in the request");
            return false;
        }
    }
    return true;
}