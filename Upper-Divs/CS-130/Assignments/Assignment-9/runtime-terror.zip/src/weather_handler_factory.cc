#include "weather_handler_factory.h"

WeatherHandlerFactory::WeatherHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger) {}

std::shared_ptr<RequestHandler> WeatherHandlerFactory::Create(const std::string &url) const
{
    return std::make_shared<WeatherHandler>(url, location_, logger_);
}