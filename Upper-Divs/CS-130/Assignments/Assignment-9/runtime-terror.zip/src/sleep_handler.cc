#include "sleep_handler.h"

SleepHandler::SleepHandler(const std::string &url, const std::string &location, const std::string &time, std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger),
      time_(time) {}

http::status SleepHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    std::string request_str;
    logger_->LogInfo("Sleeping for " + time_ + " seconds");
    sleep(std::stoul(time_));
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/plain");
    response.body() = "Thread slept for " + time_ + " second" + (time_ == "1" ? "" : "s") + "\r\n";
    response.prepare_payload();
    return response.result();
}
