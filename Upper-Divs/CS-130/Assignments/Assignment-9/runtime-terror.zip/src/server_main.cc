#include <memory>
#include "initializer.h"
#include "real_logger.h"

int main(int argc, char *argv[])
{
    Initializer init;
    init.Initialize(argc, argv, std::make_shared<RealLogger>());
}
