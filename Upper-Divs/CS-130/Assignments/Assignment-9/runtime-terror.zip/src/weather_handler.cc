#include "weather_handler.h"

WeatherHandler::WeatherHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger) {}

http::status WeatherHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    // Extract request target, removing trailing slashes
    std::string target = request.target().to_string();
    while (target[target.size() - 1] == '/')
    {
        target.pop_back();
    }
    logger_->LogInfo("WeatherHandler: handling " + boost::lexical_cast<std::string>(request.method_string()) +
                     " request for " + target);

    // Make correct behavior for target
    if (target == "/weather")
    {
        return ServeInitialForm(request.method(), response);
    }
    else if (target.rfind("/weather/forecast?", 0) == 0)
    {
        return ServeWeatherForm(request.method(), target, response);
    }
    else
    {
        return HandleErrorResponse(http::status::not_found, "The requested URL does not exist", response);
    }
}

http::status WeatherHandler::ServeInitialForm(http::verb method, http::response<http::string_body> &response) const
{
    // Only GET requests should be allowed
    if (method != http::verb::get)
    {
        return HandleErrorResponse(http::status::method_not_allowed, "This URL only accepts GET requests", response);
    }

    // Retrieve HTML form from file
    fs::path path("../forms/weather_form.html");
    fs::ifstream file(path);
    std::string form((std::istreambuf_iterator<char>(file)),
                     std::istreambuf_iterator<char>());

    // Serve HTML form
    logger_->LogInfo("WeatherHandler: serving initial HTML form");
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/html");
    response.body() = form;
    response.prepare_payload();
    return http::status::ok;
}

http::status WeatherHandler::ServeWeatherForm(http::verb method, const std::string &target, http::response<http::string_body> &response) const
{
    // Only GET requests should be allowed
    if (method != http::verb::get)
    {
        return HandleErrorResponse(http::status::method_not_allowed, "This URL only accepts GET requests", response);
    }

    // Parse URL for params
    std::string location = ParseURL(target, "location");
    std::string start_date = ParseURL(target, "startdate");
    std::string end_date = ParseURL(target, "enddate");
    std::string units = ParseURL(target, "units");

    // Check params for validity
    if (location.empty() || units.empty() || start_date.empty() || end_date.empty())
    {
        return HandleErrorResponse(http::status::bad_request, "The request must specify a location, units, start date, and end date", response);
    }
    if (start_date > end_date)
    {
        return HandleErrorResponse(http::status::bad_request, "Please make sure that the start date is before the end date", response);
    }
    if (units != "fahrenheit" && units != "celsius")
    {
        return HandleErrorResponse(http::status::unprocessable_entity, "The request contains an invalid unit of temperature, please use \"fahrenheit\" or \"celsius\"", response);
    }

    // Check if location is valid
    std::string location_validity_target = "/v1/search?name=" + location + "&count=1&language=en&format=json";
    http::response<http::string_body> location_validity_res = MakeAPICall("geocoding-api.open-meteo.com", location_validity_target);
    std::string location_validity_str = boost::lexical_cast<std::string>(location_validity_res.body());

    if (location_validity_str.find("results") == std::string::npos)
    {
        return HandleErrorResponse(http::status::bad_request, "Please enter a valid location", response);
    }

    // Call to Meteo API with params
    std::string temp = GetWeatherData(location, units, start_date, end_date);
    units = (units == "fahrenheit") ? "F" : "C";

    // Retrieve HTML from file
    fs::path path("../forms/notes_form.html");
    fs::ifstream file(path);
    std::string form((std::istreambuf_iterator<char>(file)),
                     std::istreambuf_iterator<char>());

    // Replace HTML content with fetched data
    boost::replace_all(location, "%20", " ");
    boost::replace_all(form, "LOCATION", location);
    boost::replace_all(form, "TEMPERATURE", temp);
    boost::replace_all(form, "UNITS", units);

    // Serve HTML
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/html");
    response.body() = form;
    response.prepare_payload();
    return http::status::ok;
}

std::string WeatherHandler::ParseURL(const std::string &url, std::string param) const
{
    size_t begin = url.find(param + "=");
    if (begin != std::string::npos)
    {
        size_t end = url.find("&", begin);
        if (end == std::string::npos)
        {
            end = url.size();
        }
        begin += param.size() + 1;
        return url.substr(begin, end - begin);
    }
    else
    {
        return "";
    }
}

std::string WeatherHandler::GetWeatherData(const std::string &location, const std::string &units, const std::string &start_date, const std::string &end_date) const
{

    // Get latitude and longitude
    std::string target = "/v1/search?name=" + location + "&count=1&language=en&format=json";
    http::response<http::string_body> coordinate_res = MakeAPICall("geocoding-api.open-meteo.com", target);

    std::pair<std::string, std::string> coords = ParseCoordinates(coordinate_res);
    std::string latitude = coords.first;
    std::string longitude = coords.second;
    logger_->LogInfo("WeatherHandler: received geocoded coordinates [" + latitude + ", " + longitude + "]");

    // Get weather data
    target = "/v1/forecast?latitude=" + latitude + "&longitude=" + longitude + "&hourly=temperature_2m&temperature_unit=" + units + "&start_date=" + start_date + "&end_date=" + end_date;

    http::response<http::string_body> weather_res = MakeAPICall("api.open-meteo.com", target);
    std::vector<float> weather_data = ParseWeatherData(weather_res);
    logger_->LogInfo("WeatherHandler: received requested weather data");

    // TODO: Temporary output for Weather API Calls
    int mean_weather = std::accumulate(weather_data.begin(), weather_data.end(), 0.0) / weather_data.size();
    return std::to_string(mean_weather);
}

http::response<http::string_body> WeatherHandler::MakeAPICall(std::string host, const std::string &target) const
{
    logger_->LogInfo("WeatherHandler: making API call to: " + host + target);

    try
    {
        // The io_context is required for all I/O
        net::io_context ioc;
        net::ip::tcp::resolver resolver(ioc);
        beast::tcp_stream stream(ioc);

        // Look up the domain name
        auto const results = resolver.resolve(host, "80");
        stream.connect(results);

        // Set up an HTTP GET request message
        http::request<http::string_body> req{http::verb::get, target, 11};
        req.set(http::field::host, host);
        req.set(http::field::user_agent, BOOST_BEAST_VERSION_STRING);

        // Send the HTTP request to the remote host
        http::write(stream, req);
        beast::flat_buffer buffer;
        http::response<http::string_body> res;

        // Receive the HTTP response
        http::read(stream, buffer, res);

        // Gracefully close the connection
        beast::error_code ec;
        stream.socket().shutdown(net::ip::tcp::socket::shutdown_both, ec);
        if (ec && ec != net::error::not_connected)
        {
            std::string error_message = "Error during API Call: " + ec.message();
            logger_->LogInfo(error_message);
            throw beast::system_error{ec};
        }
        return res;
    }
    catch (std::exception const &e)
    {
        std::string error_message = "Error during API call: " + std::string(e.what());
        logger_->LogError(error_message);
        throw; // rethrow it, possibly to be handled at a higher level
    }
}

std::pair<std::string, std::string> WeatherHandler::ParseCoordinates(const http::response<http::string_body> &coords_res) const
{
    std::string coords_str = boost::lexical_cast<std::string>(coords_res.body());
    json coords_json = json::parse(coords_str);
    float latitude = coords_json["results"][0]["latitude"];
    float longitude = coords_json["results"][0]["longitude"];
    return std::make_pair(std::to_string(latitude), std::to_string(longitude));
}

std::vector<float> WeatherHandler::ParseWeatherData(const http::response<http::string_body> &weather_res) const
{
    std::string weather_str = boost::lexical_cast<std::string>(weather_res.body());
    json weather_json = json::parse(weather_str);
    std::vector<float> hourly_temp = weather_json["hourly"]["temperature_2m"];
    std::vector<float> daily_temp;

    // TODO: Temporary output for weather format, only keeps hour 0 of each day requested
    for (int i = 0; i < hourly_temp.size(); i += 24)
        daily_temp.push_back(hourly_temp[i]);
    return daily_temp;
}

http::status WeatherHandler::HandleErrorResponse(http::status status, std::string error_msg, http::response<http::string_body> &response) const
{
    logger_->LogInfo("WeatherHandler: request could not be handled, sending error response");
    response.result(status);
    response.set(http::field::content_type, "text/plain");
    response.body() = error_msg + "\r\n";
    response.prepare_payload();
    return status;
}
