#include "nginx_config.h"

std::string NginxConfigStatement::ToString(int depth)
{
    std::string serialized_statement;
    for (int i = 0; i < depth; ++i)
    {
        serialized_statement.append("  ");
    }
    for (unsigned int i = 0; i < tokens_.size(); ++i)
    {
        if (i != 0)
        {
            serialized_statement.append(" ");
        }
        serialized_statement.append(tokens_[i]);
    }
    if (child_block_.get() != nullptr)
    {
        serialized_statement.append(" {\n");
        serialized_statement.append(child_block_->ToString(depth + 1));
        for (int i = 0; i < depth; ++i)
        {
            serialized_statement.append("  ");
        }
        serialized_statement.append("}");
    }
    else
    {
        serialized_statement.append(";");
    }
    serialized_statement.append("\n");
    return serialized_statement;
}

std::string NginxConfig::ToString(int depth)
{
    std::string serialized_config;
    for (const auto &statement : statements_)
    {
        serialized_config.append(statement->ToString(depth));
    }
    return serialized_config;
}

unsigned short NginxConfig::GetServerKeyword(std::string keyword) const
{
    std::queue<std::shared_ptr<NginxConfigStatement>> statement_queue;
    for (auto &statement : statements_)
    {
        statement_queue.push(statement);
    }
    while (!statement_queue.empty())
    {
        std::shared_ptr<NginxConfigStatement> statement = statement_queue.front();
        statement_queue.pop();
        if (statement->child_block_)
        {
            for (auto &statement : statement->child_block_->statements_)
            {
                statement_queue.push(statement);
            }
        }
        std::string value_str = "";
        if (statement->tokens_.size() == 2 && statement->tokens_[0] == keyword)
        {
            value_str = statement->tokens_[1];
        }
        else
        {
            continue;
        }
        try
        {
            int value = std::stoi(value_str);
            if (value > 0 && value <= USHRT_MAX)
            {
                return value;
            }
        }
        catch (std::exception &e)
        {
            std::cerr << "Exception: " << e.what() << "\n";
        }
    }
    return 0;
}

std::string NginxConfig::GetKeyword(std::string keyword) const
{
    for (auto &statement : statements_)
    {
        if (statement->tokens_.size() == 2 && statement->tokens_[0] == keyword)
        {
            std::string value = statement->tokens_[1];
            while (!value.empty() && value[value.size() - 1] == '/')
            {
                value.pop_back();
            }
            return value;
        }
    }
    return "";
}
