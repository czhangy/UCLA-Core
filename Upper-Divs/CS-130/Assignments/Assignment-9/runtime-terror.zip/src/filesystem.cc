#include "filesystem.h"

std::string Filesystem::GetEntityName(const std::string &entity_path) const
{
    if (entity_path.empty())
    {
        return "";
    }
    // Strip off leading "/"
    std::string entity_str = entity_path.substr(1);
    std::size_t len = entity_str.find("/");
    if (len == std::string::npos)
    {
        return entity_str;
    }
    else
    {
        return entity_str.substr(0, len);
    }
}

int Filesystem::GetEntityID(const std::string &entity_path, const std::string &entity_name) const
{
    // Check if an ID exists
    if (entity_path.size() < entity_name.size() + 2)
    {
        // Return 0 for no ID
        return 0;
    }
    // +2 to account for leading "/" and "/" separating entity name and ID
    std::string id_str = entity_path.substr(entity_name.size() + 2);
    try
    {
        return boost::lexical_cast<int>(id_str);
    }
    catch (boost::bad_lexical_cast)
    {
        // Return -1 for bad ID
        return -1;
    }
}
