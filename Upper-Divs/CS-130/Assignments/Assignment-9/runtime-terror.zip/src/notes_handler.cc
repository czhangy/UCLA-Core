#include "notes_handler.h"
#include <iostream>

NotesHandler::NotesHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger, std::shared_ptr<Filesystem> fs)
    : RequestHandler(url, location, logger),
      fs_(fs) {}

http::status NotesHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    // Extract request target, removing trailing slashes
    std::string target = request.target().to_string();
    while (target[target.size() - 1] == '/')
    {
        target.pop_back();
    }
    logger_->LogInfo("NotesHandler: handling " + boost::lexical_cast<std::string>(request.method_string()) +
                     " request for " + target);

    // Make correct behavior for method
    if (request.method() == http::verb::get)
    {
        if(ParseURL(target, "id") == "") 
            return ServeNotesList(target, response);
        else
            return ServeNote(target, response);
    }
    else if (request.method() == http::verb::post)
    {
        return CreateNote(target, request.body(), response);
    }
    else if (request.method() == http::verb::delete_)
    {
        return DeleteNote(target, response);
    }
    else
    {
        return HandleErrorResponse(http::status::not_implemented, "That HTTP method is not supported", response);
    }
}

http::status NotesHandler::ServeNotesList(const std::string &target, http::response<http::string_body> &response) const
{
    // Check that params are correct
    std::string username = ParseURL(target, "username");
    if (username.empty())
    {
        logger_->LogInfo("NotesHandler: request is missing params, can't process");
        return HandleErrorResponse(http::status::bad_request, "That URL does not handle GET requests", response);
    }

    // Get a list of notes under the specified username
    std::vector<std::string> notes;
    http::status s = ListNotes(target, notes);

    // Error out if needed
    if (s == http::status::not_found)
    {
        logger_->LogInfo("NotesHandler: request target doesn't exist, can't list notes");
        return HandleErrorResponse(http::status::not_found, "That user doesn't exist", response);
    }

    // Retrieve HTML from file
    fs::path path("../forms/notes_list.html");
    fs::ifstream file(path);
    std::string markup((std::istreambuf_iterator<char>(file)),
                       std::istreambuf_iterator<char>());

    // Inject data into JS
    std::string script = "<script defer>";
    size_t begin = markup.find(script) + script.size();
    std::string js = "let list=[";
    for (const std::string &note : notes)
    {
        js += "\'" + note + "\',";
    }
    if (js[js.size() - 1] == ',')
    {
        js.pop_back();
    }
    js += "];";
    markup.insert(begin, js);

    // Replace HTML text with username
    boost::replace_all(markup, "USERNAME", username);

    // Serve HTML form
    logger_->LogInfo("NotesHandler: handled LIST request, serving notes list");
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/html");
    response.body() = markup;
    response.prepare_payload();
    return http::status::ok;
}

http::status NotesHandler::ServeNote(const std::string &target, http::response<http::string_body> &response) const
{
     // Extract username and ID
    std::string username = ParseURL(target, "username");
    std::string id = ParseURL(target, "id");

    // Check if params both exist
    if (username.empty() || id.empty())
    {
        logger_->LogInfo("NotesHandler: GET request is missing required params");
        return HandleErrorResponse(http::status::bad_request, "The URL is missing required params", response);
    }

    // Check if note exists
    std::string note_path = "/" + username + "/" + id;
    if (!fs_->Exists(note_path))
    {
        logger_->LogInfo("NotesHandler: request target doesn't exist, can't display file");
        return HandleErrorResponse(http::status::not_found, "That note doesn't exist", response);
    }

    // Retrieve note contents
    fs::path path("../notes" + note_path);
    fs::ifstream file(path);
    std::string note_contents((std::istreambuf_iterator<char>(file)),
                       std::istreambuf_iterator<char>());
    json json_content = json::parse(note_contents);
    std::string title = json_content["title"];
    std::string note = json_content["note"];

    // Retrieve HTML from file
    fs::path html_path("../forms/view_note_form.html");
    fs::ifstream html_file(html_path);
    std::string markup((std::istreambuf_iterator<char>(html_file)),
                       std::istreambuf_iterator<char>());

    // Replace HTML text with note title
    boost::replace_all(markup, "TITLE", title);
    boost::replace_all(markup, "NOTE", note);

    // Serve HTML form
    logger_->LogInfo("NotesHandler: handled GET request, serving note");
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/html");
    response.body() = markup;
    response.prepare_payload();
    return http::status::ok;
}

http::status NotesHandler::CreateNote(const std::string &target, const std::string &body, http::response<http::string_body> &response) const
{
    // Check that the target is valid
    if (target != "/notes")
    {
        logger_->LogInfo("NotesHandler: POST request received for invalid target");
        return HandleErrorResponse(http::status::not_found, "That URL doesn't exist or doesn't accept POST requests", response);
    }

    // Check for valid JSON body
    if (!json::accept(body))
    {
        logger_->LogInfo("NotesHandler: request did not send valid JSON");
        return HandleErrorResponse(http::status::bad_request, "This POST request must contain a valid JSON object", response);
    }
    json json_content = json::parse(body);
    if (json_content["username"].empty() || json_content["title"].empty() || json_content["username"].get<std::string>().empty() || json_content["title"].get<std::string>().empty())
    {
        logger_->LogInfo("NotesHandler: request did not send a username and title");
        return HandleErrorResponse(http::status::bad_request, "Notes must contain a username and title", response);
    }

    // Make user if they don't exist
    std::string username_path = "/" + json_content["username"].get<std::string>();
    if (!fs_->Exists(username_path))
    {
        logger_->LogInfo("NotesHandler: " + json_content["username"].get<std::string>() + " does not exist, creating directory");
        if (!fs_->CreateDirectory(username_path))
        {
            logger_->LogError("NotesHandler: failed to create directory for " + username_path);
            return HandleErrorResponse(http::status::internal_server_error, "Something went wrong when creating a user, please try again later", response);
        }
    }

    // Get hashed filename
    std::string hash = std::to_string(std::hash<std::string>{}(json_content["title"].get<std::string>() + json_content["note"].get<std::string>()));
    std::string note_path = username_path + "/" + hash;
    if (fs_->Exists(note_path))
    {
        logger_->LogError("NotesHandler: duplicate hash found, stopping file creation");
        return HandleErrorResponse(http::status::conflict, "A note with the same title and body already exists", response);
    }

    // Construct JSON
    json note_obj;
    note_obj["id"] = hash;
    note_obj["title"] = json_content["title"].get<std::string>();
    note_obj["note"] = json_content["note"].get<std::string>();
    if (!fs_->CreateFile(note_path, note_obj.dump(kTabSize)))
    {
        logger_->LogError("NotesHandler: failed to create file for " + note_path);
        return HandleErrorResponse(http::status::internal_server_error, "Something went wrong when creating a note, please try again later", response);
    }

    // Prepare HTTP response
    logger_->LogInfo("NotesHandler: handled POST request, sending response");
    response.result(http::status::created);
    response.prepare_payload();
    return http::status::created;
}

http::status NotesHandler::DeleteNote(const std::string &target, http::response<http::string_body> &response) const
{
    // Extract username and ID
    std::string username = ParseURL(target, "username");
    std::string id = ParseURL(target, "id");

    // Check if params both exist
    if (username.empty() || id.empty())
    {
        logger_->LogInfo("NotesHandler: DELETE request is missing required params");
        return HandleErrorResponse(http::status::bad_request, "The URL is missing required params", response);
    }

    // Check if note exists
    std::string note_path = "/" + username + "/" + id;
    if (!fs_->Exists(note_path))
    {
        logger_->LogInfo("NotesHandler: request target doesn't exist, can't delete file");
        return HandleErrorResponse(http::status::not_found, "That note doesn't exist", response);
    }

    // Delete file
    if (!fs_->DeleteFile(note_path))
    {
        logger_->LogError("NotesHandler: failed to delete file for " + note_path);
        return HandleErrorResponse(http::status::internal_server_error, "Failed to delete note, try again later", response);
    }

    // Prepare HTTP response
    logger_->LogInfo("NotesHandler: handled DELETE request, sending response");
    response.result(http::status::ok);
    response.prepare_payload();
    return http::status::ok;
}

http::status NotesHandler::ListNotes(const std::string &target, std::vector<std::string> &notes) const
{
    // Check if user exists
    std::string username_path = "/" + ParseURL(target, "username");
    if (!fs_->Exists(username_path))
    {
        return http::status::not_found;
    }

    // Get list of files and their contents
    std::vector<size_t> ids = fs_->GetAllEntityIDs(username_path);
    for (size_t id : ids)
    {
        std::string note_path = username_path + "/" + std::to_string(id);
        std::string note = fs_->GetData(note_path);
        if (!json::accept(note))
        {
            logger_->LogWarning("NotesHandler: file with invalid JSON found, ignoring");
        }
        else
        {
            note.erase(std::remove(note.begin(), note.end(), '\n'), note.end());
            notes.push_back(note);
        }
    }

    // Send OK when done
    return http::status::ok;
}

std::string NotesHandler::ParseURL(const std::string &url, std::string param) const
{
    size_t begin = url.find(param + "=");
    if (begin != std::string::npos)
    {
        size_t end = url.find("&", begin);
        if (end == std::string::npos)
        {
            end = url.size();
        }
        begin += param.size() + 1;
        return url.substr(begin, end - begin);
    }
    else
    {
        return "";
    }
}

http::status NotesHandler::HandleErrorResponse(http::status status, std::string error_msg, http::response<http::string_body> &response) const
{
    logger_->LogInfo("NotesHandler: request could not be handled, sending error response");
    response.result(status);
    response.set(http::field::content_type, "text/plain");
    response.body() = error_msg + "\r\n";
    response.prepare_payload();
    return status;
}
