#include "health_handler.h"

HealthHandler::HealthHandler(const std::string &url, const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger) {}

http::status HealthHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    logger_->LogInfo("Generated 200 response for health check");
    response.result(http::status::ok);
    response.set(http::field::content_type, "text/plain");
    response.body() = "OK\r\n";
    response.prepare_payload();
    return response.result();
}