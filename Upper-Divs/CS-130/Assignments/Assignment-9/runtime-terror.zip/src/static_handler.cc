#include "static_handler.h"

StaticHandler::StaticHandler(const std::string &url, const std::string &location, const std::string &root, std::shared_ptr<Logger> logger)
    : RequestHandler(url, location, logger),
      root_(root) {}

http::status StaticHandler::HandleRequest(const http::request<http::string_body> &request, http::response<http::string_body> &response) const
{
    // Get the full path of the file
    std::string rel_path = GetPath(request);
    std::string full_path = ".." + root_ + rel_path;

    // Check if file exists and is not a directory
    fs::path boost_path(full_path);
    if (!fs::exists(boost_path) || !fs::is_regular_file(full_path))
    {
        logger_->LogError("File doesn't exist at URI: " + request.target().to_string());
        return NotFoundRequest("The file doesn't exist\r\n", response);
    }

    // Read file contents into string
    fs::ifstream file(boost_path);
    std::string file_contents((std::istreambuf_iterator<char>(file)),
                              std::istreambuf_iterator<char>());

    // Form response
    logger_->LogInfo("Generated static response for file at " + request.target().to_string());
    response.result(http::status::ok);
    response.set(http::field::content_type, GetMIMEType(rel_path));
    response.body() = file_contents + "\r\n";
    response.prepare_payload();
    return response.result();
}

http::status StaticHandler::NotFoundRequest(std::string error, http::response<http::string_body> &response) const
{
    response.result(http::status::not_found);
    response.set(http::field::content_type, "text/plain");
    response.body() = error;
    response.prepare_payload();
    return response.result();
}

std::string StaticHandler::GetPath(const http::request<http::string_body> &request) const
{
    std::string full_url = request.target().to_string();
    return full_url.substr(location_.size());
}

std::string StaticHandler::GetMIMEType(const std::string &path) const
{
    // Extract the file extension
    int extension_start = path.find(".");
    std::string extension = path.substr(extension_start + 1);

    // Find the correct MIME type
    if (extension == "html")
    {
        return "text/html";
    }
    else if (extension == "jpg" || extension == "jpeg")
    {
        return "image/jpeg";
    }
    else if (extension == "txt")
    {
        return "text/plain";
    }
    else if (extension == "zip")
    {
        return "application/zip";
    }
    else if (extension == "gif")
    {
        return "image/gif";
    }
    else
    {
        return "application/octet-stream";
    }
}