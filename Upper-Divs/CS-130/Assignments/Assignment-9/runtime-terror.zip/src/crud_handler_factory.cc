#include "crud_handler_factory.h"

CRUDHandlerFactory::CRUDHandlerFactory(const std::string &location, const NginxConfig &config, std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger)
{
    data_path_ = config.GetKeyword("data_path");
    filesystem_ = config.GetKeyword("filesystem");
    map_guard_ = std::make_shared<std::mutex>();
    mtx_map_ = std::make_shared<mutex_map>();
}

std::shared_ptr<RequestHandler> CRUDHandlerFactory::Create(const std::string &url) const
{
    std::shared_ptr<Filesystem> fs;
    if (filesystem_ == kBoost)
    {
        fs = std::make_shared<BoostFilesystem>(data_path_, logger_);
    }
    else
    {
        if (filesystem_ != kMock)
        {
            logger_->LogWarning("CRUDHandlerFactory: no valid filesystem specified, defaulting to MockFilesystem");
        }
        std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
        fs = std::make_shared<MockFilesystem>(fs_map);
    }
    if (fs->CreateDataPathDir())
    {
        logger_->LogInfo("CRUDHandlerFactory: creating new CRUD handler with data path " + data_path_ + " serving " + location_);
        return std::make_shared<CRUDHandler>(url, location_, logger_, fs, map_guard_, mtx_map_);
    }
    else
    {
        logger_->LogFatal("CRUDHandlerFactory: failed to create data path directory " + data_path_ + ", exiting");
        return NULL;
    }
}