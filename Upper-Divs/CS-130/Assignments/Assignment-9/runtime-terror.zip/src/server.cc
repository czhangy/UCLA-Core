#include "server.h"

server::server(boost::asio::io_service &io_service, unsigned short port, std::size_t thread_pool_size, std::shared_ptr<Dispatcher> dispatcher, std::shared_ptr<Logger> logger)
    : io_service_(io_service),
      acceptor_(io_service, tcp::endpoint(tcp::v4(), port)),
      thread_pool_size_(thread_pool_size),
      dispatcher_(dispatcher),
      logger_(logger)
{
    start_accept();
    logger_->LogInfo("Server started");
}

bool server::run()
{
    // Create a pool of threads to run all of the io_services.
    std::vector<boost::shared_ptr<boost::thread>> threads;
    for (std::size_t i = 0; i < thread_pool_size_; i++)
    {
        boost::shared_ptr<boost::thread> thread(new boost::thread(
            boost::bind(&boost::asio::io_service::run, &io_service_)));
        threads.push_back(thread);
    }

    // Wait for all threads in the pool to exit.
    for (std::size_t i = 0; i < threads.size(); i++)
    {
        threads[i]->join();
    }
    return true;
}

void server::start_accept()
{
    std::shared_ptr<session> new_session = std::make_shared<session>(io_service_, dispatcher_, logger_);
    acceptor_.async_accept(new_session->socket(),
                           boost::bind(&server::handle_accept, this, new_session,
                                       boost::asio::placeholders::error));
    started = true;
}

void server::handle_accept(std::shared_ptr<session> new_session,
                           const boost::system::error_code &error)
{
    if (!error)
    {
        new_session->start();
        handled = true;
        logger_->LogInfo("New server session accepted");
    }
    else
    {
        logger_->LogWarning("New server session was not properly handled");
    }

    start_accept();
}
