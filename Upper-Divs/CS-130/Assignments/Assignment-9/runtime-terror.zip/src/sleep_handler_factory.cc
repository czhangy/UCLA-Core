#include "sleep_handler_factory.h"

SleepHandlerFactory::SleepHandlerFactory(const std::string &location,
                                         const NginxConfig &config,
                                         std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger)
{
    time_ = config.GetKeyword("time");
}

std::shared_ptr<RequestHandler> SleepHandlerFactory::Create(
    const std::string &url) const
{
    if (IsValidSleepTime())
    {
        logger_->LogInfo("Creating new sleep handler with time " + time_ + " serving " + location_);
        return std::shared_ptr<RequestHandler>(
            new SleepHandler(url, location_, time_, logger_));
    }
    else
    {
        logger_->LogError("The sleep handler serving " + location_ +
                          " is missing a valid time between 0 and 10");
        return NULL;
    }
}

bool SleepHandlerFactory::IsValidSleepTime() const
{
    if (time_.empty() || time_.size() > 2)
    {
        return false;
    }
    for (char c : time_)
    {
        if (!isdigit(c))
        {
            return false;
        }
    }
    return stoi(time_) <= 10;
}
