#include "mock_logger.h"

void MockLogger::LogTrace(std::string message)
{
    std::cout << "[Trace] " + message << std::endl;
}

void MockLogger::LogDebug(std::string message)
{
    std::cout << "[Debug] " + message << std::endl;
}

void MockLogger::LogInfo(std::string message)
{
    std::cout << "[Info] " + message << std::endl;
}

void MockLogger::LogWarning(std::string message)
{
    std::cout << "[Warning] " + message << std::endl;
}

void MockLogger::LogError(std::string message)
{
    std::cout << "[Error] " + message << std::endl;
}

void MockLogger::LogFatal(std::string message)
{
    std::cout << "[Fatal] " + message << std::endl;
}