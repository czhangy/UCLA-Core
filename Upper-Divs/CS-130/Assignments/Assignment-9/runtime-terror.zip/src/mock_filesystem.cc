#include "mock_filesystem.h"

MockFilesystem::MockFilesystem(const std::unordered_map<std::string, std::vector<MockFile>> &fs) : fs_(fs) {}

bool MockFilesystem::CreateDataPathDir()
{
    return true;
}

bool MockFilesystem::Exists(const std::string &entity_path)
{
    std::string entity_name = GetEntityName(entity_path);
    int id = GetEntityID(entity_path, entity_name);
    if (fs_.find(entity_name) == fs_.end() || id == -1)
    {
        return false;
    }
    if (id == 0)
    {
        return true;
    }
    for (const MockFile &f : fs_[entity_name])
    {
        if (f.id == id)
        {
            return true;
        }
    }
    return false;
}

bool MockFilesystem::CreateDirectory(const std::string &entity_path)
{
    std::string entity_name = GetEntityName(entity_path);
    fs_[entity_name] = {};
    return true;
}

std::vector<size_t> MockFilesystem::GetAllEntityIDs(const std::string &entity_path)
{
    std::vector<size_t> ids;
    std::string entity_name = GetEntityName(entity_path);
    for (MockFile f : fs_[entity_name])
    {
        ids.push_back(f.id);
    }
    return ids;
}

bool MockFilesystem::CreateFile(const std::string &entity_path, const std::string &content)
{
    std::string entity_name = GetEntityName(entity_path);
    int id = GetEntityID(entity_path, entity_name);
    fs_[entity_name].push_back({id, content});
    sort(fs_[entity_name].begin(), fs_[entity_name].end(), [](const MockFile &f1, const MockFile &f2)
         { return f1.id < f2.id; });
    return true;
}

std::string MockFilesystem::GetData(const std::string &entity_path)
{
    std::string entity_name = GetEntityName(entity_path);
    int id = GetEntityID(entity_path, entity_name);
    for (MockFile f : fs_[entity_name])
    {
        if (f.id == id)
        {
            return f.content;
        }
    }
    return "";
}

bool MockFilesystem::DeleteFile(const std::string &entity_path)
{
    std::string entity_name = GetEntityName(entity_path);
    int id = GetEntityID(entity_path, entity_name);
    for (int i = 0; i < fs_[entity_name].size(); i++)
    {
        if (fs_[entity_name][i].id == id)
        {
            fs_[entity_name].erase(fs_[entity_name].begin() + i);
            return true;
        }
    }
    return false;
}
