#include "health_handler_factory.h"

HealthHandlerFactory::HealthHandlerFactory(const std::string &location, std::shared_ptr<Logger> logger)
    : RequestHandlerFactory(location, logger) {}

std::shared_ptr<RequestHandler> HealthHandlerFactory::Create(const std::string &url) const
{
    return std::shared_ptr<HealthHandler>(new HealthHandler(url, location_, logger_));
}