//
// async_tcp_echo_server.cpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2017 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/log/trivial.hpp>
#include <cstdlib>
#include <iostream>

#include "config_parser.h"
#include "logger.h"
#include "server.h"
#include "web_server_runner.h"

using boost::asio::ip::tcp;

int main(int argc, char* argv[]) {
  web_server_runner runner(argc, argv);
  return runner.run();
}
