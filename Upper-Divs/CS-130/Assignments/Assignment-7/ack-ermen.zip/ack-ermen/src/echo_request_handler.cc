#include "echo_request_handler.h"

#include <boost/filesystem.hpp>
#include <string>

#include "logger.h"

http::status EchoRequestHandler::handle_request(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res) {
  res.body() = response_to_str(req);
  res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
  res.set(http::field::content_type, "text/plain");
  res.keep_alive(res.keep_alive());
  res.prepare_payload();

  return http::status::ok;
}

std::string EchoRequestHandler::response_to_str(
    const http::request<http::string_body>& req) {
  std::stringstream ss;
  ss << req.method_string() << " " << req.target() << " "
     << get_http_version_str(req.version()) << "\r\n";
  for (auto const& field : req.base())
    ss << field.name_string() << ": " << field.value() << "\r\n";
  ss << "\r\n" << req.body();
  return ss.str();
}

std::string EchoRequestHandler::get_http_version_str(unsigned int version) {
  int major_version = version / 10;
  int minor_version = version % 10;

  return std::string("HTTP/") + std::to_string(major_version) +
         std::string(".") + std::to_string(minor_version);
}
