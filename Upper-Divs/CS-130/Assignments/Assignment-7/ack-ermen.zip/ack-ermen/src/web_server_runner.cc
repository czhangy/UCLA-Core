#include "web_server_runner.h"

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <cstdlib>
#include <iostream>

#include "config_parser.h"
#include "logger.h"
#include "server.h"

using boost::asio::ip::tcp;

void sigint_handler(int s) {
  logger->info("Caught SIGINT (or Control-C), stopping server");
  exit(0);
}

int web_server_runner::run() {
  if (argc_ != 2) {
    logger->error("Usage: ./server <config-path>");
    return 1;
  }

  // From https://stackoverflow.com/questions/4217037/catch-ctrl-c-in-c answer 3

  struct sigaction act;
  act.sa_handler = sigint_handler;
  sigaction(SIGINT, &act, NULL);

  // End of snippet from stackoverflow

  NginxConfigParser parser;
  NginxConfig config;

  if (!parser.Parse(argv_[1], &config)) {
    logger->error("Fatal error occurred during parsing of config file");
    return 1;
  }
  short port = config.GetPort();

  if (port == -1) {
    logger->error("Missing or invalid port number");
    return 1;
  }

  boost::asio::io_service io_service;
  server s(io_service, port, config);

  logger->info("Server listening on port " + std::to_string(port));

  io_service.run();
}

void web_server_runner::shutdown() { exit(0); }
