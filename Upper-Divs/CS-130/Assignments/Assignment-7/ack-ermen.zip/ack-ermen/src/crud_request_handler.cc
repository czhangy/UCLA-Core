#include "crud_request_handler.h"

CRUDRequestHandler::CRUDRequestHandler(const std::string& crud_endpoint,
                                       const std::string& data_path,
                                       std::unique_ptr<Filesystem> fs)
    : crud_endpoint_(crud_endpoint), data_path_(data_path), fs_(std::move(fs)) {
  fs_->create_data_path(data_path);
}

http::status CRUDRequestHandler::handle_request(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res) {
  http::status status;
  beast::string_view req_method = req.method_string();
  bfs::path path(get_full_path_to_file(req.target().to_string()));

  // Ensure method is valid first
  if (req_method != "POST" && req_method != "GET" && req_method != "PUT" &&
      req_method != "DELETE") {
    status = http::status::not_implemented;
    res.set(http::field::content_type, "text/plain");
    res.body() = "501 Not Implemented\r\n";
    logger->error(std::string(req_method) +
                  " is an invalid request method\r\n");
  } else if (!fs_->exists(path) && req_method != "POST") {
    status = http::status::not_found;
    logger->error(path.string() + " does not exist\r\n");
  } else if (req_method == "POST") {
    status = create(req, res, path);
  } else if (req_method == "GET") {
    status = fs_->is_directory(path) ? list(req, res, path)
                                     : retrieve(req, res, path);
  } else if (req_method == "PUT") {
    status = update(req, res, path);
  } else if (req_method == "DELETE") {
    status = del(req, res, path);
  }

  res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
  res.keep_alive(req.keep_alive());
  res.result(status);
  res.prepare_payload();

  return status;
}

http::status CRUDRequestHandler::create(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res, const bfs::path& path) {
  bfs::path dir_path = bfs::path(path.string() + "/");
  if (!fs_->exists(path)) {
    fs_->create_directory(path);
    logger->info("Creating directory: " + path.string());
  }

  std::vector<std::string> ids = fs_->get_entities_in_dir(path);
  int next_id = 1;
  for (int i = 0; i < ids.size(); i++) {
    if (std::stoi(ids[i]) != i + 1) {
      break;
    }
    next_id++;
  }

  std::string full_path = path.string() + "/" + std::to_string(next_id);
  fs_->write_to_file(full_path, req.body());
  res.set(http::field::content_type, "application/json");
  res.body() = "{\"id\": " + std::to_string(next_id) + "}";
  return http::status::created;
}

http::status CRUDRequestHandler::retrieve(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res, const bfs::path& path) {
  std::string file_contents = fs_->get_file_contents(path);
  res.set(http::field::content_type, "application/json");
  res.body() = file_contents + "\r\n";
  return http::status::ok;
}

http::status CRUDRequestHandler::update(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res, const bfs::path& path) {
  fs_->write_to_file(path, req.body());
  res.set(http::field::content_type, "text/plain");
  res.body() = "Update successful!\r\n";
  return http::status::ok;
}

http::status CRUDRequestHandler::del(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res, const bfs::path& path) {
  try {
    if (fs_->exists(path)) {
      std::string path_string = path.string();
      fs_->remove(path);
      logger->info("File " + path_string + " successfully deleted");
    }
  } catch (const bfs::filesystem_error& ex) {
    logger->error(std::string("Error Deleting File: ") + ex.what());
  }
  res.set(http::field::content_type, "text/plain");
  res.body() = "Delete successful!\r\n";
  return http::status::ok;
}

http::status CRUDRequestHandler::list(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res, const bfs::path& dir_path) {
  std::vector<std::string> entities = fs_->get_entities_in_dir(dir_path);
  nlohmann::json json;
  json["valid_ids"] = entities;
  std::string json_str = json.dump();
  res.set(http::field::content_type, "application/json");
  res.body() = json_str + "\r\n";
  return http::status::ok;
}

std::string CRUDRequestHandler::get_full_path_to_file(
    std::string request_path) const {
  bool absolute = request_path[0] == '/';
  const std::string requested_path = absolute ? data_path_ : "./" + data_path_;
  return requested_path + request_path.substr(crud_endpoint_.length());
}
