#include "not_found_request_handler.h"

#include <boost/filesystem.hpp>
#include <string>

#include "logger.h"

http::status NotFoundRequestHandler::handle_request(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res) {
  std::string not_found = "404 Not Found\r\n";
  res.body() = not_found;
  res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
  res.set(http::field::content_type, "text/plain");
  res.keep_alive(req.keep_alive());
  res.result(http::status::not_found);
  res.prepare_payload();

  return http::status::not_found;
}
