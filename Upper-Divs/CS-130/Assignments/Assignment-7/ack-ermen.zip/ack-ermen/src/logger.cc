#include "logger.h"

#include <boost/asio.hpp>
#include <boost/beast.hpp>

/*
 *          Copyright Andrey Semashev 2007 - 2015.
 * Distributed under the Boost Software License, Version 1.0.
 *    (See accompanying file LICENSE_1_0.txt or copy at
 *          http://www.boost.org/LICENSE_1_0.txt)
 * Edited by acker-men team for CS 130 assigments at UCLA for education
 */

#include <boost/log/core.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <boost/log/utility/setup/file.hpp>

namespace logging = boost::log;
namespace src = boost::log::sources;
namespace sinks = boost::log::sinks;
namespace keywords = boost::log::keywords;

namespace beast = boost::beast;
namespace http = beast::http;
using boost::asio::ip::tcp;

Logger::Logger() {
  init();
  logging::add_common_attributes();
  logging::record rec = lg.open_record();
  logging::add_console_log(
      std::cout,
      keywords::format = "[%TimeStamp%] [%ThreadID%] [%Severity%]: %Message%");
}

void Logger::init() {
  logging::add_file_log(
      keywords::file_name = "../log/RUNLOG_%N.log",  // file name pattern
      keywords::rotation_size =
          10 * 1024 * 1024,  // rotate files every 10 MiB...
      keywords::time_based_rotation =
          sinks::file::rotation_at_time_point(0, 0, 0),  // ...or at midnight
      keywords::format =
          "[%TimeStamp%] [%ThreadID%] [%Severity%]: %Message%",  // log record
                                                                 // format
      keywords::auto_flush = true  // After each log record, buffer is flushed
  );

  logging::core::get()->set_filter(logging::trivial::severity >=
                                   logging::trivial::info);
}

// End of Boost Log tutorial code

// Initialize the logger as nullptr, logger can be initialized later when
// getLogger() is called
Logger* Logger::logger_ptr = nullptr;
Logger* logger = Logger::getLogger();

// Below are the functions that log messages for diferrent log levels
void Logger::trace(std::string trace_message) {
  BOOST_LOG_SEV(lg, logging::trivial::trace) << trace_message;
}

void Logger::debug(std::string debug_message) {
  BOOST_LOG_SEV(lg, logging::trivial::debug) << debug_message;
}

void Logger::info(std::string info_message) {
  BOOST_LOG_SEV(lg, logging::trivial::info) << info_message;
}

void Logger::warning(std::string warning_message) {
  BOOST_LOG_SEV(lg, logging::trivial::warning) << warning_message;
}

void Logger::error(std::string error_message) {
  BOOST_LOG_SEV(lg, logging::trivial::error) << error_message;
}

void Logger::fatal(std::string fatal_message) {
  BOOST_LOG_SEV(lg, logging::trivial::fatal) << fatal_message;
}

void Logger::log_request(http::request<http::string_body>& req,
                         http::response<http::string_body>& res,
                         tcp::socket& sock) {
  std::string user_agent = req.base().find("User-Agent")->value().to_string();
  std::string remote_ip = sock.remote_endpoint().address().to_string();
  logger->info("Echoed request sent to path: " + req.target().to_string() +
               ", User-Agent: " + user_agent +
               ", Remote IP address: " + remote_ip);
}