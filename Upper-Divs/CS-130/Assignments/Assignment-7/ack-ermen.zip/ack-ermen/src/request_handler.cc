#include "request_handler.h"

RequestHandler::RequestHandler() { logger = Logger::getLogger(); }
