#include "dispatcher.h"

#include "not_found_request_handler.h"

Dispatcher::Dispatcher(NginxConfig& config) {
  this->server_handler_map_ =
      create_server_handler_map(config.GetLocationConfigs());
}

std::map<std::string, std::shared_ptr<RequestHandler>>
Dispatcher::create_server_handler_map(
    const std::vector<NginxLocationConfig>& location_configs) {
  std::map<std::string, std::shared_ptr<RequestHandler>> server_handler_map;

  // Sort the location configs by decreasing path length
  std::vector<NginxLocationConfig> sorted_location_configs = location_configs;
  std::sort(sorted_location_configs.begin(), sorted_location_configs.end(),
            [](const NginxLocationConfig& a, const NginxLocationConfig& b) {
              return a.path.length() > b.path.length();
            });

  // Populate the server handler map
  for (const auto& location_config : sorted_location_configs) {
    server_handler_map[location_config.path] =
        RequestHandlerFactory::create_handler(location_config);
  }

  return server_handler_map;
}

std::shared_ptr<RequestHandler> Dispatcher::get_request_handler(
    const std::string& path) {
  std::vector<std::string> keys;

  for (const auto& entry : server_handler_map_) {
    keys.push_back(entry.first);
  }

  // Must do this for longest common prefix matching
  std::sort(keys.begin(), keys.end(), [](const std::string& a, const std::string& b) {
    return a.length() > b.length();
  });

  for (const auto& key : keys) {
    if (path.compare(0, key.length(), key) == 0) {
      return server_handler_map_[key];
    }
  }

  return std::make_shared<NotFoundRequestHandler>();
}