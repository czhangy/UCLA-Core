#include "static_file_request_handler.h"

namespace http = boost::beast::http;
using tcp = boost::asio::ip::tcp;

http::status StaticFileRequestHandler::handle_request(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res) {
  std::string request_path = req.target().to_string();

  std::string full_path_to_file = get_full_path_to_file(request_path);

  std::ifstream file(full_path_to_file.c_str(), std::ios::binary);

  // If file not found, terminate request early
  if (!file.is_open()) {
    logger->error("File for " + request_path + " not found.\n");
    return http::status::not_found;
  }

  std::string file_contents = std::string(
      (std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
  res.body() = file_contents;
  res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
  res.set(http::field::content_type, get_content_type(full_path_to_file));
  res.content_length(file_contents.length());
  res.keep_alive(res.keep_alive());
  res.result(http::status::ok);

  res.prepare_payload();

  logger->info("File for " + request_path + " found. Sending file at " +
               full_path_to_file + " with type " +
               get_content_type(full_path_to_file) + "\n");
  return http::status::ok;
}

std::string StaticFileRequestHandler::get_content_type(
    const std::string& file_path) const {
  size_t ext_pos = file_path.find_last_of('.');
  if (ext_pos == std::string::npos) {
    return "application/octet-stream";
  }
  std::string extension = file_path.substr(ext_pos);
  if (extension == ".html") {
    return "text/html";
  } else if (extension == ".jpeg") {
    return "image/jpeg";
  } else if (extension == ".png") {
    return "image/png";
  } else if (extension == ".gif") {
    return "image/gif";
  } else if (extension == ".txt") {
    return "text/plain";
  } else if (extension == ".zip") {
    return "application/zip";
  } else {
    return "application/octet-stream";
  }
}

std::string StaticFileRequestHandler::get_full_path_to_file(
    std::string request_path) const {
  bool absolute = request_path[0] == '/';
  const std::string requested_path =
      absolute ? serving_dir_ : "./" + serving_dir_;
  return requested_path + request_path.substr(static_endpoint_.length());
}
