#include "request_handler_factory.h"

#include <memory>
#include <string>

#include "boost_filesystem.h"
#include "config_parser.h"
#include "crud_request_handler.h"
#include "echo_request_handler.h"
#include "filesystem.h"
#include "logger.h"
#include "not_found_request_handler.h"
#include "request_handler.h"
#include "session.h"
#include "static_file_request_handler.h"

std::shared_ptr<RequestHandler> RequestHandlerFactory::create_handler(
    const NginxLocationConfig& location_config) {
  const std::string& path = location_config.path;
  const std::string& handler = location_config.handler;

  if (handler == "EchoHandler") {
    return std::make_shared<EchoRequestHandler>();
  } else if (handler == "StaticHandler") {
    if (location_config.options.find("root") == location_config.options.end()) {
      logger->fatal("Static file request handler requires root option\n");
      return nullptr;
    }

    const std::string& file_serve_dir = location_config.options.at("root");
    return std::make_shared<StaticFileRequestHandler>(path, file_serve_dir);

  } else if (handler == "CRUDHandler") {
    if (location_config.options.find("data_path") ==
        location_config.options.end()) {
      logger->fatal("CRUD file request handler requires data_path option\n");
      return nullptr;
    }

    const std::string& file_serve_dir = location_config.options.at("data_path");
    std::unique_ptr<Filesystem> fs(new BoostFilesystem());
    return std::make_shared<CRUDRequestHandler>(path, file_serve_dir,
                                                std::move(fs));
  }

  return std::make_shared<NotFoundRequestHandler>();
}
