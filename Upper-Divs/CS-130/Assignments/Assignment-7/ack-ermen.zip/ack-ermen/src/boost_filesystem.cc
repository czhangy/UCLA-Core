#include "boost_filesystem.h"

bool BoostFilesystem::exists(fs::path path) { return fs::exists(path); }

std::vector<std::string> BoostFilesystem::get_entities_in_dir(fs::path path) {
  std::vector<std::string> entities;
  fs::directory_iterator end;
  for (fs::directory_iterator file(path); file != end; file++) {
    if (fs::is_regular_file(*file)) {
      entities.push_back(file->path().filename().string());
    }
  }
  // Sort entities, prioritizing length before lexicographical order
  sort(entities.begin(), entities.end(), [](std::string e1, std::string e2) {
    return e1.size() < e2.size() ? true : e1 < e2;
  });
  return entities;
}

bool BoostFilesystem::is_directory(fs::path path) {
  return fs::is_directory(path);
}

bool BoostFilesystem::is_regular_file(fs::path path) {
  return fs::is_regular_file(path);
}

void BoostFilesystem::remove(fs::path path) { fs::remove(path); }

std::string BoostFilesystem::get_file_contents(fs::path path) {
  fs::ifstream file(path);
  std::string file_contents((std::istreambuf_iterator<char>(file)),
                            std::istreambuf_iterator<char>());
  return file_contents;
}
void BoostFilesystem::create_directory(fs::path path) {
  fs::create_directory(path);
}

void BoostFilesystem::write_to_file(fs::path path, std::string content) {
  fs::ofstream file(path);
  file << content;
  file.flush();
}

void BoostFilesystem::create_data_path(std::string data_path) {
  if (fs::exists(data_path)) {
    return;
  }
  if (data_path[data_path.size() - 1] != '/') {
    data_path += "/";
  }
  int ind = 0;
  while (ind != std::string::npos) {
    ind = data_path.find("/", ind + 1);
    if (ind != std::string::npos) {
      fs::path path(data_path.substr(0, ind));
      if (!fs::exists(path)) {
        fs::create_directory(path);
      }
    }
  }
}
