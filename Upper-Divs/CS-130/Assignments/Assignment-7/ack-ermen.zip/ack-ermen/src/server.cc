#include "server.h"

#include <iostream>
#include <memory>

#include "config_parser.h"
#include "session.h"

server::server(boost::asio::io_service& io_service, short port,
               NginxConfig config)
    : acceptor_(io_service, tcp::endpoint(tcp::v4(), port)),
      socket_(io_service),
      config_(config) {
  start_accept();
}

void server::start_accept() {
  acceptor_.async_accept(socket_,
                         boost::bind(&server::handle_accept, this,
                                     boost::asio::placeholders::error));
}

void server::handle_accept(boost::system::error_code err_code) {
  if (!err_code) {
    std::make_shared<session>(std::move(socket_), config_)->start();
  }

  start_accept();
}
