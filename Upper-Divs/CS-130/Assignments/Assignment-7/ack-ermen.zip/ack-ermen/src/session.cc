#include "session.h"

#include <boost/filesystem.hpp>
#include <sstream>
#include <string>

#include "config_parser.h"
#include "dispatcher.h"
#include "not_found_request_handler.h"

session::session(tcp::socket socket, NginxConfig config)
    : socket_(std::move(socket)), config_(config) {}

void session::start() { handle_read(); }

void session::on_read(boost::system::error_code err_code,
                      std::size_t bytes_transferred) {
  if (err_code) {
    // Error code of 1 means end of stream, which is not an error, so ignore
    if (err_code.value() != 1) {
      logger->error("Error reading from socket: " + err_code.message() + "\n");
    }
    return;
  }

  auto callback = std::bind(&session::on_write, shared_from_this(),
                            std::placeholders::_1, std::placeholders::_2);

  logger->log_request(request_, response_, socket_);

  std::string request_path = request_.target().to_string();
  std::unique_ptr<Dispatcher> dispatcherPtr =
      std::make_unique<Dispatcher>(config_);
  auto request_handler = dispatcherPtr->get_request_handler(request_path);
  auto status = request_handler->handle_request(request_, response_);
  if (status == http::status::not_found) {
    auto not_found_handler = std::make_shared<NotFoundRequestHandler>();
    not_found_handler->handle_request(request_, response_);
  }

  http::async_write(socket_, response_, callback);
}

void session::on_write(boost::system::error_code err_code,
                       std::size_t bytes_transferred) {
  if (!err_code) {
    handle_read();
  }
}

void session::handle_read() {
  http::async_read(socket_, buffer_, request_,
                   std::bind(&session::on_read, shared_from_this(),
                             std::placeholders::_1, std::placeholders::_2));
}
