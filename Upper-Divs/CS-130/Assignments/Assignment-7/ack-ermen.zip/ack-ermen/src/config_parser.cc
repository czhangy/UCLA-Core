// An nginx config file parser.
//
// See:
//   http://wiki.nginx.org/Configuration
//   http://blog.martinfjordvald.com/2010/07/nginx-primer/
//
// How Nginx does it:
//   http://lxr.nginx.org/source/src/core/ngx_conf_file.c

#include "config_parser.h"

#include <cstdio>
#include <fstream>
#include <iostream>
#include <memory>
#include <stack>
#include <string>
#include <vector>

#include "logger.h"

std::string NginxConfig::ToString(int depth) {
  std::string serialized_config;
  for (const auto& statement : statements_) {
    serialized_config.append(statement->ToString(depth));
  }
  return serialized_config;
}

// Returns the port number from the config file
// Returns -1 if the port number is not found
const int NginxConfig::GetPort() {
  if (statements_.size() == 0) {
    logger->fatal("Config file is empty");
    return -1;
  }

  for (const auto& statement : statements_) {
    if (statement->tokens_.size() == 2 && statement->tokens_[0] == "listen") {
      const char* portStr = statement->tokens_[1].c_str();
      char* end;
      int port = std::strtol(portStr, &end, 10);

      // Port contains non numeric characters
      if (end == portStr || *end != '\0' || port < 0) {
        logger->fatal("Invalid port number");
        return -1;
      }
      return port;
    }
    // Check inside of nested blocks for the port number
    if (statement->child_block_.get() != nullptr) {
      int port = statement->child_block_->GetPort();
      if (port != -1) {
        logger->debug(
            logger->str_format("Port number %d found in config file", port));
        return port;
      }
    }
  }
  logger->fatal("Port number not found in config file");
  return -1;
}

std::vector<NginxLocationConfig> NginxConfig::GetLocationConfigs() {
  std::vector<NginxLocationConfig> location_configs;

  // Format is "location <path> <handler_type> { ... }"
  for (const auto& statement : statements_) {
    if (statement->tokens_.size() != 3 || statement->tokens_[0] != "location") {
      if (statement->child_block_.get() != nullptr) {
        std::vector<NginxLocationConfig> child_location_configs =
            statement->child_block_->GetLocationConfigs();

        location_configs.reserve(location_configs.size() +
                                 child_location_configs.size());
        location_configs.insert(location_configs.end(),
                                child_location_configs.begin(),
                                child_location_configs.end());
      }
      continue;
    }

    NginxLocationConfig location_config;
    location_config.path = statement->tokens_[1];
    location_config.handler = statement->tokens_[2];

    if (statement->child_block_.get() == nullptr) {
      location_configs.push_back(location_config);
      continue;
    }

    // Parse the options inside the block
    for (const auto& child_statement : statement->child_block_->statements_) {
      // Format is "root <path>"
      if (child_statement->tokens_.size() != 2) {
        continue;
      }

      // TODO: Consider supporting nested options
      std::string option = child_statement->tokens_[0];
      std::string value = child_statement->tokens_[1];
      location_config.options.insert(std::make_pair(option, value));
    }
    location_configs.push_back(location_config);
  }

  return location_configs;
}

std::string NginxConfigStatement::ToString(int depth) {
  std::string serialized_statement;
  for (int i = 0; i < depth; ++i) {
    serialized_statement.append("  ");
  }
  for (unsigned int i = 0; i < tokens_.size(); ++i) {
    if (i != 0) {
      serialized_statement.append(" ");
    }
    serialized_statement.append(tokens_[i]);
  }
  if (child_block_.get() != nullptr) {
    serialized_statement.append(" {\n");
    serialized_statement.append(child_block_->ToString(depth + 1));
    for (int i = 0; i < depth; ++i) {
      serialized_statement.append("  ");
    }
    serialized_statement.append("}");
  } else {
    serialized_statement.append(";");
  }
  serialized_statement.append("\n");
  return serialized_statement;
}

const char* NginxConfigParser::TokenTypeAsString(TokenType type) {
  switch (type) {
    case TOKEN_TYPE_START:
      return "TOKEN_TYPE_START";
    case TOKEN_TYPE_NORMAL:
      return "TOKEN_TYPE_NORMAL";
    case TOKEN_TYPE_START_BLOCK:
      return "TOKEN_TYPE_START_BLOCK";
    case TOKEN_TYPE_END_BLOCK:
      return "TOKEN_TYPE_END_BLOCK";
    case TOKEN_TYPE_COMMENT:
      return "TOKEN_TYPE_COMMENT";
    case TOKEN_TYPE_STATEMENT_END:
      return "TOKEN_TYPE_STATEMENT_END";
    case TOKEN_TYPE_EOF:
      return "TOKEN_TYPE_EOF";
    case TOKEN_TYPE_ERROR:
      return "TOKEN_TYPE_ERROR";
  }
}

bool IfWhitespaceExtended(char c) {
  return (c == ' ' || c == '\t' || c == '\n' || c == ';' || c == '{' ||
          c == '}');
}

char EscapeCharacter(char input) {
  switch (input) {
    case 'n':
      return '\n';
    case 't':
      return '\t';
    case 'r':
      return '\r';
    default:
      return input;
  }
}

NginxConfigParser::TokenType NginxConfigParser::ParseToken(std::istream* input,
                                                           std::string* value) {
  TokenParserState state = TOKEN_STATE_INITIAL_WHITESPACE;
  while (input->good()) {
    const char c = input->get();
    if (!input->good()) {
      break;
    }
    switch (state) {
      case TOKEN_STATE_INITIAL_WHITESPACE:
        switch (c) {
          case '{':
            *value = c;
            return TOKEN_TYPE_START_BLOCK;
          case '}':
            *value = c;
            return TOKEN_TYPE_END_BLOCK;
          case '#':
            *value = c;
            state = TOKEN_STATE_TOKEN_TYPE_COMMENT;
            continue;
          case '"':
            *value = c;
            state = TOKEN_STATE_DOUBLE_QUOTE;
            continue;
          case '\'':
            *value = c;
            state = TOKEN_STATE_SINGLE_QUOTE;
            continue;
          case ';':
            *value = c;
            return TOKEN_TYPE_STATEMENT_END;
          case ' ':
          case '\t':
          case '\n':
          case '\r':
            continue;
          default:
            *value += c;
            state = TOKEN_STATE_TOKEN_TYPE_NORMAL;
            continue;
        }
      case TOKEN_STATE_SINGLE_QUOTE:
        *value += c;
        if (c == '\'') {
          // Get next character to see if this is whitespace
          const char next_char = input->get();
          if (IfWhitespaceExtended(next_char)) {
            input->unget();
            return TOKEN_TYPE_NORMAL;
          } else
            return TOKEN_TYPE_ERROR;
        }
        if (c == '\\') {
          value->pop_back();
          state = TOKEN_STATE_SINGLE_QUOTE_ESCAPE;
        }
        continue;
      case TOKEN_STATE_DOUBLE_QUOTE:
        *value += c;
        if (c == '"') {
          // Get next character to see if this is whitespace
          const char next_char = input->get();
          if (IfWhitespaceExtended(next_char)) {
            input->unget();
            return TOKEN_TYPE_NORMAL;
          } else
            return TOKEN_TYPE_ERROR;
        }
        if (c == '\\') {
          value->pop_back();
          state = TOKEN_STATE_DOUBLE_QUOTE_ESCAPE;
        }
        continue;
      case TOKEN_STATE_TOKEN_TYPE_COMMENT:
        if (c == '\n' || c == '\r') {
          return TOKEN_TYPE_COMMENT;
        }
        *value += c;
        continue;
      case TOKEN_STATE_TOKEN_TYPE_NORMAL:
        if (IfWhitespaceExtended(c)) {
          input->unget();
          return TOKEN_TYPE_NORMAL;
        }
        *value += c;
        continue;
      case TOKEN_STATE_SINGLE_QUOTE_ESCAPE:
        *value += EscapeCharacter(c);
        state = TOKEN_STATE_SINGLE_QUOTE;
        break;
      case TOKEN_STATE_DOUBLE_QUOTE_ESCAPE:
        *value += EscapeCharacter(c);
        state = TOKEN_STATE_DOUBLE_QUOTE;
        break;
    }
  }

  // If we get here, we reached the end of the file.
  if (state == TOKEN_STATE_SINGLE_QUOTE || state == TOKEN_STATE_DOUBLE_QUOTE) {
    logger->fatal("Unterminated quoted string, have lonely quote mark ' or \"");
    return TOKEN_TYPE_ERROR;
  }

  return TOKEN_TYPE_EOF;
}

bool NginxConfigParser::Parse(std::istream* config_file, NginxConfig* config) {
  std::stack<NginxConfig*> config_stack;
  config_stack.push(config);
  TokenType last_token_type = TOKEN_TYPE_START;
  TokenType token_type;
  int count_of_open_curly_seen_until_now = 0;
  int count_of_closed_curly_seen_until_now = 0;
  while (true) {
    std::string token;
    token_type = ParseToken(config_file, &token);
    logger->debug(logger->str_format("%s: %s\n", TokenTypeAsString(token_type),
                                     token.c_str()));
    if (token_type == TOKEN_TYPE_ERROR) {
      logger->fatal("Invalid config, lack of whitespace after ' or \"");
      break;
    }

    if (token_type == TOKEN_TYPE_COMMENT) {
      logger->trace("Skip comments");
      continue;
    }

    if (token_type == TOKEN_TYPE_START) {
      logger->fatal("Invalid token type TOKEN_TYPE_START");
      break;
    } else if (token_type == TOKEN_TYPE_NORMAL) {
      if (last_token_type == TOKEN_TYPE_START ||
          last_token_type == TOKEN_TYPE_STATEMENT_END ||
          last_token_type == TOKEN_TYPE_START_BLOCK ||
          last_token_type == TOKEN_TYPE_END_BLOCK ||
          last_token_type == TOKEN_TYPE_NORMAL) {
        if (last_token_type != TOKEN_TYPE_NORMAL) {
          config_stack.top()->statements_.emplace_back(
              new NginxConfigStatement);
        }
        config_stack.top()->statements_.back().get()->tokens_.push_back(token);
      } else {
        logger->fatal("Invalid token type after TOKEN_TYPE_NORMAL");
        break;
      }
    } else if (token_type == TOKEN_TYPE_STATEMENT_END) {
      if (last_token_type != TOKEN_TYPE_NORMAL) {
        logger->fatal("Invalid token type after ;");
        break;
      }
    } else if (token_type == TOKEN_TYPE_START_BLOCK) {
      if (last_token_type != TOKEN_TYPE_NORMAL) {
        logger->fatal("Invalid token type after {");
        break;
      }
      NginxConfig* const new_config = new NginxConfig;
      config_stack.top()->statements_.back().get()->child_block_.reset(
          new_config);
      config_stack.push(new_config);
      count_of_open_curly_seen_until_now++;
    } else if (token_type == TOKEN_TYPE_END_BLOCK) {
      // It is not invalid to have two } after each other, need to make sure
      // there are atleast the number of { before accepting another }
      count_of_closed_curly_seen_until_now++;
      if (last_token_type != TOKEN_TYPE_STATEMENT_END) {
        if (last_token_type == TOKEN_TYPE_END_BLOCK &&
            count_of_open_curly_seen_until_now >=
                count_of_closed_curly_seen_until_now)
          continue;
        else
          logger->fatal("Extra invalid }");
        break;
      }
      config_stack.pop();
    } else if (token_type == TOKEN_TYPE_EOF) {
      // Check if the number of { match the number of }
      if (count_of_closed_curly_seen_until_now !=
          count_of_open_curly_seen_until_now) {
        logger->fatal("Non-matching number of { and }\n");
        return false;
      }

      if (last_token_type != TOKEN_TYPE_STATEMENT_END &&
          last_token_type != TOKEN_TYPE_END_BLOCK &&
          last_token_type != TOKEN_TYPE_START) {
        logger->fatal(
            "Invalid token previous to EOF, check end of config file");
        break;
      }
      return true;
    }

    last_token_type = token_type;
  }

  logger->fatal(logger->str_format("Bad transition from %s to %s\n",
                                   TokenTypeAsString(last_token_type),
                                   TokenTypeAsString(token_type)));
  return false;
}

bool NginxConfigParser::Parse(const char* file_name, NginxConfig* config) {
  std::ifstream config_file;
  config_file.open(file_name);
  if (!config_file.good()) {
    logger->fatal(
        logger->str_format("Failed to open config file: %s\n", file_name));
    return false;
  }

  logger->debug(logger->str_format("Opened config file: %s\n", file_name));

  const bool return_value =
      Parse(dynamic_cast<std::istream*>(&config_file), config);
  config_file.close();
  return return_value;
}
