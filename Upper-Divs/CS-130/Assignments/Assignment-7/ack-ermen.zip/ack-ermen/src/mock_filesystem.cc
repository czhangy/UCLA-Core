#include "mock_filesystem.h"

#include <iostream>

MockFilesystem::MockFilesystem(
    const std::unordered_map<std::string, std::vector<MockFile>>& fs,
    std::string data_path)
    : fs_(fs), data_path_(data_path) {}

bool MockFilesystem::exists(fs::path path) {
  std::string dir = get_directory(path);
  std::string file = get_file(path);
  if (fs_.find(dir) == fs_.end()) {
    return false;
  }
  if (file.empty()) {
    return true;
  }
  for (MockFile f : fs_[dir]) {
    if (f.name == file) {
      return true;
    }
  }
  return false;
}

std::vector<std::string> MockFilesystem::get_entities_in_dir(fs::path path) {
  std::vector<std::string> entities;
  std::string dir = get_directory(path);
  if (fs_.find(dir) == fs_.end()) {
    return {};
  }
  for (MockFile f : fs_[dir]) {
    entities.push_back(f.name);
  }
  // Sort entities, prioritizing length before lexicographical order
  sort(entities.begin(), entities.end(), [](std::string e1, std::string e2) {
    return e1.size() < e2.size() ? true : e1 < e2;
  });
  return entities;
}

std::string MockFilesystem::get_file_contents(fs::path path) {
  std::string dir = get_directory(path);
  std::string file = get_file(path);
  if (fs_.find(dir) == fs_.end()) {
    return "";
  }
  for (MockFile f : fs_[dir]) {
    if (f.name == file) {
      return f.contents;
    }
  }
  return "";
}

bool MockFilesystem::is_directory(fs::path path) {
  std::string file = get_file(path);
  return file.empty();
}

bool MockFilesystem::is_regular_file(fs::path path) {
  std::string file = get_file(path);
  return !file.empty();
}

void MockFilesystem::remove(fs::path path) {
  std::string dir = get_directory(path);
  std::string file = get_file(path);
  if (fs_.find(dir) == fs_.end()) {
    return;
  }
  for (int i = 0; i < fs_[dir].size(); i++) {
    if (fs_[dir][i].name == file) {
      fs_[dir].erase(fs_[dir].begin() + i);
      break;
    }
  }
}

std::string MockFilesystem::get_directory(fs::path path) {
  std::string dir = path.string().substr(data_path_.size() + 1);
  std::size_t ind = dir.find("/");
  if (ind != std::string::npos) {
    dir = dir.substr(0, ind);
  }
  return dir;
}

std::string MockFilesystem::get_file(fs::path path) {
  std::string dir = path.string().substr(data_path_.size() + 1);
  std::size_t ind = dir.find("/");
  if (ind != std::string::npos) {
    return dir.substr(ind + 1);
  }
  return "";
}

void MockFilesystem::create_directory(fs::path path) {
  std::string dir = get_directory(path);
  if (fs_.find(dir) == fs_.end()) {
    fs_[dir] = {};
  }
}

void MockFilesystem::write_to_file(fs::path path, std::string content) {
  std::string dir = get_directory(path);
  std::string file = get_file(path);

  if (fs_.find(dir) == fs_.end()) {
    return;
  }

  for (int i = 0; i < fs_[dir].size(); i++) {
    if (fs_[dir][i].name == file) {
      fs_[dir][i].contents = content;
      return;
    }
  }

  if (!file.empty()) fs_[dir].push_back({file, content});
}

void MockFilesystem::create_data_path(std::string data_path) {}
