#ifndef STATIC_FILE_REQUEST_HANDLER
#define STATIC_FILE_REQUEST_HANDLER

#include "request_handler.h"

namespace http = boost::beast::http;
using tcp = boost::asio::ip::tcp;

class StaticFileRequestHandler : public RequestHandler {
 public:
  StaticFileRequestHandler(const std::string& static_endpoint,
                           const std::string& serving_dir)
      : static_endpoint_(static_endpoint), serving_dir_(serving_dir) {}
  http::status handle_request(const http::request<http::string_body>& req,
                              http::response<http::string_body>& res);

 private:
  std::string get_content_type(const std::string& file_path) const;
  std::string get_full_path_to_file(std::string request_path) const;
  std::string static_endpoint_;
  std::string serving_dir_;
};

#endif  // STATIC_FILE_REQUEST_HANDLER
