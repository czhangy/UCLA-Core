#ifndef LOGGER_H
#define LOGGER_H

#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/log/trivial.hpp>
#include <cstdarg>
#include <string>

namespace logging = boost::log;
namespace src = boost::log::sources;
namespace sinks = boost::log::sinks;
namespace keywords = boost::log::keywords;

namespace beast = boost::beast;
namespace http = beast::http;
using boost::asio::ip::tcp;

class Logger {
 public:
  void init();
  Logger();
  void trace(std::string trace_message);
  void error(std::string error_message);
  void info(std::string info_message);
  void debug(std::string debug_message);
  void warning(std::string warning_message);
  void fatal(std::string fatal_message);
  void log_request(http::request<http::string_body>& request,
                   http::response<http::string_body>& response_,
                   tcp::socket& socket);

  src::severity_logger<logging::trivial::severity_level> lg;
  static Logger* logger_ptr;
  static Logger* getLogger() {
    if (logger_ptr == nullptr) {
      logger_ptr = new Logger();
    }
    return logger_ptr;
  }

  // Can't find a way to put this in logger.cc and have code compile, if
  // possible, will fix later
  template <typename... Args>
  std::string str_format(const char* fmt, Args... args) {
    std::size_t size = std::snprintf(nullptr, 0, fmt,
                                     args...);  // Get size of formatted string
    std::string str(size, '\0');          // Create string of the required size
    std::sprintf(&str[0], fmt, args...);  // Write formatted string to string
    return str;
  }
};

extern Logger* logger;

#endif  // LOGGER_H
