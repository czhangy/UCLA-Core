#ifndef CRUD_REQUEST_HANDLER_H
#define CRUD_HANDLER_H

#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/filesystem.hpp>
#include <fstream>
#include <iostream>
#include <memory>
#include <nlohmann/json.hpp>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "filesystem.h"
#include "logger.h"
#include "request_handler.h"

namespace bfs = boost::filesystem;

class CRUDRequestHandler : public RequestHandler {
 public:
  CRUDRequestHandler(const std::string& crud_endpoint,
                     const std::string& data_path,
                     std::unique_ptr<Filesystem> fs);

  http::status handle_request(const http::request<http::string_body>& req,
                              http::response<http::string_body>& res);
  http::status create(const http::request<http::string_body>& req,
                      http::response<http::string_body>& res,
                      const bfs::path& path);
  http::status retrieve(const http::request<http::string_body>& req,
                        http::response<http::string_body>& res,
                        const bfs::path& path);
  http::status update(const http::request<http::string_body>& req,
                      http::response<http::string_body>& res,
                      const bfs::path& path);
  http::status del(const http::request<http::string_body>& req,
                   http::response<http::string_body>& res,
                   const bfs::path& path);
  http::status list(const http::request<http::string_body>& req,
                    http::response<http::string_body>& res,
                    const bfs::path& dir_path);

 private:
  std::string get_full_path_to_file(std::string request_path) const;
  std::string crud_endpoint_;
  std::string data_path_;
  std::unique_ptr<Filesystem> fs_;
};

#endif  // CRUD_REQUEST_HANDLER_H
