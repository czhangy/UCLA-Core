#ifndef NOT_FOUND_REQUEST_HANDLER_H
#define NOT_FOUND_REQUEST_HANDLER_H

#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <fstream>
#include <iostream>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "request_handler.h"

namespace asio = boost::asio;
namespace beast = boost::beast;

class NotFoundRequestHandler : public RequestHandler {
 public:
  http::status handle_request(const http::request<http::string_body>& req,
                              http::response<http::string_body>& res);
};

#endif  // NOT_FOUND_REQUEST_HANDLER_H
