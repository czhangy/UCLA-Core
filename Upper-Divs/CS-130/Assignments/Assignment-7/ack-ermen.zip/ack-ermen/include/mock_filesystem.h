#ifndef MOCK_FILESYSTEM_H
#define MOCK_FILESYSTEM_H

#include <boost/filesystem.hpp>
#include <string>
#include <unordered_map>

#include "filesystem.h"

namespace fs = boost::filesystem;

class MockFilesystem : public Filesystem {
 public:
  struct MockFile {
    std::string name;
    std::string contents;
  };

  MockFilesystem(
      const std::unordered_map<std::string, std::vector<MockFile>>& fs,
      std::string data_path);
  bool exists(fs::path path);
  std::vector<std::string> get_entities_in_dir(fs::path path);
  std::string get_file_contents(fs::path path);
  bool is_directory(fs::path path);
  bool is_regular_file(fs::path path);
  void remove(fs::path path);
  void create_directory(fs::path path);
  void write_to_file(fs::path path, std::string content);
  void create_data_path(std::string data_path);

 private:
  std::string get_directory(fs::path path);
  std::string get_file(fs::path path);
  std::unordered_map<std::string, std::vector<MockFile>> fs_;
  std::string data_path_;
};

#endif  // MOCK_FILESYSTEM_H
