#ifndef REQUEST_HANDLER_H
#define REQUEST_HANDLER_H

#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <fstream>
#include <iostream>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "logger.h"

namespace asio = boost::asio;
namespace beast = boost::beast;
namespace http = beast::http;
using tcp = asio::ip::tcp;

class RequestHandler {
 public:
  RequestHandler();
  virtual http::status handle_request(
      const http::request<http::string_body>& req,
      http::response<http::string_body>& res) = 0;
};

#endif  // REQUEST_HANDLER_H
