#ifndef SESSION_H
#define SESSION_H

#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/bind.hpp>
#include <memory>

#include "config_parser.h"
#include "logger.h"
#include "request_handler.h"

namespace http = boost::beast::http;
using tcp = boost::asio::ip::tcp;

class session : public std::enable_shared_from_this<session> {
 public:
  session(tcp::socket socket, NginxConfig config);
  void start();

 private:
  void handle_read();
  void on_read(boost::system::error_code ec, std::size_t bytes_transferred);
  void on_write(boost::system::error_code ec, std::size_t bytes_transferred);

  NginxConfig config_;

  tcp::socket socket_;
  boost::beast::flat_buffer buffer_;
  http::request<http::string_body> request_;
  http::response<http::string_body> response_;
};

#endif  // SESSION_H
