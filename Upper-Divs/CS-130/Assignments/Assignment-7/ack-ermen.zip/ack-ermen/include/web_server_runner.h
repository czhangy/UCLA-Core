#ifndef WEB_SERVER_RUNNER_H
#define WEB_SERVER_RUNNER_H

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <cstdlib>
#include <iostream>

using boost::asio::ip::tcp;

class web_server_runner {
 public:
  web_server_runner(int argc, char* argv[]) : argc_(argc), argv_(argv) {}
  int run();
  void shutdown();

 private:
  int argc_;
  char** argv_;
};

#endif  // WEB_SERVER_RUNNER_H
