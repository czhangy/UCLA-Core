#ifndef SERVER_H
#define SERVER_H

#include <boost/asio.hpp>

#include "config_parser.h"

using boost::asio::ip::tcp;

class server {
 public:
  server(boost::asio::io_service& io_service, short port, NginxConfig config);

 private:
  void start_accept();
  void handle_accept(boost::system::error_code err_code);

  tcp::acceptor acceptor_;
  tcp::socket socket_;
  NginxConfig config_;
};

#endif  // SERVER_H
