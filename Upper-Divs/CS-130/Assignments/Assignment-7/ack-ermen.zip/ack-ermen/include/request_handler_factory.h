#ifndef REQUEST_HANDLER_FACTORY_H
#define REQUEST_HANDLER_FACTORY_H

#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <string>

#include "config_parser.h"
#include "request_handler.h"

namespace asio = boost::asio;
namespace beast = boost::beast;

class RequestHandler;

class RequestHandlerFactory {
 public:
  static std::shared_ptr<RequestHandler> create_handler(
      const NginxLocationConfig& location_config);
};

#endif  // REQUEST_HANDLER_FACTORY_H
