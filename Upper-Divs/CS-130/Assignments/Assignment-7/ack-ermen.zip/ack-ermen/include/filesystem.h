#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <boost/filesystem.hpp>
#include <vector>

namespace fs = boost::filesystem;

class Filesystem {
 public:
  virtual bool exists(fs::path path) = 0;
  virtual std::vector<std::string> get_entities_in_dir(fs::path path) = 0;
  virtual std::string get_file_contents(fs::path path) = 0;
  virtual bool is_directory(fs::path path) = 0;
  virtual bool is_regular_file(fs::path path) = 0;
  virtual void remove(fs::path path) = 0;
  virtual void create_directory(fs::path path) = 0;
  virtual void write_to_file(fs::path path, std::string content) = 0;
  virtual void create_data_path(std::string data_path) = 0;
};

#endif  // FILESYSTEM_H
