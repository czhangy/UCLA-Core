#ifndef DISPATCHER_H
#define DISPATCHER_H

#include <boost/system/error_code.hpp>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "config_parser.h"
#include "request_handler.h"
#include "request_handler_factory.h"

class Dispatcher {
 public:
  Dispatcher(NginxConfig& config);

  std::shared_ptr<RequestHandler> get_request_handler(const std::string& path);

 private:
  std::map<std::string, std::shared_ptr<RequestHandler>>
  create_server_handler_map(
      const std::vector<NginxLocationConfig>& location_configs);

  std::map<std::string, std::shared_ptr<RequestHandler>> server_handler_map_;
};

#endif  // DISPATCHER_H
