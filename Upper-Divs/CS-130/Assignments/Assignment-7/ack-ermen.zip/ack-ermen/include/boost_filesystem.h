#ifndef BOOST_FILESYSTEM_H
#define BOOST_FILESYSTEM_H

#include <boost/filesystem.hpp>
#include <string>
#include <vector>

#include "filesystem.h"

namespace fs = boost::filesystem;

class BoostFilesystem : public Filesystem {
 public:
  bool exists(fs::path path);
  std::vector<std::string> get_entities_in_dir(fs::path path);
  std::string get_file_contents(fs::path path);
  bool is_directory(fs::path path);
  bool is_regular_file(fs::path path);
  void remove(fs::path path);
  void create_directory(fs::path path);
  void write_to_file(fs::path path, std::string content);
  void create_data_path(std::string data_path);
};

#endif  // BOOST_FILESYSTEM_H