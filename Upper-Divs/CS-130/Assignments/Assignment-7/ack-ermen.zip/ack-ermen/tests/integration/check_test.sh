#!/bin/bash

test_number=${1:-0}
integration_folder_path=${2:-"../tests/integration"}
response_file_path=${3:-"${integration_folder_path}/responses/test_response${test_number}"}
correct_file_path=${4:-"${integration_folder_path}/correct_responses/correct_response${test_number}"}

diff ${response_file_path} ${correct_file_path} 2> error_file > diff_file
exit_code=$?
echo exit_code is ${exit_code}

if [ -s diff_file ]
  then
    echo "Failure"
    echo "Difference is below"
    cat diff_file
    rm diff_file
    exit 1
  else
    echo "No difference"
    cat diff_file
fi

if [ -s error_file ]
  then
    echo "Failure"
    echo "Error is below"
    cat error_file
    rm diff_file
    exit 1
  else
    echo "No error"
    cat error_file
    rm error_file
    echo "Success"
    rm diff_file
    exit 0
    # rm ${response_file_path}
fi
