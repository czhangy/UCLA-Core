#!/bin/bash

cd ../

local=${1:-0}
if [ $local -eq 1 ]
then
  echo "ran test.sh to start server locally"
  server_path="../../build"
  test_path="../../.."
else
  echo "ran test.sh to start server from make test"
  server_path="build"
  test_path="."
fi

cwd=$(pwd)

SERVER_MAIN_EXECUTABLE_PATH="$cwd/$server_path/bin/server_main"
SERVER_EXECUTABLE_PATH="$cwd/$server_path/bin/server"
CONFIG_INPUT_PATH="$cwd/$test_path/tests/integration/example.conf"
INTEGRATION_FOLDER_PATH="$cwd/$test_path/tests/integration"

echo "SERVER_MAIN_EXECUTABLE_PATH is ${SERVER_MAIN_EXECUTABLE_PATH}"
echo "SERVER_EXECUTABLE_PATH is ${SERVER_EXECUTABLE_PATH}"
echo "CONFIG_INPUT_PATH is ${CONFIG_INPUT_PATH}"
echo "INTEGRATION_FOLDER_PATH is ${INTEGRATION_FOLDER_PATH}"

# Now run server while passing in the config file
${SERVER_EXECUTABLE_PATH} ${CONFIG_INPUT_PATH} > /dev/null &
server_pid=$!
sleep 1

mkdir ${INTEGRATION_FOLDER_PATH}/responses

# run test 4
echo "test 4, proper static file GET request for .html file ..."
curl 127.0.0.1:3000/static/test.html -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test4.html
${INTEGRATION_FOLDER_PATH}/check_test.sh 4 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test4.html ${INTEGRATION_FOLDER_PATH}/correct_responses/test.html
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 5
echo "test 5, proper static file GET request for .jpg file ..."
curl 127.0.0.1:3000/static/test.jpg -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test5.jpg
${INTEGRATION_FOLDER_PATH}/check_test.sh 5 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test5.jpg ${INTEGRATION_FOLDER_PATH}/correct_responses/test.jpg
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 6
echo "test 6, proper static file GET request for .json file ..."
curl 127.0.0.1:3000/static/test.json -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test6.json
${INTEGRATION_FOLDER_PATH}/check_test.sh 6 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test6.json ${INTEGRATION_FOLDER_PATH}/correct_responses/test.json
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 7
echo "test 7, proper static file GET request for .txt file ..."
curl 127.0.0.1:3000/static/test.txt -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test7.txt
${INTEGRATION_FOLDER_PATH}/check_test.sh 7 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test7.txt ${INTEGRATION_FOLDER_PATH}/correct_responses/test.txt
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 8
echo "test 8, proper static file GET request for .zip file ..."
curl 127.0.0.1:3000/static/test.zip -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test8.zip
${INTEGRATION_FOLDER_PATH}/check_test.sh 8 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test8.zip ${INTEGRATION_FOLDER_PATH}/correct_responses/test.zip
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 9
echo "test 9, try to GET a file that doesn't exist ..."
curl 127.0.0.1:3000/static/doesnt_exist.html -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test9.html
${INTEGRATION_FOLDER_PATH}/check_test.sh 9 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test9.html ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response9.html
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# kill server to prevent port from being used indefinitely
${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 0
