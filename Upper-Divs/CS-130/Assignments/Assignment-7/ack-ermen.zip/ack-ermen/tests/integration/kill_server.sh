#!/bin/bash

server_pid=$1
exit_code=${2:-1}

kill $server_pid
if [ $exit_code -eq 0 ]
then
  echo "Killed server, passed test"
  exit 0
else
  echo "Killed server, failed test"
  exit 1
fi
