#!/bin/bash

cd ..

SERVER_MAIN_EXECUTABLE_PATH="build/bin/server_main"
SERVER_EXECUTABLE_PATH="build/bin/server"
CONFIG_INPUT_PATH="tests/integration/example.conf"
INTEGRATION_FOLDER_PATH="tests/integration"

echo "SERVER_MAIN_EXECUTABLE_PATH is ${SERVER_MAIN_EXECUTABLE_PATH}"
echo "SERVER_EXECUTABLE_PATH is ${SERVER_EXECUTABLE_PATH}"
echo "CONFIG_INPUT_PATH is ${CONFIG_INPUT_PATH}"
echo "INTEGRATION_FOLDER_PATH is ${INTEGRATION_FOLDER_PATH}"

# Now run server while passing in the config file
${SERVER_EXECUTABLE_PATH} ${CONFIG_INPUT_PATH} > /dev/null &
server_pid=$!
sleep 1

mkdir ${INTEGRATION_FOLDER_PATH}/responses

# run test 10
echo "test 10, proper file creation ..."
curl -X POST 127.0.0.1:3000/api/Test -d '{"content": 1}' -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response10
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response10 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response10
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 11
echo "test 11, proper file creation ..."
curl -X POST 127.0.0.1:3000/api/Test -d '{"content": 2}' -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response11
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response11 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response11
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 12
echo "test 12, proper file update ..."
curl -X PUT 127.0.0.1:3000/api/Test/2 -d '{"content": 3}' -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response12
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response12 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response12
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 13
echo "test 13, proper file get ..."
curl -X GET 127.0.0.1:3000/api/Test/2 -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response13
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response13 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response13
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 14
echo "test 14, proper file list ..."
curl -X GET 127.0.0.1:3000/api/Test -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response14
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response14 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response14
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 15
echo "test 15, proper file delete ..."
curl -X DELETE 127.0.0.1:3000/api/Test/1 -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response15
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response15 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response15
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 16
echo "test 16, proper file delete ..."
curl -X DELETE 127.0.0.1:3000/api/Test/2 -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response16
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response16 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response15
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# kill server to prevent port from being used indefinitely
${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 0
