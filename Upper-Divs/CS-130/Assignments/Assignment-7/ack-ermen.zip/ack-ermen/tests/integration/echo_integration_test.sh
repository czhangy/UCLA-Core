#!/bin/bash

local=${1:-0}
if [ $local -eq 1 ]
then
  echo "ran test.sh to start server locally"
  server_path="../../build"
  test_path="../.."
else
  echo "ran test.sh to start server from make test"
  server_path="../build"
  test_path=".."
fi

cwd=$(pwd)

SERVER_MAIN_EXECUTABLE_PATH="$cwd/$server_path/bin/server_main"
SERVER_EXECUTABLE_PATH="$cwd/$server_path/bin/server"
CONFIG_INPUT_PATH="$cwd/$test_path/tests/integration/example.conf"
INTEGRATION_FOLDER_PATH="$cwd/$test_path/tests/integration"

echo "SERVER_MAIN_EXECUTABLE_PATH is ${SERVER_MAIN_EXECUTABLE_PATH}"
echo "SERVER_EXECUTABLE_PATH is ${SERVER_EXECUTABLE_PATH}"
echo "CONFIG_INPUT_PATH is ${CONFIG_INPUT_PATH}"
echo "INTEGRATION_FOLDER_PATH is ${INTEGRATION_FOLDER_PATH}"

# Now run server while passing in the config file
${SERVER_EXECUTABLE_PATH} ${CONFIG_INPUT_PATH} > /dev/null &
server_pid=$!
sleep 1

mkdir ${INTEGRATION_FOLDER_PATH}/responses

# run test 1
echo "test 1, proper curl GET request test ..."
curl 127.0.0.1:3000/echo -A "curl/7.81.0" -s -S > ${INTEGRATION_FOLDER_PATH}/responses/test_response1
${INTEGRATION_FOLDER_PATH}/check_test.sh 1 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response1 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response1
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# run test 2
# echo "test 2, proper GET request test using nc ..."
# printf "%s\r\n%s\r\n%s\r\n\r\n" \
#   "GET /echo HTTP/1.1"          \
#   "Host: www.google.com"        \
#   "Connection: close"           \
#   | nc 127.0.0.1 3000 -q 0        \
#   > ${INTEGRATION_FOLDER_PATH}/responses/test_response2
# ${INTEGRATION_FOLDER_PATH}/check_test.sh 2 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response2 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response2
# exit_code=$?
# if [ ${exit_code} -ne 0 ]
# then
#   echo exit_code is ${exit_code}
#   ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
#   exit 1
# fi

# run test 3
echo "test 3, missing GET in first line of request using nc test ..."
printf "%s\r\n%s\r\n%s\r\n\r\n" \
  "/echo HTTP/1.1"              \
  "Host: www.google.com"        \
  "Connection: close"           \
  | nc 127.0.0.1 3000 -q 0        \
  > ${INTEGRATION_FOLDER_PATH}/responses/test_response3
${INTEGRATION_FOLDER_PATH}/check_test.sh 3 ${INTEGRATION_FOLDER_PATH} ${INTEGRATION_FOLDER_PATH}/responses/test_response3 ${INTEGRATION_FOLDER_PATH}/correct_responses/correct_response3
exit_code=$?
if [ ${exit_code} -ne 0 ]
then
  echo exit_code is ${exit_code}
  ${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 1
  exit 1
fi

# kill server to prevent port from being used indefinitely
${INTEGRATION_FOLDER_PATH}/kill_server.sh ${server_pid} 0
