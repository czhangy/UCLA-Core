#include "dispatcher.h"

#include <gmock/gmock.h>
#include <gtest/gtest.h>

#include "config_parser.h"
#include "echo_request_handler.h"
#include "not_found_request_handler.h"
#include "request_handler.h"
#include "request_handler_factory.h"
#include "static_file_request_handler.h"

// Mock classes for testing
class MockRequestHandler : public RequestHandler {
 public:
  MOCK_METHOD2(handle_request,
               http::status(const http::request<http::string_body>& req,
                            http::response<http::string_body>& res));
};

class MockRequestHandlerFactory : public RequestHandlerFactory {
 public:
  static std::shared_ptr<RequestHandler> create_handler(
      const NginxLocationConfig& location_config) {
    return std::make_shared<MockRequestHandler>();
  }
};

class DispatcherTest : public ::testing::Test {
 protected:
  void SetUp() override { config_parser.Parse("example_config", &config); }

  NginxConfigParser config_parser;
  NginxConfig config;
};

TEST_F(DispatcherTest, RequestHandlerNoMatchFound) {
  Dispatcher dispatcher(config);

  std::shared_ptr<RequestHandler> handler =
      dispatcher.get_request_handler("/no/match");
  EXPECT_NE(nullptr, handler);
  EXPECT_NE(std::dynamic_pointer_cast<NotFoundRequestHandler>(handler),
            nullptr);
}

TEST_F(DispatcherTest, EchoRequestHandlerMatchFound) {
  Dispatcher dispatcher(config);

  std::shared_ptr<RequestHandler> handler =
      dispatcher.get_request_handler("/echo");
  EXPECT_NE(nullptr, handler);
  EXPECT_NE(std::dynamic_pointer_cast<EchoRequestHandler>(handler), nullptr);
}

TEST_F(DispatcherTest, StaticFileRequestHandlerMatchFound) {
  Dispatcher dispatcher(config);

  std::shared_ptr<RequestHandler> handler =
      dispatcher.get_request_handler("/static");
  EXPECT_NE(nullptr, handler);
  EXPECT_NE(std::dynamic_pointer_cast<StaticFileRequestHandler>(handler),
            nullptr);
}