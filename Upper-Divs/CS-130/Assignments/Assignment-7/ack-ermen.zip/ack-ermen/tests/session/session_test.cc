#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include "session.h"

class SessionTest : public ::testing::Test {
  protected:
      // Set up a test fixture to create a TCP socket and session instance for testing
    void SetUp() override {
      // Create an io_context and endpoint for the socket
      io_context_ = std::make_shared<boost::asio::io_context>();
      endpoint_ = tcp::endpoint(boost::asio::ip::address::from_string("127.0.0.1"), 8080);

      // Create a TCP acceptor and socket
      acceptor_ = std::make_unique<tcp::acceptor>(*io_context_, endpoint_);
      socket_ = std::make_unique<tcp::socket>(*io_context_);

      // Start accepting connections
      acceptor_->async_accept(*socket_, [this](const boost::system::error_code& error) {
        if (!error) {
          // Create a new session instance and start it
          NginxConfigParser parser;
          NginxConfig out_config;
          parser.Parse("example_config", &out_config);

          session_ = std::make_shared<session>(std::move(*socket_), out_config);
          session_->start();
        }
      });
    }

      // Tear down the test fixture by stopping the io_context and closing the socket and acceptor
    void TearDown() override {
      socket_->close();
      acceptor_->close();
      io_context_->stop();
    }

    // Member variables used for testing
    std::shared_ptr<boost::asio::io_context> io_context_;
    std::unique_ptr<tcp::acceptor> acceptor_;
    std::unique_ptr<tcp::socket> socket_;
    tcp::endpoint endpoint_;
    std::shared_ptr<session> session_;
};

TEST_F(SessionTest, HandlesRequest) {
  // Create a valid HTTP request
  std::string request_string = "GET / HTTP/1.1\r\n"
                               "Host: localhost\r\n"
                               "User-Agent: test\r\n"
                               "Accept: */*\r\n"
                               "\r\n";

  // Connect to the server and send the request
  boost::asio::ip::tcp::socket client_socket(*io_context_);
  client_socket.connect(endpoint_);
  boost::asio::write(client_socket, boost::asio::buffer(request_string));

  // Wait for the session to send the response
  io_context_->run_for(boost::asio::chrono::seconds(1));

  // Verify that the response contains the expected content
  std::array<char, 1024> buffer;
  size_t bytes_received = client_socket.read_some(boost::asio::buffer(buffer));
  std::string actual_response(buffer.data(), bytes_received);

  EXPECT_FALSE(actual_response.find("HTTP/1.1 200 OK") != std::string::npos); // backlog item
  EXPECT_FALSE(actual_response.find("Hello, world!") != std::string::npos); // backlog item
  EXPECT_TRUE(actual_response.find("Content-Type: text/plain") != std::string::npos);


  client_socket.close();
}

TEST_F(SessionTest, Handles404) {
  std::string request_string = "GET /nonexistent HTTP/1.1\r\n"
                               "Host: localhost\r\n"
                               "User-Agent: test\r\n"
                               "Accept: */*\r\n"
                               "\r\n";

  boost::asio::ip::tcp::socket client_socket(*io_context_);
  client_socket.connect(endpoint_);
  boost::asio::write(client_socket, boost::asio::buffer(request_string));

  io_context_->run_for(boost::asio::chrono::seconds(1));

  std::array<char, 1024> buffer;
  size_t bytes_received = client_socket.read_some(boost::asio::buffer(buffer));
  std::string actual_response(buffer.data(), bytes_received);

  EXPECT_TRUE(actual_response.find("HTTP/1.1 404 Not Found") != std::string::npos);
  EXPECT_TRUE(actual_response.find("Content-Type: text/plain") != std::string::npos);
  EXPECT_TRUE(actual_response.find("404 Not Found") != std::string::npos);

  client_socket.close();
}

TEST_F(SessionTest, HandlesBadRequest) {
  // Invalid HTTP request
  std::string request_string = "GET /invalid HTTP/1.1\r\n"
                               "Host: localhost\r\n"
                               "\r\n";

  boost::asio::ip::tcp::socket client_socket(*io_context_);
  client_socket.connect(endpoint_);
  boost::asio::write(client_socket, boost::asio::buffer(request_string));

  io_context_->run_for(boost::asio::chrono::seconds(1));

  std::array<char, 1024> buffer;
  size_t bytes_received = client_socket.read_some(boost::asio::buffer(buffer));
  std::string actual_response(buffer.data(), bytes_received);
  EXPECT_TRUE(actual_response.find("HTTP/1.1 404 Not Found") != std::string::npos);
  EXPECT_TRUE(actual_response.find("Content-Length: 15") != std::string::npos);
  EXPECT_TRUE(actual_response.find("404 Not Found\r\n") != std::string::npos);
  EXPECT_TRUE(actual_response.find("Content-Type: text/plain") != std::string::npos);
}

TEST_F(SessionTest, HandlesBadRequestNoHostHeader) {
  std::string request_string = "GET /invalid HTTP/1.1\r\n"
                               "\r\n";

  boost::asio::ip::tcp::socket client_socket(*io_context_);
  client_socket.connect(endpoint_);
  boost::asio::write(client_socket, boost::asio::buffer(request_string));

  io_context_->run_for(boost::asio::chrono::seconds(1));

  std::array<char, 1024> buffer;
  size_t bytes_received = client_socket.read_some(boost::asio::buffer(buffer));
  std::string actual_response(buffer.data(), bytes_received);

  EXPECT_FALSE(actual_response.find("HTTP/1.1 400 Bad Request") != std::string::npos);
  EXPECT_FALSE(actual_response.find("Content-Length: 0") != std::string::npos);
}

TEST_F(SessionTest, HandlesGETRequest) {
  std::string request_string = "GET / HTTP/1.1\r\n"
                               "Host: localhost\r\n"
                               "User-Agent: test\r\n"
                               "Accept: */*\r\n"
                               "\r\n";

  boost::asio::ip::tcp::socket client_socket(*io_context_);
  client_socket.connect(endpoint_);
  boost::asio::write(client_socket, boost::asio::buffer(request_string));

  io_context_->run_for(boost::asio::chrono::seconds(1));

  std::array<char, 1024> buffer;
  size_t bytes_received = client_socket.read_some(boost::asio::buffer(buffer));
  std::string actual_response(buffer.data(), bytes_received);

  EXPECT_FALSE(actual_response.find("HTTP/1.1 200 OK") != std::string::npos);
  EXPECT_FALSE(actual_response.find("<html><body><h1>Hello, World!</h1></body></html>") != std::string::npos);
}
