#include "mock_filesystem.h"

#include "gtest/gtest.h"

TEST(MockFilesystemTest, Exists) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {{"1", "Content 1"}, {"2", "Content 2"}};
  MockFilesystem fs(fs_map, "mnt/crud");
  EXPECT_TRUE(fs.exists("mnt/crud/Entity"));
  EXPECT_TRUE(fs.exists("mnt/crud/Entity/1"));
  EXPECT_FALSE(fs.exists("mnt/crud/NotEntity"));
  EXPECT_FALSE(fs.exists("mnt/crud/Entity/3"));
}

TEST(MockFilesystemTest, IsDirectory) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {{"1", "Content 1"}, {"2", "Content 2"}};
  MockFilesystem fs(fs_map, "mnt/crud");
  EXPECT_TRUE(fs.is_directory("mnt/crud/Entity"));
  EXPECT_FALSE(fs.is_directory("mnt/crud/Entity/1"));
}

TEST(MockFilesystemTest, IsRegularFile) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {{"1", "Content 1"}, {"2", "Content 2"}};
  MockFilesystem fs(fs_map, "mnt/crud");
  EXPECT_TRUE(fs.is_regular_file("mnt/crud/Entity/1"));
  EXPECT_FALSE(fs.is_regular_file("mnt/crud/Entity"));
}

TEST(MockFilesystemTest, GetEntitiesInDir) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {{"1", "Content 1"}, {"2", "Content 2"}};
  MockFilesystem fs(fs_map, "mnt/crud");
  std::vector<std::string> entities = fs.get_entities_in_dir("mnt/crud/Entity");
  EXPECT_EQ(entities.size(), 2);
  EXPECT_EQ(entities[0], "1");
  EXPECT_EQ(entities[1], "2");
}

TEST(MockFilesystemTest, Remove) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {{"1", "Content 1"}, {"2", "Content 2"}};
  MockFilesystem fs(fs_map, "mnt/crud");
  fs.remove("mnt/crud/Entity/1");
  std::vector<std::string> entities = fs.get_entities_in_dir("mnt/crud/Entity");
  EXPECT_EQ(entities.size(), 1);
  EXPECT_EQ(entities[0], "2");
}

TEST(MockFilesystemTest, GetFileContents) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {{"1", "Content 1"}, {"2", "Content 2"}};
  MockFilesystem fs(fs_map, "mnt/crud");
  std::string contents = fs.get_file_contents("mnt/crud/Entity/1");
  EXPECT_EQ(contents, "Content 1");
}

TEST(MockFilesystemTest, WriteToFile) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  fs_map["Entity"] = {};
  MockFilesystem fs(fs_map, "mnt/crud");
  std::string path = "mnt/crud/Entity/1";
  std::string contents = "Content 1";
  fs.write_to_file(path, contents);
  EXPECT_EQ(fs.get_file_contents("mnt/crud/Entity/1"), "Content 1");
}

TEST(MockFilesystemTest, CreateDirectory) {
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem fs(fs_map, "mnt/crud");
  std::string dir = "mnt/crud/Entity";
  fs.create_directory(dir);
  EXPECT_TRUE(fs.exists("mnt/crud/Entity"));
}