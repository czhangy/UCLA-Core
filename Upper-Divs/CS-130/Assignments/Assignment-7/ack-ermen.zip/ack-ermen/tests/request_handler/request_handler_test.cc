#include "request_handler.h"

#include <fstream>
#include <iostream>

#include "crud_request_handler.h"
#include "echo_request_handler.h"
#include "gtest/gtest.h"
#include "mock_filesystem.h"
#include "static_file_request_handler.h"

using boost::asio::ip::tcp;

TEST(RequestHandlerTest, EchoHandlerSimple) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);

  req.method(http::verb::get);
  req.version(11);
  req.target("/echo");
  req.set(http::field::user_agent, "curl/7.81.0");

  std::string body = "GET /echo HTTP/1.1\r\nUser-Agent: curl/7.81.0\r\n\r\n";

  EchoRequestHandler handler;

  handler.handle_request(req, file_res);
  EXPECT_EQ(file_res.result(), http::status::ok);
  // std::cout << file_res << std::endl;
  EXPECT_EQ(file_res.body(), body);
}

TEST(RequestHandlerTest, StaticFileHandlerTxt) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);
  std::string static_path = "/static";
  std::string static_dir = "./public";

  req.method(http::verb::get);
  req.version(11);
  req.target("/static/test.txt");
  req.set(http::field::user_agent, "curl/7.81.0");

  StaticFileRequestHandler handler(static_path, static_dir);
  handler.handle_request(req, file_res);

  std::string test_body = "Hello\nHi\n3000\n";

  EXPECT_EQ(file_res.result(), http::status::ok);
  EXPECT_EQ(file_res.body(), "Hello\nHi\n3000\n");
}

TEST(RequestHandlerTest, StaticFileHandlerHtml) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);
  std::string static_path = "/static";
  std::string static_dir = "/public";

  req.method(http::verb::get);
  req.version(11);
  req.target("/static/test.html");
  req.set(http::field::user_agent, "curl/7.81.0");

  StaticFileRequestHandler handler(static_path, static_dir);
  handler.handle_request(req, file_res);

  std::string test_body = "";

  EXPECT_EQ(file_res.result(), http::status::ok);
  EXPECT_EQ(file_res.body(), test_body);
}

TEST(RequestHandlerTest, StaticFileHandlerJpg) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);
  std::string static_path = "/static";
  std::string static_dir = "/public";

  req.method(http::verb::get);
  req.version(11);
  req.target("/static/test.jpg");
  req.set(http::field::user_agent, "curl/7.81.0");

  StaticFileRequestHandler handler(static_path, static_dir);
  handler.handle_request(req, file_res);

  std::string test_body = "";

  EXPECT_EQ(file_res.result(), http::status::ok);
  EXPECT_EQ(file_res.body(), test_body);
}

TEST(RequestHandlerTest, StaticFileHandlerJson) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);
  std::string static_path = "/static";
  std::string static_dir = "/public";

  req.method(http::verb::get);
  req.version(11);
  req.target("/static/test.json");
  req.set(http::field::user_agent, "curl/7.81.0");

  StaticFileRequestHandler handler(static_path, static_dir);
  handler.handle_request(req, file_res);

  std::string test_body = "";

  EXPECT_EQ(file_res.result(), http::status::ok);
  EXPECT_EQ(file_res.body(), test_body);
}

TEST(RequestHandlerTest, StaticFileHandlerZip) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);
  std::string static_path = "/static";
  std::string static_dir = "/public";

  req.method(http::verb::get);
  req.version(11);
  req.target("/static/test.zip");
  req.set(http::field::user_agent, "curl/7.81.0");

  StaticFileRequestHandler handler(static_path, static_dir);
  handler.handle_request(req, file_res);

  std::string test_body = "";

  EXPECT_EQ(file_res.result(), http::status::ok);
  EXPECT_EQ(file_res.body(), test_body);
}

TEST(RequestHandlerTest, StaticFileHandlerBad) {
  http::request<http::string_body> req;
  http::response<http::string_body> file_res;
  boost::asio::io_service io_service;
  tcp::socket socket(io_service);
  std::string static_endpoint = "/static";
  std::string serving_dir = "./public";

  req.method(http::verb::get);
  req.version(11);
  req.target("/static/bad");
  req.set(http::field::user_agent, "curl/7.81.0");

  StaticFileRequestHandler handler(static_endpoint, serving_dir);

  EXPECT_EQ(handler.handle_request(req, file_res), http::status::not_found);
}

TEST(RequestHandlerTest, CRUDRequestHandlerUnimplemented) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file = {"1", "{\"content\": \"1\"}"};
  fs_map["Entity"] = {file};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::connect);
  req.version(11);
  req.target("/api");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::not_implemented);
}

TEST(RequestHandlerTest, CRUDRequestHandlerRetrieveSuccess) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file = {"1", "{\"content\": \"1\"}"};
  fs_map["Entity"] = {file};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::get);
  req.version(11);
  req.target("/api/Entity/1");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::ok);
  EXPECT_EQ(res.body(), "{\"content\": \"1\"}\r\n");
}

TEST(RequestHandlerTest, CRUDRequestHandlerRetrieveFailure) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file = {"1", "{\"content\": \"1\"}"};
  fs_map["Entity"] = {file};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::get);
  req.version(11);
  req.target("/api/Entity/2");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::not_found);
}

TEST(RequestHandlerTest, CRUDRequestHandlerListSuccess) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file_1 = {"1", "{\"content\": \"1\"}"};
  MockFilesystem::MockFile file_2 = {"2", "{\"content\": \"2\"}"};
  fs_map["Entity"] = {file_1, file_2};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::get);
  req.version(11);
  req.target("/api/Entity");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::ok);
  EXPECT_EQ(res.body(), "{\"valid_ids\":[\"1\",\"2\"]}\r\n");
}

TEST(RequestHandlerTest, CRUDRequestHandlerListFailure) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file_1 = {"1", "{\"content\": \"1\"}"};
  MockFilesystem::MockFile file_2 = {"2", "{\"content\": \"2\"}"};
  fs_map["Entity"] = {file_1, file_2};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::get);
  req.version(11);
  req.target("/api/NotEntity");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::not_found);
}

TEST(RequestHandlerTest, CRUDRequestHandlerCreateSuccess) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::post);
  req.version(11);
  req.target("/api/Entity");
  req.set(http::field::user_agent, "curl/7.81.0");
  req.body() = "{\"content\": \"1\"}";

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::created);
  EXPECT_EQ(res.body(), "{\"id\": 1}");
}

TEST(RequestHandlerTest, CRUDRequestHandlerDeleteSuccess) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file_1 = {"1", "{\"content\": \"1\"}"};
  MockFilesystem::MockFile file_2 = {"2", "{\"content\": \"2\"}"};
  fs_map["Entity"] = {file_1, file_2};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::delete_);
  req.version(11);
  req.target("/api/Entity/1");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::ok);
  EXPECT_EQ(res.body(), "Delete successful!\r\n");
}

TEST(RequestHandlerTest, CRUDRequestHandlerDeleteFailure) {
  http::request<http::string_body> req;
  http::response<http::string_body> res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file_1 = {"1", "{\"content\": \"1\"}"};
  MockFilesystem::MockFile file_2 = {"2", "{\"content\": \"2\"}"};
  fs_map["Entity"] = {file_1, file_2};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));

  req.method(http::verb::delete_);
  req.version(11);
  req.target("/api/Entity/3");
  req.set(http::field::user_agent, "curl/7.81.0");

  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  http::status status = handler.handle_request(req, res);

  EXPECT_EQ(status, http::status::not_found);
}

TEST(RequestHandlerTest, CRUDRequestHandlerUpdateSuccess) {
  http::request<http::string_body> update_req;
  http::response<http::string_body> update_res;
  http::request<http::string_body> retrieve_req;
  http::response<http::string_body> retrieve_res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file = {"1", "{\"content\": \"1\"}"};
  fs_map["Entity"] = {file};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));
  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  std::string file_target = "/api/Entity/1";
  std::string new_content = "{\"content\": \"27\"}";
  update_req.method(http::verb::put);
  update_req.version(11);
  update_req.target(file_target);
  update_req.set(http::field::user_agent, "curl/7.81.0");
  update_req.body() = new_content;
  update_req.prepare_payload();
  http::status update_status = handler.handle_request(update_req, update_res);
  EXPECT_EQ(update_status, http::status::ok);
  retrieve_req.method(http::verb::get);
  retrieve_req.version(11);
  retrieve_req.target(file_target);
  retrieve_req.set(http::field::user_agent, "curl/7.81.0");
  http::status retrieve_status =
      handler.handle_request(retrieve_req, retrieve_res);
  EXPECT_EQ(retrieve_status, http::status::ok);
  EXPECT_EQ(retrieve_res.body(), new_content + "\r\n");
}

TEST(RequestHandlerTest, CRUDRequestHandlerUpdateFailure) {
  http::request<http::string_body> update_req;
  http::response<http::string_body> update_res;
  http::request<http::string_body> retrieve_req;
  http::response<http::string_body> retrieve_res;
  std::string crud_endpoint = "/api";
  std::string data_path = "mnt/crud";
  std::unordered_map<std::string, std::vector<MockFilesystem::MockFile>> fs_map;
  MockFilesystem::MockFile file = {"1", "{\"content\": \"1\"}"};
  fs_map["Entity"] = {file};
  std::unique_ptr<MockFilesystem> fs(new MockFilesystem(fs_map, data_path));
  CRUDRequestHandler handler(crud_endpoint, data_path, std::move(fs));
  std::string file_target = "/api/Entity/2";
  std::string new_content = "{\"content\": \"27\"}";
  update_req.method(http::verb::put);
  update_req.version(11);
  update_req.target(file_target);
  update_req.set(http::field::user_agent, "curl/7.81.0");
  update_req.body() = new_content;
  update_req.prepare_payload();
  http::status update_status = handler.handle_request(update_req, update_res);
  EXPECT_EQ(update_status, http::status::not_found);
}
