#include "config_parser.h"

#include <fstream>

#include "gtest/gtest.h"

const int INVALID_PORT_NUM = -1;
const int PORT_NUM = 3000;

// Create Test Fixture class
class ParserTest : public ::testing::Test {
 protected:
  NginxConfigParser parser;
  NginxConfig out_config;
};

TEST_F(ParserTest, SimpleConfig) {
  bool success = parser.Parse("example_config", &out_config);

  EXPECT_TRUE(success);
}

TEST_F(ParserTest, WorkingServer) {
  bool success = parser.Parse("minimal_config", &out_config);

  EXPECT_TRUE(success);
}

TEST_F(ParserTest, ExtraCurlyBrace) {
  bool failure = parser.Parse("extra_curly_brace", &out_config);

  EXPECT_FALSE(failure);
}

TEST_F(ParserTest, MissingCurlyBrace) {
  bool failure = parser.Parse("missing_curly_brace", &out_config);

  EXPECT_FALSE(failure);
}

TEST_F(ParserTest, ExtraCurlyBraceMiddle) {
  bool failure = parser.Parse("extra_curly_brace_middle", &out_config);

  EXPECT_FALSE(failure);
}

TEST_F(ParserTest, EmptyConfig) {
  bool success = parser.Parse("empty_config", &out_config);

  EXPECT_TRUE(success);
}

TEST_F(ParserTest, NoWhiteSpaceAfterQuote) {
  bool failure = parser.Parse("no_whitespace_after_quote", &out_config);

  EXPECT_FALSE(failure);
}

TEST_F(ParserTest, EscapeCharacterDoubleQuoteInDoubleQuote) {
  bool success = parser.Parse("escape_character_double_quote_in_double_quote",
                              &out_config);

  EXPECT_TRUE(success);
}

TEST_F(ParserTest, EscapeCharacterNewline) {
  bool success = parser.Parse("escape_character_newline", &out_config);

  EXPECT_TRUE(success);
}

TEST_F(ParserTest, EscapeCharacterCombination) {
  bool success = parser.Parse("escape_character_combination", &out_config);

  EXPECT_TRUE(success);
}

TEST_F(ParserTest, GetPortFromConfig) {
  bool success = parser.Parse("example_config", &out_config);

  EXPECT_TRUE(success);
  EXPECT_EQ(PORT_NUM, out_config.GetPort());
}

TEST_F(ParserTest, GetInvalidPortFromConfig) {
  bool success = parser.Parse("invalid_port_config", &out_config);

  EXPECT_TRUE(success);
  EXPECT_EQ(INVALID_PORT_NUM, out_config.GetPort());
}

TEST_F(ParserTest, GetNegativePortFromConfig) {
  bool success = parser.Parse("negative_port_config", &out_config);

  EXPECT_TRUE(success);
  EXPECT_EQ(INVALID_PORT_NUM, out_config.GetPort());
}

TEST_F(ParserTest, GetPortFromEmptyConfig) {
  bool success = parser.Parse("empty_config", &out_config);

  EXPECT_TRUE(success);
  EXPECT_EQ(INVALID_PORT_NUM, out_config.GetPort());
}

TEST_F(ParserTest, GetLocationConfigsFromConfig) {
  bool success = parser.Parse("multiple_path_config", &out_config);
  EXPECT_TRUE(success);

  NginxLocationConfig expected_config1;
  expected_config1.path = "/static";
  expected_config1.handler = "StaticHandler";
  expected_config1.options.insert(std::make_pair("root", "/public"));

  NginxLocationConfig expected_config2;
  expected_config2.path = "/new_static";
  expected_config2.handler = "StaticHandler";
  expected_config2.options.insert(std::make_pair("root", "/new_public"));

  NginxLocationConfig expected_config3;
  expected_config3.path = "/echo";
  expected_config3.handler = "EchoHandler";

  NginxLocationConfig expected_config4;
  expected_config4.path = "/new_echo";
  expected_config4.handler = "EchoHandler";

  std::vector<NginxLocationConfig> actual_configs =
      out_config.GetLocationConfigs();

  ASSERT_EQ(actual_configs.size(), 4);
  EXPECT_EQ(actual_configs[0].path, expected_config1.path);
  EXPECT_EQ(actual_configs[0].handler, expected_config1.handler);
  EXPECT_EQ(actual_configs[0].options, expected_config1.options);

  EXPECT_EQ(actual_configs[1].path, expected_config2.path);
  EXPECT_EQ(actual_configs[1].handler, expected_config2.handler);
  EXPECT_EQ(actual_configs[1].options, expected_config2.options);

  EXPECT_EQ(actual_configs[2].path, expected_config3.path);
  EXPECT_EQ(actual_configs[2].handler, expected_config3.handler);
  EXPECT_EQ(actual_configs[2].options, expected_config3.options);

  EXPECT_EQ(actual_configs[3].path, expected_config4.path);
  EXPECT_EQ(actual_configs[3].handler, expected_config4.handler);
  EXPECT_EQ(actual_configs[3].options, expected_config4.options);
}

TEST_F(ParserTest, CommentOnlyConfigWithWhitespace) {
  bool success = parser.Parse("comment_only_config", &out_config);

  EXPECT_TRUE(success);
  EXPECT_EQ(INVALID_PORT_NUM, out_config.GetPort());
}

TEST_F(ParserTest, VerifyConfigToString) {
  bool success = parser.Parse("example_config", &out_config);
  std::string config_str = out_config.ToString(0);

  // Read the expected output from the file
  std::ifstream file("example_config_parsed_output");
  std::stringstream config_stream;
  config_stream << file.rdbuf();
  file.close();
  std::string expected_parsed_output = config_stream.str();

  // Remove all whitespace and newlines from both strings
  config_str.erase(std::remove(config_str.begin(), config_str.end(), ' '), config_str.end());
  config_str.erase(std::remove(config_str.begin(), config_str.end(), '\n'), config_str.end());
  expected_parsed_output.erase(std::remove(expected_parsed_output.begin(), expected_parsed_output.end(), ' '), expected_parsed_output.end());
  expected_parsed_output.erase(std::remove(expected_parsed_output.begin(), expected_parsed_output.end(), '\n'), expected_parsed_output.end());

  EXPECT_TRUE(success);
  EXPECT_EQ(config_str, expected_parsed_output);
}

TEST_F(ParserTest, VerifyBadConfig) {
  bool failure = parser.Parse("unknown_config", &out_config);

  EXPECT_FALSE(failure);
}

TEST_F(ParserTest, UnterminatedString) {
  bool failure = parser.Parse("unterminated_string", &out_config);
  EXPECT_FALSE(failure);
}

TEST_F(ParserTest, UnknownToken) {
  bool success = parser.Parse("unknown_token", &out_config);
  EXPECT_TRUE(success);
}

TEST_F(ParserTest, CommentToken) {
  bool success = parser.Parse("comment_token", &out_config);
  EXPECT_TRUE(success);
}
