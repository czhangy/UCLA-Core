
#include "web_server_runner.h"

#include <signal.h>
#include <unistd.h>

#include <chrono>
#include <cstdlib>
#include <future>
#include <iostream>
#include <thread>

#include "config_parser.h"
#include "gtest/gtest.h"
#include "server.h"

using boost::asio::ip::tcp;

TEST(WebServerRunnerTest, MissingConfigFile) {
  char* argv[] = {"./server"};
  web_server_runner runner(1, argv);
  EXPECT_EQ(runner.run(), 1);
}

TEST(WebServerRunnerTest, NonExistentConfigFile) {
  char* argv[] = {"./server", "UNKNOWN_FILE"};
  web_server_runner runner(2, argv);
  EXPECT_EQ(runner.run(), 1);
}

TEST(WebServerRunnerTest, InvalidConfigFile) {
  char* argv[] = {"./server", "extra_curly_brace"};
  web_server_runner runner(2, argv);
  EXPECT_EQ(runner.run(), 1);
}

TEST(WebServerRunnerTest, ValidConfigFile) {
  char* argv[] = {"./server", "example_config"};
  web_server_runner runner(2, argv);

  // EXPECT_EQ(runner.run(), 0);
  std::thread t([&runner]() { runner.run(); });

  // Wait for the server to start listening on the port
  usleep(100 * 1000);

  // Send a signal to the server to shut down
  // Note: Implement the shutdown() method in your web_server_runner class
  runner.shutdown();

  // Wait for the server to exit or timeout after 10 seconds
  EXPECT_TRUE(t.joinable());
  std::chrono::time_point<std::chrono::system_clock> start =
      std::chrono::system_clock::now();
  std::chrono::duration<double> elapsed_seconds;
  while (t.joinable() && elapsed_seconds.count() < 10.0) {
    t.join();
    elapsed_seconds = std::chrono::system_clock::now() - start;
  }
  EXPECT_FALSE(t.joinable());
  EXPECT_EXIT(t.detach(), ::testing::ExitedWithCode(0), "");
}

TEST(WebServerRunnerTest, InvalidPortFile) {
  char* argv[] = {"./server", "invalid_port_config"};
  web_server_runner runner(2, argv);
  EXPECT_EQ(runner.run(), 1);
}
