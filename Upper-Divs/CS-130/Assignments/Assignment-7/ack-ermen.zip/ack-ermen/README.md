## About

Welcome to `ack-ermen`, our web server that our amazing team (@jtay20, @rajpiskala, @mntxca, @sidredpat) is building. Our web server as it is supports two main endpoins, `/echo`, which will echo your request and `/static` which will serve a static file.

Here's some of the features you can find in your project:
**Echoing Requests:**
The echo endpoint is accessible at `/echo`:
![Caption](https://i.imgur.com/s07Nst3.png)

**Static File-Serving:**
The static endpoint is accessible at `/static/{file.ext}`:

![Caption](https://i.imgur.com/7ff6UJv.png)

![Caption](https://i.imgur.com/W9UgmVp.png)

Currently, our web server serves the following files out-of-the-box for the `/static` endpoint: 
- test.txt
- test.zip
- test.json
- test.jpg
- test.jpeg
- test.html

Upon each request, the server will log a message when it's run locally:
![Caption](https://i.imgur.com/qVivdFF.png)

## Getting Started
### Prerequisites
Please ensure that you have the proper SSH keys and the repository permissions set up.
- [Set up SSH Access](https://www.cs130.org/guides/gerrit/#ssh-access)
- [Project Protocol]()

Additionally, you may find the instructions from previous assignments helpful:
- [Assignment 1](https://www.cs130.org/assignments/1/)
- [Assignment 2](https://www.cs130.org/assignments/2/)

### Installation
Clone the `ack-ermen` repository - we will do all our programming here
```
git clone ssh://code.cs130.org:29418/ack-ermen
```

### Build
The following commands will build the project in the `build` directory. The `make test` command will run the unit and integration tests.
From the directory where you cloned the repository, run the following commands:
```sh
cd ack-ermen
mkdir build
cmake ..
make
```

### Run
The server executable will be in the `build/bin` directory. It is used to run the server.

The server executable requires one argument, where that argument is a configuration file. The configuration file is a text file that contains the following information:
- The port number to run the server on
- The path of the webserver on the ip address to serve on
- The directory to serve files from

Ensure that you are in the ack-ermen folder, then run the following command:
```sh
build/bin/server conf/example.conf
```

### Test
To run the tests, ensure that you are in the ack-ermen folder, then run the following commands:
```sh
mkdir build # if it does not already exist
cmake ..
make
make test
```

To check the test coverage, ensure that you are in the ack-ermen folder, then run the following commands:
```sh
mkdir build_coverage # if it does not exist
cd build_coverage
cmake -DCMAKE_BUILD_TYPE=Coverage ..
make coverage
```
Note: if it is not the first time running the tests or checking the test coverage, then skip the mkdir command.

### Cleanup
To clear the build folder, run the following command while in the ack-ermen folder to remove it:
```sh
rm -rf build
```

To clear the build_coverage folder, run the following command while in the ack-ermen folder to remove it:
```sh
rm -rf build_coverage
```

In order to reset all other changes to the latest branch, feel free to use this command
```sh
git reset --hard origin/main
```
**Important note:** origin refers to the remote for ack-ermen

## Project Structure
Here is the project structure:
```sh
/conf     # Config(s) that we run the server from. example.conf is what prod runs on
/docker   # Docker configuration - e.g. for Docker builds performed on Google Cloud build
/include  # All project header files
/log      # Log files from all server runs
/public   # Static files that the server should serve from
/src      # All source (.cc) files
/tests    # All tests and auxiliary files (e.g. .txt or .html files) reside here
CMakeLists.txt # Instructions for CMake
.gitignore     # Files that should be ignored in development
.dockerignore  # Files ignored by Docker
```
### Public Folder(s)
- The public folder is used to store the files that the server serves
- Currently holds files of many types, such as test.txt, test.html, test.jpeg, test.zip, etc.

### Source Structure
- All header *.h files are in the `/include` folder
- All source *.cc files are in the `/src` folder

### Test Structure
- All test files are in the `/tests` folder, which are further divided into many folders
- Tests are divided within 5 folders: config_parser, dispatcher, integration, request_handler, session
- Each test folder mentioned except integration has a *.cc file that runs the tests using the gtest library
- Many of the test folders include a public folder that is used to store the files that the tests serve to themeselves
- Many of the test folders include a *.conf config file to store the configuration for running the server during the tests
- The integration folder has two integration tests: echo_integration_test.sh and static_file_integration.sh instead of a *.cc file

## Adding Request Handlers
### Summary of Steps
Adding a new request handlers must complete following steps:
1. Have a header file with the class definition that goes into the `include` folder
2. A source file with the implementation that goes into the `src` folder
3. Update the `CMakeLists.txt` to include this into your executable in compiling this program
4. Update the `request_handler_factory.cc` file to create the appropriate `RequestHandler` based on the static handle type. This essentially registers the request handler with the factory

Please refer to the Build, Run, and Test sections when doing this to verify that your change was made successfully. If the request handler was written correctly, then the implementation should automatically run given the correct handler is invoked for the route.

### Code Examples
We will now explore an example request handler and how we built it. Here, we will do a case study of the `NotFoundRequestHandler` which can serve as an example of our minimal request handler. For context, the `NotFoundRequestHandler` is our project's 404 file not found handler.

Note: all our request handlers use the Beast library within Boost. Documentation for all of the ode that we implement can be found in the [Boost Beast Examples](https://www.boost.org/doc/libs/1_67_0/libs/beast/doc/html/beast/examples.html) and the [GitHub for Boost Beast](https://github.com/boostorg/beast).

Here is the header file for the `NotFoundRequestHandler`: 
```cpp
// Must derive from the RequestHandler parent class
class NotFoundRequestHandler : public RequestHandler {
 public:
  // Empty constructor - define your own if needed
  http::status handle_request(const http::request<http::string_body>& req,
                              http::response<http::string_body>& res);
};
```

In our project, our convention is to put the handler name first, then suffix it with RequestHandler. For naming classes, we use PascalCase, while we use snake_case for the file names.

All request handlers must inherit from the `RequestHandler` interface. They must implement the same `handle_request` function which takes in a request with a string body and a response of string body, and returns an HTTP status request. This is **required** for every request handler that must be defined.

If you would like to construct this request handler with any arguments, then define a public constructor. Currently, this request handler has an empty constructor as it requires no parameters.  Additionally, you may define any other methods or fields (private or public) to supplement this.

For context, this is the `RequestHandler` interface that all request handlers must be derived from:
```c++
class RequestHandler {
 public:
  RequestHandler();
  virtual http::status handle_request(
      const http::request<http::string_body>& req,
      http::response<http::string_body>& res) = 0;
};
```
Notice that this `handle_request` function is required and is the same as the one for the `NotFoundRequestHandler`. 

Now we can explore how a request handler is then implemented:
```cpp
// Parameters: request and response
// Return value: an HTTP status code
http::status NotFoundRequestHandler::handle_request(
    const http::request<http::string_body>& req,
    http::response<http::string_body>& res) {
  // All data being returned must be converted to an std::string beforehand
  std::string not_found = "404 Not Found\r\n";
  res.body() = not_found;

  // Sets the field on what server we are using -- we are using Beast similar to one would set this field for Apache or Nginx
  res.set(http::field::server, BOOST_BEAST_VERSION_STRING);

  // Update this for the type of content you're serving. For example, JSON would use the MIME type "application/json" and JPEG would use "image/jpeg"
  res.set(http::field::content_type, "text/plain");

  // Decide whether or not to keep the connection going
  res.keep_alive(req.keep_alive());

  // Set the status code to return -- see Boost HTTP documentation for this
  res.result(http::status::not_found);

  // Line required for every response object
  res.prepare_payload();

  // Return the HTTP status of this operation
  return http::status::not_found;
}
```
The code above has inline comments to explain what is done in this minimal handler line-by-line. All request handlers must implement the `handle_request` function and the code within must follow this format.

The main items that deviate from this structure are:
1. Logic for determining what the string body of the response should be
2. Logic for determining what the status should be
3. Logic for determining the MIME type (in `http::field::content_type`)
4. Adding any more HTTP header fields

## Conclusion
We hope you liked our README. Hope it was useful and have fun developing on our codebase!