#include <iostream>
#include <cstring>
#include <string>

using namespace std;

// Make sure input is valid
bool isValid(int argc, char *argv[]) {
    bool valid = true;
    if (argc < 3) {
        cout << "Missing inputs" << endl;
        valid = false;
    } else if (argc > 3) {
        cout << "Too many inputs" << endl;
        valid = false;
    } else if (strlen(argv[1]) != 2 || argv[1][0] != '-') {
        cout << "Invalid flag: " << argv[1] << endl;
        valid = false;
    } else if (strlen(argv[2]) > 45) {
        cout << "Bitstring too long" << endl;
        valid = false;
    } else {
        for (int i = 0; i < strlen(argv[2]); i++) {
            if (argv[2][i] != '0' && argv[2][i] != '1') {
                cout << "Invalid bitstring" << endl;
                valid = false;
                break;
            }
        }
    }
    return valid;
}

// Helper function for modulo 2 division, returns the remainder
string mod2Divide(string dividend, const string& divisor) {
    int m = dividend.size(), n = divisor.size();
    for (int i = 0; i < m - n + 1; i++) {
        // Shift when 0
        if (dividend[i] == '0')
            continue;
        // XOR with remainder
        for (int j = 0; j < n; j++) {
            bool x = dividend[i + j] != divisor[j] && (dividend[i + j] == '1'
                        || divisor[j] == '1');
            dividend[i + j] = x ? '1' : '0';
        }
    }
    return dividend;
}

// Handle -c flag
string generateCRC(const string& message, const string& generator) {
    // Shift message by r - 1
    int m = message.size(), r = generator.size();
    string shiftedMsg = message + string(r - 1, '0');
    string remainder = mod2Divide(shiftedMsg, generator);
    // Collect CRC from remainder
    string crc = remainder.substr(m);
    return message + crc;
}

// Handle -v flag
bool validateMessage(const string& crcMessage, const string& generator) {
    int len = crcMessage.size(), r = generator.size();
    string message = crcMessage.substr(0, len - r + 1);
    return crcMessage == generateCRC(message, generator);
}

// Handle -f flag
void calculate4BitErrors(const string& message, const string& generator) {
    string crcMessage = generateCRC(message, generator);
    int len = crcMessage.size();
    for (int i = 0; i < len - 3; i++) {
        string error = crcMessage;
        error[i] = error[i] == '0' ? '1' : '0';
        for (int j = i + 1; j < len - 2; j++) {
            error[j] = error[j] == '0' ? '1' : '0';
            for (int k = j + 1; k < len - 1; k++) {
                error[k] = error[k] == '0' ? '1' : '0';
                for (int m = k + 1; m < len; m++) {
                    error[m] = error[m] == '0' ? '1' : '0';
                    if (validateMessage(error, generator)) {
                        cout << error << endl;
                    }
                }
            }
        }
    }
}

// Handle -t and -p flags
int calculateNum5BitErrors(const string& message, const string& generator) {
    string crcMessage = generateCRC(message, generator);
    int len = crcMessage.size();
    int count = 0;
    for (int i = 0; i < len - 4; i++) {
        string error = crcMessage;
        error[i] = error[i] == '0' ? '1' : '0';
        for (int j = i + 1; j < len - 3; j++) {
            error[j] = error[j] == '0' ? '1' : '0';
            for (int k = j + 1; k < len - 2; k++) {
                error[k] = error[k] == '0' ? '1' : '0';
                for (int m = k + 1; m < len - 1; m++) {
                    error[m] = error[m] == '0' ? '1' : '0';
                    for (int n = m + 1; n < len; n++) {
                        if (validateMessage(error, generator)) {
                            count++;
                        }
                    }
                }
            }
        }
    }
    return count;
}

int main(int argc, char *argv[]) {
    // Parse input for correct format
    if (!isValid(argc, argv)) {
        return 1;
    }
    // Define generators
    string cvGenerator = "10001000010100001";
    string ftGenerator = "11001000000000101";
    string pGenerator = "11000000000000101";
    // Read flag
    char flag = argv[1][1];
    string message = argv[2];
    // Controller
    switch (flag) {
        case 'c': {
            cout << generateCRC(message, cvGenerator) << endl;
            break;
        }
        case 'v': {
            cout << validateMessage(message, cvGenerator) << endl;
            break;
        }
        case 'f': {
            calculate4BitErrors(message, ftGenerator);
            break;
        }
        case 't': {
            cout << calculateNum5BitErrors(message, ftGenerator) << endl;
            break;
        }
        // Should always output 0
        case 'p': {
            cout << calculateNum5BitErrors(message, pGenerator) << endl;
            break;
        }
        default: {
            cout << "Invalid flag: " << argv[1] << endl;
            return 1;
        }
    }
    return 0;
}