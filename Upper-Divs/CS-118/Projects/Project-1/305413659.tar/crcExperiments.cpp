#include <iostream>
#include <cstring>
#include <string>
#include <cassert>
#include <vector>

using namespace std;

// Make sure input is valid
bool isValid(int argc, char *argv[]) {
    bool valid = true;
    if (argc < 3) {
        cout << "Missing inputs" << endl;
        valid = false;
    } else if (argc > 3) {
        cout << "Too many inputs" << endl;
        valid = false;
    } else if (strlen(argv[1]) != 2 || argv[1][0] != '-') {
        cout << "Invalid flag: " << argv[1] << endl;
        valid = false;
    } else if (strlen(argv[2]) > 45) {
        cout << "Bitstring too long" << endl;
        valid = false;
    } else {
        for (int i = 0; i < strlen(argv[2]); i++) {
            if (argv[2][i] != '0' && argv[2][i] != '1') {
                cout << "Invalid bitstring" << endl;
                valid = false;
                break;
            }
        }
    }
    return valid;
}

// Helper function for modulo 2 division, returns the remainder
string mod2Divide(string dividend, const string& divisor) {
    int m = dividend.size(), n = divisor.size();
    for (int i = 0; i < m - n + 1; i++) {
        // Shift when 0
        if (dividend[i] == '0')
            continue;
        // XOR with remainder
        for (int j = 0; j < n; j++) {
            bool x = dividend[i + j] != divisor[j] && (dividend[i + j] == '1'
                        || divisor[j] == '1');
            dividend[i + j] = x ? '1' : '0';
        }
    }
    return dividend;
}

// Helper function to flip a bit
char flipBit(char bit) {
    return bit == '0' ? '1' : '0';
}

// Handle -c flag
string generateCRC(const string& message, const string& generator) {
    // Shift message by r - 1
    int m = message.size(), r = generator.size();
    string shiftedMsg = message + string(r - 1, '0');
    string remainder = mod2Divide(shiftedMsg, generator);
    // Collect CRC from remainder
    string crc = remainder.substr(m);
    return message + crc;
}

// Handle -v flag
bool validateMessage(const string& crcMessage, const string& generator) {
    int len = crcMessage.size(), r = generator.size();
    string message = crcMessage.substr(0, len - r + 1);
    return crcMessage == generateCRC(message, generator);
}

// Handle -f flag
vector<string> calculate4BitErrors(const string& message, const string& generator) {
    string crcMessage = generateCRC(message, generator);
    int len = crcMessage.size();
    vector<string> errors;
    for (int i = 0; i < len - 3; i++) {
        string error = crcMessage;
        error[i] = flipBit(error[i]);
        for (int j = i + 1; j < len - 2; j++) {
            error[j] = flipBit(error[j]);
            for (int k = j + 1; k < len - 1; k++) {
                error[k] = flipBit(error[k]);
                for (int m = k + 1; m < len; m++) {
                    error[m] = flipBit(error[m]);
                    if (validateMessage(error, generator)) {
                        errors.push_back(error);
                    }
                    error[m] = flipBit(error[m]);
                }
                error[k] = flipBit(error[k]);
            }
            error[j] = flipBit(error[j]);
        }
        error[i] = flipBit(error[i]);
    }
    return errors;
}

// Handle -t and -p flags
int calculateNum5BitErrors(const string& message, const string& generator) {
    string crcMessage = generateCRC(message, generator);
    int len = crcMessage.size();
    int count = 0;
    for (int i = 0; i < len - 4; i++) {
        string error = crcMessage;
        error[i] = flipBit(error[i]);
        for (int j = i + 1; j < len - 3; j++) {
            error[j] = flipBit(error[j]);
            for (int k = j + 1; k < len - 2; k++) {
                error[k] = flipBit(error[k]);
                for (int m = k + 1; m < len - 1; m++) {
                    error[m] = flipBit(error[m]);
                    for (int n = m + 1; n < len; n++) {
                        error[n] = flipBit(error[n]);
                        if (validateMessage(error, generator)) {
                            count++;
                        }
                        error[n] = flipBit(error[n]);
                    }
                    error[m] = flipBit(error[m]);
                }
                error[k] = flipBit(error[k]);
            }
            error[j] = flipBit(error[j]);
        }
        error[i] = flipBit(error[i]);
    }
    return count;
}

void runTests() {
    // Define messages
    string cMessage = "1010101101010101010101010101010";
    string vMessage = "10101011010101010101010101010100001100101101000";
    string fMessage = "1010101101010101010101010101010";
    string tMessage = "1010101011010";
    string pMessage = "1010101011010";
    // Define generators
    string cvGenerator = "10001000010100001";
    string ftGenerator = "11001000000000101";
    string pGenerator = "11000000000000101";
    // Define expected outputs
    string cOutput = "10101011010101010101010101010100001100101101000";
    int vOutput = 1;
    vector<string> fOutput = {
        "00101011010101000101010101010101001111101101010",
        "11101011010101011101010101010101001100101110010",
        "10001011010101010001010101010101001101001111110",
        "10111011010101010111010101010101001101111111000",
        "10100011010101010100010101010101001101100111011"
    };
    int tOutput = 13;
    int pOutput = 0;
    // Assertions
    assert(generateCRC(cMessage, cvGenerator) == cOutput);
    assert(validateMessage(vMessage, cvGenerator) == vOutput);
    assert(calculate4BitErrors(fMessage, ftGenerator) == fOutput);
    assert(calculateNum5BitErrors(tMessage, ftGenerator) == tOutput);
    assert(calculateNum5BitErrors(pMessage, pGenerator) == pOutput);
    cout << "All tests passed!" << endl;
}

int main(int argc, char *argv[]) {
    // Parse input for correct format
    if (!isValid(argc, argv)) {
        return 1;
    }
    // Define generators
    string cvGenerator = "10001000010100001";
    string ftGenerator = "11001000000000101";
    string pGenerator = "11000000000000101";
    // Read flag
    char flag = argv[1][1];
    string message = argv[2];
    // Controller
    switch (flag) {
        case 'c': {
            cout << generateCRC(message, cvGenerator) << endl;
            break;
        }
        case 'v': {
            cout << validateMessage(message, cvGenerator) << endl;
            break;
        }
        case 'f': {
            vector<string> errors = calculate4BitErrors(message, ftGenerator);
            for (string& error : errors) {
                cout << error << endl;
            }
            break;
        }
        case 't': {
            cout << calculateNum5BitErrors(message, ftGenerator) << endl;
            break;
        }
        // Should always output 0
        case 'p': {
            cout << calculateNum5BitErrors(message, pGenerator) << endl;
            break;
        }
        // Test cases
        // case 'x': {
        //     runTests();
        //     break;
        // }
        default: {
            cout << "Invalid flag: " << argv[1] << endl;
            return 1;
        }
    }
    return 0;
}
