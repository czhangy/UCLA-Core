/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 2017 Alexander Afanasyev
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of
 * the GNU General Public License as published by the Free Software Foundation, either version
 * 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 */

#include "routing-table.hpp"
#include "core/utils.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>

#include <iostream>

namespace simple_router {

/*
    Calculate the prefix len. of a given mask
*/
uint32_t calcPrefixLen(uint32_t mask) {
    // Count the number of 0s at the end of the IP
    uint32_t numZeroes = 0;
    // Convert mask to host endian
    mask = htonl(mask);
    // Iterate bit-by-bit over mask until a 1 is reached, or the end of the mask
    while ((mask & 0b1) == 0b0 && numZeroes < 32) {
        mask >>= 1;
        numZeroes++;
    }
    // Subtract number of 0s from mask size to get number of 1s (prefix)
    return 32 - numZeroes;
}

/*
    Find the entry with the longest prefix match
    - Iterate over each RoutingTableEntry
    - Mask both IPs
    - Check if masked IPs are equal
    - If they are, check if the prefix len. is best so far
    - If current entry is BSF, remember entry and len.
*/
RoutingTableEntry RoutingTable::lookup(uint32_t ip) const {
    std::cerr << "Calculating longest prefix for " + ipToString(ip) + "..." << std::endl;
    // Track BSF
    RoutingTableEntry lpm;
    int longestPrefixLen = -1;
    // Iterate over RoutingTableEntries
    for (auto& entry : m_entries) {
        // Apply mask to IPs
        uint32_t maskedEntry = entry.dest & entry.mask;
        uint32_t maskedInput = ip & entry.mask;
        // Check if prefixes match
        if (maskedEntry == maskedInput) {
            // Compute the length of the prefix
            int prefixLen = calcPrefixLen(entry.mask);
            // If this prefix len. is BSF, save entry + len.
            if (prefixLen > longestPrefixLen) {
                lpm = entry;
                longestPrefixLen = prefixLen;
            }
        }
    }
    std::cerr << "Longest prefix is " + ipToString(lpm.dest & lpm.mask) + "/" + std::to_string(longestPrefixLen) << std::endl;
    return lpm;
}
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

// You should not need to touch the rest of this code.

bool
RoutingTable::load(const std::string& file)
{
  fprintf(stderr,
              "Loading Routing Table from %s\n",
              file.c_str());

  FILE* fp;
  char  line[BUFSIZ];
  char  dest[32];
  char  gw[32];
  char  mask[32];
  char  iface[32];
  struct in_addr dest_addr;
  struct in_addr gw_addr;
  struct in_addr mask_addr;

  if (access(file.c_str(), R_OK) != 0) {
    perror("access");
    return false;
  }

  fp = fopen(file.c_str(), "r");

  while (fgets(line, BUFSIZ, fp) != 0) {
    sscanf(line,"%s %s %s %s", dest, gw, mask, iface);
    if (inet_aton(dest, &dest_addr) == 0) {
      fprintf(stderr,
              "Error loading routing table, cannot convert %s to valid IP\n",
              dest);
      return false;
    }
    if (inet_aton(gw, &gw_addr) == 0) {
      fprintf(stderr,
              "Error loading routing table, cannot convert %s to valid IP\n",
              gw);
      return false;
    }
    if (inet_aton(mask, &mask_addr) == 0) {
      fprintf(stderr,
              "Error loading routing table, cannot convert %s to valid IP\n",
              mask);
      return false;
    }

    addRoute({dest_addr.s_addr, gw_addr.s_addr, mask_addr.s_addr, iface});
  }
  return true;
}

void
RoutingTable::addRoute(RoutingTableEntry entry)
{
  m_entries.push_back(std::move(entry));
}

std::ostream&
operator<<(std::ostream& os, const RoutingTableEntry& entry)
{
  os << ipToString(entry.dest) << "\t\t"
     << ipToString(entry.gw) << "\t"
     << ipToString(entry.mask) << "\t"
     << entry.ifName;
  return os;
}

std::ostream&
operator<<(std::ostream& os, const RoutingTable& table)
{
  os << "Destination\tGateway\t\tMask\tIface\n";
  for (const auto& entry : table.m_entries) {
    os << entry << "\n";
  }
  return os;
}

} // namespace simple_router
