/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 2017 Alexander Afanasyev
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of
 * the GNU General Public License as published by the Free Software Foundation, either version
 * 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 */

#include "simple-router.hpp"
#include "core/utils.hpp"

#include <stdlib.h>
#include <stdio.h>
#include <fstream>

namespace simple_router {

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

/*
    Returns if ethernet header is valid
    - Validate packet length
    - Check for broadcast address
    - Check for matching address
*/
bool validEthernetHeader(const Buffer& packet, const Buffer& iAddr) {
    // Check if packet is long enough to be an Ethernet packet
    if (packet.size() < sizeof(ethernet_hdr)) {
        return false;
    }
    // Extract dest. MAC addr.
    ethernet_hdr* ehdr = (ethernet_hdr*)packet.data();
    uint8_t* dest = ehdr->ether_dhost;
    bool isBroadcast = true, isMatch = true;
    // Check if dest. MAC addr. is broadcast addr.
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        if (dest[i] != 0xFF) {
            isBroadcast = false;
            break;
        }
    }
    // Check if dest. MAC addr. matches iface addr.
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        if (dest[i] != iAddr[i]) {
            isMatch = false;
            break;
        }
    }
    // Must be either broadcast or match to be accepted
    return isBroadcast || isMatch;
}

/*
    Returns if ARP header is valid
    - Check packet length
    - Check hardware format
    - Check protocol format
    - Check hardware addr. len.
    - Check protocol addr. len.
*/
bool validARPHeader(const Buffer& packet) {
    // Check packet size
    if (packet.size() < sizeof(ethernet_hdr) + sizeof(arp_hdr)) {
        return false;
    }
    // Extract ARP header
    arp_hdr* ahdr = (arp_hdr*)(packet.data() + sizeof(ethernet_hdr));
    // Extract hardware format
    unsigned short hrd = ntohs(ahdr->arp_hrd);
    // Extract protocol format
    unsigned short pro = ntohs(ahdr->arp_pro);
    // Extract hardware addr. len.
    unsigned char hln = ahdr->arp_hln;
    // Extract protocol addr. len.
    unsigned char pln = ahdr->arp_pln;
    // Verify all conditions pass
    return hrd == 0x0001 && pro == 0x0800 && hln == 0x06 && pln == 0x04;
}

/*
    Returns if IP header is valid
    - Check packet length
    - Check checksum
    - Check version
    - Check TTL
*/
bool validIPHeader(const Buffer& packet) {
    // Check packet size
    if (packet.size() < sizeof(ethernet_hdr) + sizeof(ip_hdr)) {
        return false;
    }
    // Extract IP header
    ip_hdr* ihdr = (ip_hdr*)(packet.data() + sizeof(ethernet_hdr));
    // Calculate checksum
    uint16_t checksum = cksum(ihdr, sizeof(ip_hdr));
    // Extract version number
    unsigned int version = ihdr->ip_v;
    // Extract TTL
    uint8_t ttl = ihdr->ip_ttl;
    // Verify all conditions pass
    return checksum == 0xFFFF && version == 4 && ttl > 1;
}

/*
    Build an Ethernet header given header information
    - Dest. addr.
    - Source addr.
    - Packet type
*/
Buffer SimpleRouter::buildEthernetHeader(const uint8_t* src, const uint8_t* dest, uint16_t type) {
    Buffer hdr;
    // Construct destination address
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        hdr.push_back(dest[i]);
    }
    // Construct source address
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        hdr.push_back(src[i]);
    }
    // Construct type
    type = ntohs(type);
    uint8_t* typePtr = (uint8_t*)&type;
    for (int i = 0; i < 2; i++) {
        hdr.push_back(typePtr[i]);
    }
    return hdr;
}

/*
    Build an ARP header given header information
    - Hardware type (0x0001)
    - Protocol type (0x0800)
    - Hardware addr. len. (0x06)
    - Protocol addr. len. (0x04)
    - Opcode
    - Source hardware addr.
    - Source protocol addr.
    - Dest. hardware addr.
    - Dest. protocol addr.
*/
Buffer SimpleRouter::buildARPHeader(uint16_t opcode, const uint8_t* hsrc, const uint32_t psrc, const uint8_t* hdest, const uint32_t pdest) {
    Buffer hdr;
    // Construct hardware type
    hdr.push_back(0x00);
    hdr.push_back(0x01);
    // Construct protocol type
    hdr.push_back(0x08);
    hdr.push_back(0x00);
    // Construct hardware address length
    hdr.push_back(ETHER_ADDR_LEN);
    // Construct protocol address length
    hdr.push_back(0x04);
    // Construct opcode
    opcode = ntohs(opcode);
    std::cout << opcode << std::endl;
    uint8_t* opPtr = (uint8_t*)&opcode;
    for (int i = 0; i < 2; i++) {
        hdr.push_back(opPtr[i]);
    }
    // Construct source hardware address
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        hdr.push_back(hsrc[i]);
    }
    // Construct source protocol address
    uint8_t* ipsrc = (uint8_t*)(&psrc);
    for (int i = 0; i < 4; i++) {
        hdr.push_back(ipsrc[i]);
    }
    // Construct destination hardware address
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        hdr.push_back(hdest[i]);
    }
    // Construct destination protocol address
    uint8_t* ipdest = (uint8_t*)(&pdest);
    for (int i = 0; i < 4; i++) {
        hdr.push_back(ipdest[i]);
    }
    return hdr;
}

/*
    ARP request handler
    - Find the requested interface
    - If the interface exists, construct and send back an ARP reply from iface
*/
void SimpleRouter::handleARPRequest(const ethernet_hdr* ehdr, const arp_hdr* ahdr, const std::string& inIface) {
    // Find target interface
    const Interface* targetIface = findIfaceByIp(ahdr->arp_tip);
    // Check if the interface exists
    if (targetIface != nullptr) {
        // Get sender addr
        const Interface* senderIface = findIfaceByName(inIface);
        const uint8_t* ethernetSrc = &(senderIface->addr[0]);
        // Construct the ARP reply
        Buffer arpReply = buildEthernetHeader(ethernetSrc, ehdr->ether_shost, ethertype_arp);
        Buffer arpHdr = buildARPHeader(arp_op_reply, targetIface->addr.data(), targetIface->ip, ahdr->arp_sha, ahdr->arp_sip);
        arpReply.insert(arpReply.end(), arpHdr.begin(), arpHdr.end());
        // Send the ARP reply out on iface request was received at
        sendPacket(arpReply, inIface);
        std::cerr << "Sent ARP reply" << std::endl;
    }
}

/*
    ARP reply handler
    - Add mapping to ARP cache
    - Iterate over queued packets
    - Forward packets
    - Remove request from queue
*/
void SimpleRouter::handleARPReply(const arp_hdr* ahdr, const std::string& inIface) {
    // Construct MAC-IP mapping from ARP reply
    Buffer mac;
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        mac.push_back(ahdr->arp_sha[i]);
    }
    std::shared_ptr<ArpRequest> req = m_arp.insertArpEntry(mac, ahdr->arp_sip);
    std::cerr << "Inserted ARP cache entry for (" << macToString(mac) << ", " << ipToString(req->ip) << ")" << std::endl;
    // Iterate over queued packets
    for (auto& packet : req->packets) {
        sendIPPacket(packet.packet, mac, packet.iface);
    }
    // Remove req. from queue
    m_arp.removeArpRequest(req);
    std::cerr << "Removed ARP request for " << ipToString(req->ip) << std::endl;
}

/*
    ARP packet handler
    - Validate packet
    - Extract headers
    - Extract opcode
    - Call handler corresponding to opcode
*/
void SimpleRouter::handleARPPacket(const Buffer& packet, const std::string& inIface) {
    // Validate packet
    if (!validARPHeader(packet)) {
        std::cerr << "Dropped ARP packet on interface " << inIface << std::endl;
        return;
    }
    // Extract headers
    ethernet_hdr* ehdr = (ethernet_hdr*)packet.data();
    arp_hdr* ahdr = (arp_hdr*)(packet.data() + sizeof(ethernet_hdr));
    // Extract opcode
    uint16_t op = ntohs(ahdr->arp_op);
    // Handle ARP request
    if (op == arp_op_request) {
        std::cerr << "Received ARP request for " << ipToString(ahdr->arp_tip) << " on interface " << inIface << std::endl;
        handleARPRequest(ehdr, ahdr, inIface);
    // Handle ARP reply
    } else if (op == arp_op_reply) {
        std::cerr << "Received ARP reply for " << ipToString(ahdr->arp_sip) << " on interface " << inIface << std::endl;
        handleARPReply(ahdr, inIface);
    }
}

/*
    Sends given ARP request to each interface
    - Iterate over each interface
    - Construct the ARP request
    - Send the packet to the subnet
*/
void SimpleRouter::sendARPRequest(const ArpRequest& req) {
    // Find iface to send on
    if (req.packets.empty()) {
        std::cout << "Something went very wrong" << std::endl;
    } else {
        const Interface* outIface = findIfaceByName(req.packets.front().iface);
        // Extract source addr.
        const uint8_t* ethernetSrc = (uint8_t*)(&outIface->addr[0]);
        // Define dest. addr.
        uint8_t broadcastAddr[ETHER_ADDR_LEN] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
        uint8_t unknownAddr[ETHER_ADDR_LEN] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
        // Build ARP request packet
        Buffer arpReq = buildEthernetHeader(ethernetSrc, broadcastAddr, ethertype_arp);
        Buffer arpHdr = buildARPHeader(arp_op_request, ethernetSrc, outIface->ip, unknownAddr, req.ip);
        arpReq.insert(arpReq.end(), arpHdr.begin(), arpHdr.end());
        sendPacket(arpReq, outIface->name);
        std::cerr << "Sent ARP request for " << ipToString(req.ip) << " on interface " << outIface->name << std::endl;
    }
}

/*
    IP packet handler
    - Validate packet
    - Extract headers
    - Check that packet is not bound for router or denied by ACL table
    - Decrement TTL
    - Recompute checksum
    - Find next-hop IP
    - Check ARP cache for next-hop MAC
    - Send ARP requests for dest. not in ARP cache
    - Queue packets that are waiting on ARP requests
    - Forward packets that have dest. in ARP cache
*/
void SimpleRouter::handleIPPacket(const Buffer& packet, const std::string& inIface) {
    // Validate header
    if (!validIPHeader(packet)) {
        std::cerr << "Dropped IP packet on interface " << inIface << " due to invalid header" << std::endl;
        return;
    }
    // Make a copy of the incoming packet
    Buffer newPacket = packet;
    // Extract header
    ip_hdr* ihdr = (ip_hdr*)(newPacket.data() + sizeof(ethernet_hdr));
    // Check that packet is not bound for router
    const Interface* targetIface = findIfaceByIp(ihdr->ip_dst);
    if (targetIface != nullptr) {
        std::cerr << "Dropped IP packet on interface " << inIface << " due to router destination" << std::endl;
        return;
    }
    // Check ACL table
    try {
        uint16_t srcPort = 0x0000, destPort = 0x0000;
        // If TCP or UDP packet
        if (ihdr->ip_p == 0x06 || ihdr->ip_p == 0x11) {
            uint16_t* phdr = (uint16_t*)(packet.data() + sizeof(ethernet_hdr) + sizeof(ip_hdr));
            srcPort = phdr[0];
            destPort = phdr[1];
        }
        // Lookup in ACL table
        ACLTableEntry aclEntry = m_aclTable.lookup(ihdr->ip_src, ihdr->ip_dst, ihdr->ip_p, srcPort, destPort);
        // If ACL table says to deny, drop the packet
        if (aclEntry.action == "deny") {
            std::cerr << "Dropped IP packet on interface " << inIface << " due to ACL violation" << std::endl;
            // Log packet drop
            std::ofstream file;
            file.open("./router-acl.log", std::ios::app);
            if (file.is_open()) {
                file << std::hex << aclEntry.src << "&" << aclEntry.srcMask << " ";
                file << aclEntry.dest << "&" << aclEntry.destMask << " ";
                file << aclEntry.srcPort << "&" << aclEntry.srcPortMask << " ";
                file << aclEntry.destPort << "&" << aclEntry.destPortMask << " ";
                file << (uint16_t)aclEntry.protocol << "&" << (uint16_t)aclEntry.protocolMask << " ";
                file << aclEntry.priority << " ";
                file << aclEntry.action << "\n";
                file.close();
            } else {
                std::cerr << "Error opening logging file" << std::endl;
            }
            return;
        }
    } catch (...) {
        std::cerr << "Rule not found in ACL table" << std::endl;
    }
    // Decrement TTL
    ihdr->ip_ttl--;
    // Recompute checksum
    ihdr->ip_sum = 0;
    ihdr->ip_sum = cksum(ihdr, sizeof(ip_hdr));
    // Lookup next-hop IP
    RoutingTableEntry entry = m_routingTable.lookup(ihdr->ip_dst);
    uint32_t nextHopIP = entry.gw;
    const Interface* nextHopIface = findIfaceByName(entry.ifName);
    Buffer ifaceAddr = nextHopIface->addr;
    // Modify the source MAC addr. in the Ethernet header
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        newPacket[ETHER_ADDR_LEN + i] = ifaceAddr[i];
    }
    // If next-hop IP is not in ARP cache, queue ARP request
    std::shared_ptr<ArpEntry> arpEntry = m_arp.lookup(nextHopIP);
    if (arpEntry == nullptr) {
        // Queue the ARP request
        m_arp.queueArpRequest(nextHopIP, newPacket, entry.ifName);
        std::cerr << "Queued ARP request for " << ipToString(nextHopIP) << std::endl;
    // Otherwise, refresh entry and forward to known MAC addr.
    } else {
        // Save MAC-IP mapping
        Buffer mac = arpEntry->mac;
        uint32_t ip = arpEntry->ip;
        // Erase old entry
        arpEntry->isValid = false;
        m_arp.removeInvalidEntries();
        // Add refreshed entry
        m_arp.insertArpEntry(mac, ip);
        // Forward packet
        sendIPPacket(newPacket, arpEntry->mac, entry.ifName);
    }
}

/*
    Sends an IP packet from a given interface
*/
void SimpleRouter::sendIPPacket(const Buffer& packet, const Buffer& mac, const std::string& iface) {
    Buffer newPacket = packet;
    // Extract headers
    ethernet_hdr* ehdr = (ethernet_hdr*)(newPacket.data());
    ip_hdr* ihdr = (ip_hdr*)(newPacket.data() + sizeof(ethernet_hdr));
    // Set packet's MAC dest.
    for (int i = 0; i < ETHER_ADDR_LEN; i++) {
        ehdr->ether_dhost[i] = mac[i];
    }
    // Send packet on designated interface
    sendPacket(newPacket, iface);
    std::cerr << "Sent packet to " << ipToString(ihdr->ip_dst) << " from interface " << iface << std::endl;
}


/*
    Ethernet packet handler
    - Validate packet
    - Determine payload type
    - Offload to corresponding ARP/IP functions, ignoring other payloads
*/
void
SimpleRouter::processPacket(const Buffer& packet, const std::string& inIface)
{
    // Skeleton code
    std::cerr << "Got packet of size " << packet.size() << " on interface " << inIface << std::endl;
    const Interface* iface = findIfaceByName(inIface);
    if (iface == nullptr) {
        std::cerr << "Received packet, but interface is unknown, ignoring" << std::endl;
        return;
    }
    // Check if dest. MAC addr. should be accepted
    if (!validEthernetHeader(packet, iface->addr)) {
        std::cerr << "Dropped Ethernet packet on interface " << inIface << std::endl;
        return;
    }
    // Get payload type
    uint16_t ether_type = ethertype(packet.data());
    // Handle ARP payload
    if (ether_type == ethertype_arp) {
        std::cerr << "Received ARP packet on interface " << inIface << std::endl;
        handleARPPacket(packet, inIface);
    // Handle IP payload
    } else if (ether_type == ethertype_ip) {
        std::cerr << "Received IP packet on interface " << inIface << std::endl;
        handleIPPacket(packet, inIface);
    }

}
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

// You should not need to touch the rest of this code.
SimpleRouter::SimpleRouter()
  : m_arp(*this)
{
  m_aclLogFile.open("router-acl.log");
}

void
SimpleRouter::sendPacket(const Buffer& packet, const std::string& outIface)
{
  m_pox->begin_sendPacket(packet, outIface);
}

bool
SimpleRouter::loadRoutingTable(const std::string& rtConfig)
{
  return m_routingTable.load(rtConfig);
}

bool
SimpleRouter::loadACLTable(const std::string& aclConfig)
{
  return m_aclTable.load(aclConfig);
}

void
SimpleRouter::loadIfconfig(const std::string& ifconfig)
{
  std::ifstream iff(ifconfig.c_str());
  std::string line;
  while (std::getline(iff, line)) {
    std::istringstream ifLine(line);
    std::string iface, ip;
    ifLine >> iface >> ip;

    in_addr ip_addr;
    if (inet_aton(ip.c_str(), &ip_addr) == 0) {
      throw std::runtime_error("Invalid IP address `" + ip + "` for interface `" + iface + "`");
    }

    m_ifNameToIpMap[iface] = ip_addr.s_addr;
  }
}

void
SimpleRouter::printIfaces(std::ostream& os)
{
  if (m_ifaces.empty()) {
    os << " Interface list empty " << std::endl;
    return;
  }

  for (const auto& iface : m_ifaces) {
    os << iface << "\n";
  }
  os.flush();
}

const Interface*
SimpleRouter::findIfaceByIp(uint32_t ip) const
{
  auto iface = std::find_if(m_ifaces.begin(), m_ifaces.end(), [ip] (const Interface& iface) {
      return iface.ip == ip;
    });

  if (iface == m_ifaces.end()) {
    return nullptr;
  }

  return &*iface;
}

const Interface*
SimpleRouter::findIfaceByMac(const Buffer& mac) const
{
  auto iface = std::find_if(m_ifaces.begin(), m_ifaces.end(), [mac] (const Interface& iface) {
      return iface.addr == mac;
    });

  if (iface == m_ifaces.end()) {
    return nullptr;
  }

  return &*iface;
}

const Interface*
SimpleRouter::findIfaceByName(const std::string& name) const
{
  auto iface = std::find_if(m_ifaces.begin(), m_ifaces.end(), [name] (const Interface& iface) {
      return iface.name == name;
    });

  if (iface == m_ifaces.end()) {
    return nullptr;
  }

  return &*iface;
}

void
SimpleRouter::reset(const pox::Ifaces& ports)
{
  std::cerr << "Resetting SimpleRouter with " << ports.size() << " ports" << std::endl;

  m_arp.clear();
  m_ifaces.clear();

  for (const auto& iface : ports) {
    auto ip = m_ifNameToIpMap.find(iface.name);
    if (ip == m_ifNameToIpMap.end()) {
      std::cerr << "IP_CONFIG missing information about interface `" + iface.name + "`. Skipping it" << std::endl;
      continue;
    }

    m_ifaces.insert(Interface(iface.name, iface.mac, ip->second));
  }

  printIfaces(std::cerr);
}

} // namespace simple_router {
